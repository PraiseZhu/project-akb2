---
report_type: manual_source_intake
date: 2026-05-08
runbook_ref: docs/runbooks/manual-source-intake.md
topic: "andrej-karpathy-skills Stage 2 首个真实 manual intake"
lint_baseline: "manifests/lint/2026-05-08T201058-v0-3.jsonl"
scope_guard: "Stage 2 边界：只处理此 1 个候选；不扩 scope；不启用 MCP/hook/cron"
---

# Manual Intake Report — andrej-karpathy-skills (2026-05-08)

> **scope_guard**：Stage 2 执行边界 — 只处理此 1 个候选，不扩展至其他候选，不启用 MCP / hook / cron / 自动抓取。

---

## 1. 输入材料

| 字段 | 内容 |
|------|------|
| 来源 URL | https://github.com/forrestchang/andrej-karpathy-skills |
| 材料标题 | andrej-karpathy-skills — LLM Coding Behavioral Guidelines |
| source_type | blog |
| raw_integrity_note | mixed（§A web_copy_paste / §B web_copy_paste selected / §C hand_summary） |
| captured_at | 2026-05-08 |
| ingest_channel | manual |

---

## 2. Raw 输出

| 字段 | 内容 |
|------|------|
| raw 文件路径 | `raw/andrej-karpathy-skills--raw--2026-05-08.md` |
| 归档状态 | ✅ 已创建 |
| 结构 | §A CLAUDE.md 全文 / §B EXAMPLES.md 4 代表性示例 + Anti-Pattern 摘要 / §C overview.md 元信息 + ECC 对比表 + Karpathy 引用 |

---

## 3. Source Gate Decision

| 字段 | 内容 |
|------|------|
| staging candidate 路径 | `staging/candidate/manual-source-intake-2026-05-08/andrej-karpathy-skills.md` |
| gate_decision | `active` |
| gate 判定依据 | INTAKE-GATE §3 全 11 条满足：89.8k ⭐ 社区高引用；4 原则定义清晰（source_grounded）；与 harness-engineering 行为约束层有直接对应；evidence_provenance = source_grounded（§A CLAUDE.md 全文为主证据） |
| source active 路径 | `wiki/sources/andrej-karpathy-skills.md` |
| ingest manifest | `manifests/ingest/2026-05-08-andrej-karpathy-skills-manual-intake.jsonl` |
| backlink 更新 | `wiki/concepts/concept-harness-engineering.md` related_sources 加 `[[andrej-karpathy-skills]]` |
| index 更新 | `wiki/sources/00-Index.md` §4 blog 新增条目（2026-05 subsection） |

---

## 4. Concept Decision（可选）

| 字段 | 内容 |
|------|------|
| 是否满足 direct source 三条件 | 部分满足（active source ✅ + 定义性段落 ✅ + 概念名 Surgical Changes / Simplicity First ✅） |
| concept 决策 | `needs_source`（无独立 concept 页；创建 concept-surgical-changes 等属 Stage 2 scope expansion） |
| 决策理由 | 三条件技术上满足，但在"只处理 1 个候选"scope_guard 下，新建 concept 页超出 Stage 2 边界。延后至下轮 intake 处理。见 manifest stage2-006。 |
| concept candidate 路径（如建页） | — |
| concept active 路径（gate 通过后） | — |

> **`needs_source`** 是本轮决策标签，非 lifecycle status，不写入任何页面 `status` 字段。

---

## 5. Lint / Review

| 项目 | 结果 |
|------|------|
| lint 复跑命令 | `python3 .akb-runtime/lint/akb2-lint.py --version v0.3` |
| lint 结果（P0/P1/P2） | P0=0 / P1=0 / P2=0 ✅ |
| lint manifest 路径 | `manifests/lint/2026-05-08T201058-v0-3.jsonl` |
| 修复过程 | 首次 lint: P1 SOURCE-KEY-FINDINGS-MISSING-FRONTMATTER → 补 key_findings 数组；二次 lint: P2 SOURCE-KEY-FINDINGS-MISSING-PROSE → 补 `## 关键发现` 章节；三次 lint: P0/P1/P2=0 |
| active 页数 | 20（+1 vs baseline 19，新增 andrej-karpathy-skills） |
| code review 触发 | `/review code` → Codex review capsule |
| review 结果 | **APPROVED** |
| review result 路径 | `~/.claude/review-baselines/c9c2dd365172/result-20260508T121530Z.md` |

---

## 6. 未做项

- 未建 concept-surgical-changes / concept-simplicity-first 等 concept 页（Stage 2 scope 外，延后）
- 未修改 `docs/AKB-2.0-*.md` 任何标准文档
- 未处理其他 source 候选（Stage 2 边界：只处理此 1 个候选）
- 未做阶段完成报告（本报告只记录本轮 intake，非 Stage 2 完成报告）

---

## 7. 不变量

- 0 新改 `.akb-runtime/lint/akb2-lint.py`
- 0 新改 `docs/AKB-2.0-*.md` 任何标准文档
- 0 新改 `toolbox/**`
- 0 启用 MCP / hook / cron / Obsidian on-save / pre-commit
- 0 新增 stage completion report
- 0 修改旧 AKB（只修改 AKB2.0 vault）
- 0 新建 concept 页（needs_source 决策，延后至下轮）
- 新增文件范围仅限：`raw/`（1）/ `staging/candidate/`（1）/ `wiki/sources/`（1）/ `manifests/ingest/`（1）/ `docs/phase-d-reports/`（本文件）；修改文件范围仅限：`wiki/sources/00-Index.md` / `wiki/concepts/concept-harness-engineering.md`

---

## 维护记录

| 日期 | 改动 | 作者 |
|------|------|------|
| 2026-05-08 | 初始创建 — Stage 2 andrej-karpathy-skills manual intake CP-7 report | praise + Claude Code |
