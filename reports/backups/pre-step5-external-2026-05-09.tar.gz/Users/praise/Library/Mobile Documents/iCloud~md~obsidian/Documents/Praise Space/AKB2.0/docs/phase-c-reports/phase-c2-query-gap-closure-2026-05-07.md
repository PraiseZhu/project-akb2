---
report_type: phase_c_query_gap_closure
report_id: phase-c2-query-gap-closure-2026-05-07
date: 2026-05-07
scope: C1 P1 backlog (BL-C1-001 / BL-C1-002 / BL-C1-003)
predecessor_report: docs/phase-c-reports/phase-c1-active-usability-validation-2026-05-06.md
manifest: manifests/ingest/2026-05-07-c2-query-gap-closure.jsonl
verdict: PASS_WITH_BACKLOG
---

# AKB2.0 Phase C2 — 查询缺口闭环与正文质量修正报告

## 执行摘要

Phase C1 暴露 3 个 P1 backlog（karpathy / MCP / CE source 缺口）。C2 按用户决策：BL-C1-001 deferred-not-blocked；BL-C1-002 + BL-C1-003 用 Anthropic 官方源闭环。

**结论**：`PASS_WITH_BACKLOG`

- BL-C1-001（karpathy）：deferred-not-blocked-this-round；本轮不找第三方低可信 transcript
- BL-C1-002（MCP）：闭环 — 新建 [[mcp-spec]] source + [[concept-mcp-tool-use]] hub
- BL-C1-003（CE）：闭环 — 新建 [[anthropic-effective-context-engineering]] source；[[concept-context-engineering]] 从 cluster_center 升级为 hub
- 8 query 复测：5 yes / 3 partial / 0 no（C1 是 4 yes / 4 partial / 0 no），Q2 由 partial 推到 yes
- Obsidian 阅读体验：`pending_user_visual_check`（继承 C1 状态，用户未给截图）
- 全部 raw 归档于 `raw/`；无 LLM 自编内容

---

## §1. P1 Backlog 处理结果

### BL-C1-001：karpathy transcript / LLM concept 升级

**状态**：`deferred-not-blocked-this-round`

**理由**：用户决策不为 BL-C1-001 找第三方低可信 transcript，也不用 YouTube URL + 模型常识补 LLM concept。无可靠 transcript / source-grounded 材料不足，本轮 LLM concept 不动。后续若用户提供本地 transcript 或手动整理笔记再单独补。

**影响**：
- [[concept-large-language-model]] 仍保 `evidence_provenance: bridging_source_grounded` + `graph_status: orphan_risk`
- [[karpathy-intro-to-llms]] source 仍保 walkthrough-grounded
- C1 Q1 的 LLM mental model 部分仍 partial

**未来路径**：用户提供 transcript → `raw/karpathy-intro-to-llms-transcript--raw--YYYY-MM-DD.md` 入库 → 升级 karpathy source 到 `source_grounded` → 升级 LLM concept evidence。

### BL-C1-002：MCP tool-use concept 缺失

**状态**：`closed`

**处理**：

1. WebFetch modelcontextprotocol.io 三页（introduction / architecture / server-concepts）→ 归档 `raw/mcp-spec--raw--2026-05-07.md`
2. 新建 [[mcp-spec]] source 页（`evidence_provenance: source_grounded` / `graph_status: healthy`）
3. 新建 [[concept-mcp-tool-use]] hub 概念页（`evidence_provenance: source_grounded` / `graph_status: healthy`）
4. 修 [[concept-harness-engineering]]：frontmatter `related_concepts` 加 [[concept-mcp-tool-use]]；正文 §二.1 第 1 条加跳转；## 图谱关系 表新增 extends 行；Pending 列表移除 `concept-mcp-tool-use`

**评估覆盖度**：
- [[mcp-spec]] §1 提供 MCP 定义 + USB-C 类比 + 生态支持
- §2 提供三角色（host/client/server）+ 两层架构（data/transport）+ lifecycle
- §3 提供三类 server primitives（Tools/Resources/Prompts）+ 控制方差异
- 不足：Authorization OAuth 完整 flow 未抓（本 source Q4 backlog）；Sampling/Elicitation 仅有定义未给完整使用模式

### BL-C1-003：Context Engineering 专门 source 缺失

**状态**：`closed`

**处理**：

1. WebFetch anthropic.com/engineering/effective-context-engineering-for-ai-agents → 归档 `raw/anthropic-effective-context-engineering--raw--2026-05-07.md`
2. 新建 [[anthropic-effective-context-engineering]] source 页（`evidence_provenance: source_grounded` / `graph_status: healthy`）
3. 重写 [[concept-context-engineering]] v4：`graph_role` cluster_center → hub；`graph_status` orphan_risk → healthy；`evidence_provenance` bridging_source_grounded → source_grounded；正文从对照锚扩为完整 hub（CE 重要性 + 四大 anatomy + 长程三技术 + CE 与 tool use/memory + 三 hub 边界）

**评估覆盖度**：
- 定义覆盖：CE 是什么 / CE vs PE 边界 / CE 工程问题表述 — 全部 source_fact
- 重要性覆盖：attention budget + context rot + n² 限制 + 边际收益递减 + agent 长程 acuteness — source_fact
- 实操覆盖：四大 anatomy（system prompt / tools / examples / just-in-time） + 长程三技术（compaction / structured note-taking / sub-agent） — source_fact
- 关系覆盖：CE 与 tool use / memory 关系 — source_fact + akb_interpretation 标注三 hub 边界
- 不足：CE 量化基准缺；多模态 CE 缺；RAG 流派对比缺（这些进 CE concept Future Questions）

---

## §2. 文件清单

### 新建（5 个）

| 文件 | 类型 | 大小 | 说明 |
|---|---|---|---|
| `raw/mcp-spec--raw--2026-05-07.md` | raw | ~7K | MCP 三页 fetch 归档 |
| `raw/anthropic-effective-context-engineering--raw--2026-05-07.md` | raw | ~6K | Anthropic CE blog 归档 |
| `wiki/sources/mcp-spec.md` | source | ~10K | MCP 官方 docs source 页 |
| `wiki/sources/anthropic-effective-context-engineering.md` | source | ~10K | Anthropic CE blog source 页 |
| `wiki/concepts/mcp-tool-use.md` | concept hub | ~9K | MCP Tool Use 概念页 |

### 修改（4 个）

| 文件 | 类型改动 | 改动范围 |
|---|---|---|
| `wiki/concepts/context-engineering.md` | rewritten v4 | hub 升级 + 主源换 + 正文从对照锚扩为完整 hub；备份 `archive/active-pre-c2-2026-05-07/` |
| `wiki/concepts/harness-engineering.md` | incremental_link_update | frontmatter 加 MCP 链；正文 §二.1 第 1 条加跳转；## 图谱关系 加 extends 行；正文论证未改；备份 `archive/active-pre-c2-2026-05-07/` |
| `wiki/sources/00-Index.md` | incremental_index_update | 加 §4 blog（含 anthropic-effective-context-engineering）+ §5 docs（含 mcp-spec） |
| `wiki/concepts/00-Index.md` | incremental_index_update | CE 索引行重写（hub 升级）+ 加 mcp-tool-use 索引行 |

### 不修改（plan 明示）

- `wiki/sources/karpathy-intro-to-llms.md`（BL-C1-001 deferred）
- `wiki/concepts/large-language-model.md`（无 source 升级源）
- `wiki/sources/jenny-wen-ai-design-philosophy.md` / `wiki/sources/harness-engineering-deep-eval.md`（不需要）
- `wiki/designs/implementation-aware-design.md` / `wiki/designs/00-Index.md`（IAD / 设计主线本轮不动）
- 旧 AKB / Project AKB / `toolbox/` / Obsidian 配置 / 自动化链路 / docs/AKB-2.0-* 标准主文档

---

## §3. 查询复测（C1 8 query 全量重测）

### Q1（用户题）：AKB2.0 里 large language model 的核心 mental model 是什么？它和 agent / tool use / memory 有什么关系？

| 维度 | C1 状态 | C2 状态 | 改进路径 |
|---|---|---|---|
| LLM mental model | partial | partial | BL-C1-001 deferred；karpathy transcript 待入库 |
| 与 agent 关系 | partial | yes | concept-LLM → concept-HE 直链已存在；HE 现含 MCP/CE 三 hub 关联 |
| 与 tool use 关系 | partial（需 2 跳到 HE 7 组件第 1 条） | yes（concept-mcp-tool-use 直接 part_of HE） | BL-C1-002 闭环 |
| 与 memory 关系 | partial（HE 7 组件第 2 条仅组件名） | yes（CE concept §3 长程三技术含 structured note-taking + Anthropic memory tool） | BL-C1-003 闭环 |

**C2 整体答题质量**：**partial**（LLM 本体 mental model 仍待 transcript 升级）但 agent/tool/memory 三个子问题全 yes。

### Q2（用户题）：Harness Engineering 和 Context Engineering 的边界是什么？我做 Claude Code / MCP / agent 工具时应该分别怎么用？

| 维度 | C1 状态 | C2 状态 | 改进路径 |
|---|---|---|---|
| HE/CE 边界 | partial | **yes** | CE v4 concept 含"三 hub 边界"明示表（HE 治理层 / CE 推理窗口层 / MCP 协议接入层）+"CE vs PE/RAG/Memory 边界"明示表 |
| Claude Code 应用 | partial | yes | Anthropic CE blog §3.4 直举 Claude Code 例子（CLAUDE.md 预加载 + glob/grep just-in-time）；MCP spec §2 Claude Code 是 host 例子 |
| MCP 应用 | partial（仅 NLM 报告组件名） | **yes** | concept-mcp-tool-use hub 提供三角色 + 三 primitives + 控制方差异 + 与 HE/CE 边界 |
| agent 工具应用 | partial（缺单工具深度） | partial | entity-claude-code / entity-cursor / entity-cline 仍在 BL-C1-004 P2 backlog |

**C2 整体答题质量**：**yes**（核心 boundary 部分由 partial 推到 yes；agent 工具 production 配置部分仍 partial 但有明确 backlog 路径）。**Q2 是本轮主要 partial → yes 的改进。**

### Q3（用户题）：Implementation-aware design 对我做 AI 工具、设计系统、Figma/Code Connect 工作流有什么具体指导？

| 维度 | C1 状态 | C2 状态 | 改进路径 |
|---|---|---|---|
| AI 工具 / 设计师角色 | yes | yes | IAD 30/30/30 时间分配 + 三类人才；本轮 IAD 未改但已 yes |
| 设计系统 | partial | partial | BL-C1-005（design tokens governance）P2 backlog，本轮不在范围 |
| Figma Code Connect 工作流 | partial | partial | 同上 BL-C1-005 |

**C2 整体答题质量**：**partial**（IAD 设计页本轮不在 P1 范围；改进需 BL-C1-005 后续 P2 plan）。

### Q4（补充题）：如果我要设计 agent harness，应该先读哪些页？

C1: yes → C2: **yes**（增强）

C2 后推荐路径变为 6 篇（原 5 + 新 mcp-tool-use）：
1. [[concept-harness-engineering]]（HE 定义 + 三层范式 + 7 组件）
2. [[concept-context-engineering]]（CE 推理窗口治理 + 长程技术）— 升级为 hub
3. [[concept-mcp-tool-use]]（HE 7 组件第 1 条 hub）— 新增
4. [[harness-engineering-deep-eval]]（NLM 35 源 + 实证）
5. [[anthropic-effective-context-engineering]]（CE 主源）— 新增
6. [[mcp-spec]]（MCP spec）— 新增

### Q5（补充题）：Claude Code/Codex 使用 AKB2.0 时，哪些概念页能提供上下文？

C1: yes（4 页）→ C2: **yes**（5 页）

| 概念页 | 用途 |
|---|---|
| [[concept-large-language-model]] | LLM 入门 mental model（仍 hub 入口） |
| [[concept-harness-engineering]] | agent 工程治理层 |
| [[concept-context-engineering]] | 推理窗口 token 治理（C2 升 hub） |
| [[concept-mcp-tool-use]] | 工具调用协议层（C2 新增） |
| [[implementation-aware-design]] | 设计协同侧 |

### Q6（补充题）：从 `large-language-model` 能否跳到 `harness-engineering` 和 `context-engineering`？

C1: partial → C2: **partial**（未改进；P3 backlog BL-C1-008 本轮未做）

- LLM → HE: ✅ 1 跳（未变）
- LLM → CE: ❌ 直接，仍需 LLM → HE → CE 2 跳（HE related_concepts 含 CE）

理由：BL-C1-008 是 P3 cosmetic（语义上 CE 是 HE 的 part_of，2 跳合理），plan 明示"P2/P3 不在本轮范围"。

### Q7（补充题）：从 `implementation-aware-design` 能否追溯到 Jenny source？

C1: yes → C2: **yes**（未变）

IAD 本轮未改。

### Q8（补充题）：source 页和 concept/design 页之间是否有可解释关系？

C1: yes → C2: **yes**（更丰富）

C2 后新增双向关系：
- mcp-spec ↔ concept-mcp-tool-use ✅
- mcp-spec ↔ concept-harness-engineering ✅（applies_to）
- mcp-spec ↔ harness-engineering-deep-eval ✅（corroborates）
- anthropic-effective-context-engineering ↔ concept-context-engineering ✅（evidenced_by strong）
- anthropic-effective-context-engineering ↔ concept-harness-engineering ✅（corroborates）
- anthropic-effective-context-engineering ↔ concept-mcp-tool-use ✅（applies_to）
- anthropic-effective-context-engineering ↔ harness-engineering-deep-eval ✅（corroborates）

### 查询复测汇总

| Query | C1 | C2 | 变化 |
|---|---|---|---|
| Q1 LLM mental model + agent/tool/memory | partial | partial | LLM 本体未改；agent/tool/memory 子问题全 yes |
| Q2 HE/CE 边界 + Claude Code/MCP/agent | partial | **yes** | **本轮主要 partial → yes 改进** |
| Q3 IAD + 设计系统/Code Connect | partial | partial | 不在本轮范围（BL-C1-005 P2） |
| Q4 设计 agent harness 阅读路径 | yes | yes（增强） | 加 mcp-tool-use 等 |
| Q5 Claude Code/Codex 上下文清单 | yes | yes（增强） | 4 → 5 概念页 |
| Q6 LLM → HE/CE 图谱跳转 | partial | partial | BL-C1-008 P3 未改 |
| Q7 IAD → Jenny | yes | yes | 未变 |
| Q8 source ↔ concept/design 双向 | yes | yes（更丰富） | 新增 7 对关系 |

**C1 → C2 总分**：4 yes / 4 partial → **5 yes / 3 partial**（净改进 1 yes）。3 个 partial 都对应明确 backlog 路径（BL-C1-001 deferred / BL-C1-005 P2 / BL-C1-008 P3）。

---

## §4. Obsidian 阅读体验验收

| 检查项 | 状态 | 说明 |
|---|---|---|
| 阅读视图第一屏可见 H1 + TLDR + 正文开头 | `pending_user_visual_check` | 继承 C1 状态；C2 新增 5 页 fm 17-22 行均合规 |
| Properties 不变成长篇正文容器 | `pending_user_visual_check` | C2 新增页 frontmatter 全部 ≤ 22 行；CE concept 从 17 → 17（v4 重写未增 fm） |
| TLDR 30 秒内可理解 | `pending_user_visual_check` | C2 新增 5 页 TLDR 均 1-3 段 + 含主源链接 |
| 入选理由短而明确 | `pending_user_visual_check` | C2 新增 4 页（不含 raw）均 3 重理由结构 |
| 证据地图可追溯来源 | static-pass | C2 新增 4 页（不含 raw）均含 `## 证据地图` 表 + raw §X 引用路径 |
| 核心论点 / 论证有人读价值 | `pending_user_visual_check` | 静态结构合规；阅读体验需用户判定 |
| 维护记录不干扰正文 | static-pass | 全部位于正文末节 `## 维护记录` |

**注**：Obsidian 视觉检查需用户实际打开。如未给截图，本节保持 `pending_user_visual_check`，不假装通过。

---

## §5. Index 导航验收（只读 + 本轮增量）

| Index 文件 | 改动 | 验收 |
|---|---|---|
| `wiki/sources/00-Index.md` | 加 §4 blog 分组 + §5 docs 分组 + 各 1 个索引行 | 5 个 source 全在索引 ✅ |
| `wiki/concepts/00-Index.md` | CE 索引行重写 + 加 mcp-tool-use 索引行 + HE 索引行加 2026-05-07 备注 | 4 个 concept 全在索引 ✅ |
| `wiki/designs/00-Index.md` | 未改 | 1 个 design 仍在索引 ✅ |

每行索引含一句人读摘要（≥ 3 关键判断 + 时间锚）。3 个 index 均可作 Claude/Codex 入口。

---

## §6. Graph Context 验收（C2 后状态）

### 健康度变化

| 节点 | C1 状态 | C2 状态 | 变化 |
|---|---|---|---|
| concept-large-language-model | orphan_risk | orphan_risk | 未变（BL-C1-001 deferred） |
| concept-harness-engineering | healthy | healthy | 加 extends [[concept-mcp-tool-use]] |
| concept-context-engineering | orphan_risk（cluster_center）| **healthy（hub）** | **升级**（主源 + role + status 三升） |
| concept-mcp-tool-use | N/A | **healthy（hub）** | 新建 |
| implementation-aware-design | healthy | healthy | 未变 |
| karpathy-intro-to-llms | orphan_risk | orphan_risk | 未变 |
| harness-engineering-deep-eval | healthy | healthy | 未变 |
| jenny-wen-ai-design-philosophy | healthy | healthy | 未变 |
| mcp-spec | N/A | **healthy** | 新建 |
| anthropic-effective-context-engineering | N/A | **healthy** | 新建 |

### orphan_risk 节点变化

C1: 3 个 orphan_risk（concept-LLM / concept-CE / karpathy）  
C2: 2 个 orphan_risk（concept-LLM / karpathy）— concept-CE 已升 healthy

剩余 2 个 orphan_risk 都对应 BL-C1-001 deferred；待用户提供 karpathy 材料后单独闭环。

### 三 hub 结构形成

C2 后 agent 工程主线 3 hub：
- [[concept-harness-engineering]]（治理层）
- [[concept-context-engineering]]（推理窗口层）— C2 升 hub
- [[concept-mcp-tool-use]]（协议接入层）— C2 新建

CE concept v4 § 论证与解释 §5 已显式声明三 hub 边界与分工。

---

## §7. 不变量验收

| 检查项 | 状态 | 证据 |
|---|---|---|
| 7 篇 active（C1 已审）正文未改 | partial | concept-context-engineering / concept-harness-engineering 本轮做计划允许的 hub 升级 + link 增量；其余 5 篇全未改 |
| `manifests/ingest/2026-05-05-active-rewrite.jsonl` 未改 | pass | 7 行未变 |
| `archive/active-pre-rewrite-2026-05-05/` 未改 | pass | 7 个 .md 未动 |
| 旧 manifest 2026-05-04-l4-pilot.jsonl 未追加 | pass | 18 行未变 |
| `toolbox/` 未改 | pass | 本轮无 toolbox 操作 |
| `docs/AKB-2.0-*` 标准主文档未改 | pass | 本轮未改任何标准文档（"正文质量宪法"仅记录在本 C2 报告 §10 backlog）|
| 旧 AKB / Project AKB / Obsidian 配置 / 自动化 / cron / NLM | pass | 本轮未触及 |
| 备份齐 | pass | `archive/active-pre-c2-2026-05-07/` 含 CE + HE 两个 v3 备份 |

注：CE concept 的"未改"在 C2 中是预期改动（升 hub）；HE concept 的"未改正文论证"是真的未改（仅 link 增量）。

---

## §8. Source-Grounding 严格性验证

C2 强制约束：所有论断必须能追溯到 raw 或现有 active wikilink。验证：

| 文件 | source_files_used | unsupported_claim_count | 验证 |
|---|---|---|---|
| wiki/sources/mcp-spec.md | raw/mcp-spec--raw--2026-05-07.md | 0 | ✅ 全部论断带 raw §X 引用 |
| wiki/sources/anthropic-effective-context-engineering.md | raw/anthropic-effective-context-engineering--raw--2026-05-07.md | 0 | ✅ 全部论断带 raw §X 引用 |
| wiki/concepts/mcp-tool-use.md | mcp-spec + harness-engineering-deep-eval | 0 | ✅ 全部论断带 wikilink + raw 章节引用 |
| wiki/concepts/context-engineering.md (v4) | anthropic-effective-context-engineering + harness-engineering-deep-eval + mcp-spec | 0 | ✅ akb_interpretation 段明示标注（§5 三 hub 边界）|
| wiki/concepts/harness-engineering.md (incr) | 未引入新论证 | 0 | ✅ 仅 link 增量 |

无 LLM 自编扩写；无 Karpathy 常识化补充；无 Lewis RAG paper / Karpathy CE tweet 等被 plan 排除的源。

---

## §9. 待写规则（"正文质量宪法" backlog）

C2 plan §"代码执行方向" 明示 "docs/AKB-2.0-* 标准主文档：除非 review 明确指出必须补'正文质量宪法'，否则本轮只在 C2 报告中记录规则缺口"。

本轮发现以下规则在 C2 实操中已被遵守，但**未在 docs/AKB-2.0-* 标准主文档中显式写下**：

| 规则缺口 | 当前实操 | 应升级到 |
|---|---|---|
| `gate_reason` ≤ 1 行 + ≤ 120 字（INTAKE-GATE §5.1 已有但散） | C2 4 个新页 gate_reason 实测 49-141 字节（中文按 char 远低于 120） | 整合进 PAGE-TEMPLATES §3.8 fm 短字段白名单 |
| 任何论证必须有 raw §X 或 wikilink 锚 | C2 4 个 active 全 0 unsupported | LINT 规则 BODY-CLAIM-PROVENANCE-MISSING 已有但需 CLI 实现 |
| WebFetch 入库内容必须先归档到 raw/ 后再写 source 页 | C2 2 个 raw + 2 个 source 严格分离 | 应在 INTAKE-GATE §6 特殊来源分流 加"webfetch"分类 |
| concept hub 升级需双源印证（不可单 source 升 hub） | CE 升 hub 用 anthropic-CE 主源 + NLM 报告 §一.2 印证 | 应在 PAGE-TEMPLATES §3.5 graph 贡献标准加"hub 升级双源条件" |

**处置**：以上 4 条规则缺口建议后续单开 micro-plan 升级到 docs/AKB-2.0-* 标准主文档。本轮不修。

---

## §10. C2 后续 Backlog 状态

### P0（阻塞）

无。

### P1（C1 高优先级）

| ID | C1 状态 | C2 状态 | 备注 |
|---|---|---|---|
| BL-C1-001 karpathy transcript / LLM concept 升级 | open | **deferred** | 无可靠 transcript；待用户提供本地材料 |
| BL-C1-002 MCP tool-use 缺概念页 | open | **closed** | mcp-spec + concept-mcp-tool-use 已建 |
| BL-C1-003 CE 缺专门 source | open | **closed** | anthropic-effective-context-engineering 已建；CE concept 升 hub |

### P2（C1 中优先级）— 本轮全部不动

| ID | 备注 |
|---|---|
| BL-C1-004 entity-claude-code | 待 P2 plan |
| BL-C1-005 design tokens governance / Code Connect MCP server | 待 P2 plan |
| BL-C1-006 entity-anthropic / entity-openai 等 | 待 P2 plan |
| BL-C1-007 LLM concept 上游单源 | 待 P2 plan（与 BL-C1-001 联动） |

### P3（C1 低优先级）— 本轮不动

| ID | 备注 |
|---|---|
| BL-C1-008 LLM frontmatter `related_concepts` 加 CE 直链 | cosmetic；2 跳合理 |

### C2 新增 backlog

| ID | 类别 | 描述 |
|---|---|---|
| BL-C2-001 | P2 | mcp-spec 未抓 spec/basic/authorization 子页（OAuth flow 完整） |
| BL-C2-002 | P2 | mcp-spec 未抓 client primitives 完整使用模式（Sampling/Elicitation） |
| BL-C2-003 | P3 | "正文质量宪法" 4 条规则缺口未升 docs/AKB-2.0-* 标准（详见 §9）|
| BL-C2-004 | P3 | concept-context-engineering Pending 节点 9 个（attention-budget / context-rot / compaction / agentic-memory / sub-agent-architecture / just-in-time-retrieval / rag / progressive-disclosure / prompt-engineering） |
| BL-C2-005 | P3 | concept-mcp-tool-use Pending 节点 12 个（entity-claude-code 等） |

---

## §11. Review 结论

verdict: **PASS_WITH_BACKLOG**

理由：
- C2 plan 范围严格遵守（只闭环 P1，不扩 P2/P3）
- BL-C1-002 / BL-C1-003 闭环；BL-C1-001 按用户决策 deferred 不假装完成
- 5 yes / 3 partial / 0 no（C1 是 4 yes / 4 partial），Q2 由 partial 推到 yes
- 全部内容 source-grounded（0 unsupported_claim；raw 归档完整；无 LLM 自编扩写；无 plan 排除源）
- agent 工程主线形成 HE/CE/MCP 三 hub 结构，concept-CE 升 hub
- Obsidian 阅读体验保持 `pending_user_visual_check` 不伪造通过
- 4 条"正文质量宪法"规则缺口记录在 §9 backlog，未越界改 docs/AKB-2.0-* 标准

下一步：
- 用户在 Obsidian 抽查 C2 新增 5 页阅读体验后，§4 项可由用户更新为 user-confirmed
- BL-C1-001 deferred 项待用户提供本地 transcript 单独闭环
- C3 阶段路线（如果走）由用户在 P2 entity 入库 / "正文质量宪法"规则升标准 / lint 实现 中择一开新 plan

---

## §12. 维护记录

| 日期 | 改动 | 作者 |
|---|---|---|
| 2026-05-07 | 初始本 C2 查询缺口闭环报告（承接 plan：AKB2.0 Phase C2 查询缺口闭环与正文质量修正）；闭环 BL-C1-002 / BL-C1-003；BL-C1-001 deferred；C1 → C2 query 复测 4 yes/4 partial → 5 yes/3 partial；4 条规则缺口记 §9 待升标准 | praise + Claude Code |
| 2026-05-07 | **Codex P1 finding 修复**（"MCP source-grounding gate is false"）— 1)`raw/mcp-spec--raw--2026-05-07.md` 补 §2 Participants 段（cardinality 原文 "Local MCP servers... single MCP client, whereas remote MCP servers... many MCP clients" + VS Code 实例段）+ §2 Lifecycle 示例 Step 1 完整 JSON（含 protocolVersion 2025-06-18 / clientInfo / serverInfo / notifications/initialized / elicitation: {} / tools: listChanged）+ 三大目的 + capability negotiation 含义；2) `wiki/sources/mcp-spec.md` 删 "Anthropic 主导/维护" 措辞（gate_reason / TLDR / 入选理由 §2 三处），改为 "modelcontextprotocol.io 上的开源标准"，Anthropic 关联通过 NLM 报告引用桥接明示；3) Codex 验收 grep 复跑：所有 protocolVersion/clientInfo/serverInfo/notifications/initialized/elicitation:/listChanged/cardinality 措辞在 raw 中均能追溯到 §132-173 / §50；4) unsupported_claim_count 仍 = 0 立即生效（修复后 raw 与 source 严格对齐） | praise + Claude Code |
