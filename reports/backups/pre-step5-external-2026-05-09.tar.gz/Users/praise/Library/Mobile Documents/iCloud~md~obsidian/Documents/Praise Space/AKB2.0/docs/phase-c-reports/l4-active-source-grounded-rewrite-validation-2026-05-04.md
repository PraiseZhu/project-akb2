---
title: AKB2.0 L4 Active source-grounded 重写 v2 — 验证报告 2026-05-04
doc_type: phase-c-report
phase: C-3-L4-quality-repair-v2
report_kind: l4_quality_repair_v2_validation
automation_layer: L4
not_active_promotion: false
report_date: 2026-05-04
document_status: ready
canonical: true
follows_up:
  - l4-active-pilot-validation-2026-05-04
  - l4-active-quality-repair-validation-2026-05-04
authoritative_for: phase_c3_l4_quality_repair_v2_2026_05_04
---

# AKB2.0 L4 Active source-grounded 重写 v2 — 验证报告

> 本报告承接 v1 quality_repair 报告 [[l4-active-quality-repair-validation-2026-05-04]];修复 v1 中 active 页"frontmatter 仍重 / 正文 LLM 推论扩写过多 / Obsidian 实际查看体验差 / source-grounding 不严"问题。
> 触发原因:用户在 Obsidian 实际打开 v1 active 后给的反馈("active 页面前屏大面积 YAML;正文论证密度低;内容更像 DB 记录")+ Plan v2 11 步全跑指令。

---

## §1. 背景

| 项 | 值 |
|---|---|
| 上游 plan | "AKB2.0 L4 Active 正文质量修复 + Obsidian 元数据收口 v2" |
| Plan mode 用户答案 | 答 1: C 同步重写 3 source + 4 新 active / 答 2: A Karpathy walkthrough 桥接 / 答 3: A 多点补丁 INTAKE-GATE + PAGE-TEMPLATES + LINT-RULES(GRAPH 不动)|
| v1 报告 | `docs/phase-c-reports/l4-active-quality-repair-validation-2026-05-04.md` |
| L4 manifest(本批追加 7 record)| `manifests/ingest/2026-05-04-l4-pilot.jsonl`(10 → 17 行)|
| Raw materials 验证使用 | `AKB/research/Harness Engineering 深度评估 - 研究报告 2026-04-21.md`(11K)+ `AKB/research/Jenny Wen 的 AI 设计观双视频合评 - 研究报告 2026-04-18.md`(15K)+ `docs/phase-b-reports/B1-001-karpathy-llm-talk-walkthrough.md` |
| reviewer | praise + assisted_by Claude Code |
| Karpathy active 升级路径 | 待 transcript 入库;当前为 walkthrough-grounded `evidence_provenance: bridging_source_grounded` + `graph_status: orphan_risk` |

---

## §2. v1 → v2 关键变化(用户反馈对照)

| 用户反馈 | v1 状态 | v2 修复 |
|---|---|---|
| Obsidian 前屏大面积 YAML | frontmatter 30+ 行,含长 `core_summary`(150+ 字)| `core_summary` 字段移除,改写到正文 ## TLDR;frontmatter ≤ 30 行 |
| 正文论证密度低,像摘要 | 9 节结构但每节多用 LLM 综述笔法 | 每段绑定 source 章节(如"NLM §一.2"/"walkthrough §Step 5.1");大量直接引用原话 |
| 内容像 DB 记录 + 短摘要 | `key_findings` / `gate_reason` 等长字段塞 frontmatter | 长内容下放正文;frontmatter 只做索引 |
| 后续概念解释不能靠 Opus 编 | v1 4 个新 concept/design 含大量 LLM 推论(OS kernel 映射 / 7 组件 → Claude Code 落地) | v2 严格 bridging-source-grounded;删除所有无 source 论断 |
| 应该先修标准再批量生成 active | v1 直接生成 7 active | v2 先补 3 标准(INTAKE-GATE §4 第 8 条 + PAGE-TEMPLATES §3.7 + LINT-RULES §11.2)再重写 7 active |

---

## §3. 3 标准 v2 补丁(Phase B)

### §3.1 INTAKE-GATE

新增 §4 第 8 条 source-grounding 硬门 + §4.1 4 类 claim 类型:

- **第 8 条**:active 正文中任何论证 / 解释 / 例子 / 类比必须可追溯到明确 source / evidence / 已有 active wikilink;LLM 只能组织和解释来源,不得无证据扩写
- **`evidence_provenance` 字段必填**:4 枚举之一(source_grounded / bridging_source_grounded / partial_source_grounded / inference_only);**inference_only 不允许 active**
- **§4.1 4 类 claim 类型**:source_fact / akb_interpretation / user_judgment / agent_draft;混淆视为最严重违反

### §3.2 PAGE-TEMPLATES

新增 §3.7 source-grounded body 结构与正文质量(5 子节):

- **§3.7.1 frontmatter 是索引,不是正文**:强制规则 — frontmatter 不得含超 1 句 narrative;`core_summary` 不再作 frontmatter 字段
- **§3.7.2 active 正文必须 source-grounded**:三原则 + `evidence_provenance` 字段 4 枚举
- **§3.7.3 8 节最小推荐结构**:TLDR / 证据地图 / 核心论点 / 论证解释 / 应用场景 / 适用边界 / 图谱关系 / 后续缺口
- **§3.7.4 正文质量量化标准**:source ≥ 1200 / concept-design ≥ 1800 中文字效 + ≥6-7 H2
- **§3.7.5 frontmatter "前屏" 反模式**:≤ 30 行硬上限

### §3.3 LINT-RULES

新增 §11.2 三规则域(共 10 条规则):

- **SOURCE-GROUNDED-***(4 条):MISSING-FIELD P1 / **INFERENCE-ONLY P0 阻断 active** / CLAIM-UNTAGGED P2 / AGENT-DRAFT-IN-FACT-SECTION P1
- **BODY-QUALITY-***(4 条):TOO-SHORT-SOURCE P1 < 1200 / TOO-SHORT-CONCEPT P1 < 1800 / MISSING-STRUCTURE P2 / NO-EVIDENCE-MAP P2
- **METADATA-WALL-***(2 条):FRONTMATTER-OVERSIZE P2 > 30 行 / **CORE-SUMMARY-IN-YAML P2 ✅ auto_fix**

3 标准均**保持 `document_status: ready`**;补丁不改主旨,只补执行口径。

---

## §4. 7 active source-grounded 重写矩阵

| 页面 | template | evidence_provenance | graph_status | source 桥接 | claim_type 主导 |
|---|---|---|---|---|---|
| `wiki/sources/karpathy-intro-to-llms.md` | source | bridging_source_grounded | **orphan_risk**(单 walkthrough)| `B1-001 walkthrough` | source_fact(walkthrough §Step 5.1 + §Step 9 严格收紧) |
| `wiki/sources/harness-engineering-deep-eval.md` | source | bridging_source_grounded | healthy | NLM 报告 11K(35 源)| source_fact 主导 + 少量明示 akb_interpretation |
| `wiki/sources/jenny-wen-ai-design-philosophy.md` | source | bridging_source_grounded | healthy | NLM 报告 15K(2 视频 + 49 源)| source_fact 主导(6 关键金句直接引原话)|
| `wiki/concepts/large-language-model.md` | concept hub | bridging_source_grounded | **orphan_risk**(单 karpathy 桥接)| karpathy walkthrough(间接)| 严格收紧到标签级 |
| `wiki/concepts/harness-engineering.md` | concept hub | bridging_source_grounded | healthy | NLM 报告 §一-§五 全引 | source_fact |
| `wiki/concepts/context-engineering.md` | concept cluster_center | bridging_source_grounded | **orphan_risk**(对照项 + 单源)| NLM 报告 §一.2 表 CE 列(对照项)| source_fact + 1 段明示 akb_interpretation |
| `wiki/designs/implementation-aware-design.md` | design memory | bridging_source_grounded | healthy | jenny NLM 报告 §3 + §9 | source_fact + 1 节明示 akb_interpretation |

**3 个 orphan_risk 节点**(karpathy + concept-llm + concept-ce):承认当前 source 桥接弱,标 graph_status 而非伪装 healthy。

---

## §5. v1 删除清单(LLM 推论清退)

按 v2 standard,以下 v1 内容**已从 active 删除**:

### karpathy
- OS kernel 5 要素映射表(CPU = LLM / RAM = context window / disk = RAG / syscall = tool use / multi-process = multi-agent)
- 三阶段训练具体数据(~10TB / 数千 H100 / GPT-4 ~$100M)
- Claude Code 工作流 7 组件映射表
- 2024-2026 工程发展预测段
- Karpathy 后续工作引用(nanoGPT / makemore / LLM101n)

### harness-eng
- 7 组件 → Claude Code 落地完整映射表
- "复合错误的累积机制"段(0.9^5 计算)
- "AKB2.0 自身 HE 化对照清单"段

### jenny-wen
- "反馈周期机制 days-weeks vs minutes 对比表"
- "同对话流融合机制"段

### concept-llm
- OS kernel 5 要素完整映射表
- 三阶段训练具体数据
- 推理机制 chain-of-thought 推论

### concept-he
- 7 组件 → Claude Code 落地完整映射表
- 复合错误累积机制段
- AKB2.0 自身 HE 化对照清单段

### concept-ce
- 6 项 CE 典型技术(RAG / chunking / re-ranking / context selection / compression / compaction)的具体定义 + 实现 + AKB2.0 关联
- toolbox/research 子区 CE 工程化段

### iad
- 反馈周期机制对比表(传统瀑布 / 敏捷 / Cowork)
- 同对话流融合机制段

**保留**:每页 ## 证据地图节明示 source 章节绑定;## AKB2.0 中的角色 节(若有)明示 `akb_interpretation` 标注。

---

## §6. 不变量自检

| 不变量 | 状态 | 证据 |
|---|---|---|
| 0 改 candidate | ✅ | candidate mtime 仍 May 3 |
| 0 改 toolbox/<active>/ | ✅ | `find toolbox -name "*.md" -newer L3` 输出空 |
| 0 接旧链路 / 0 LLM | ✅ | 纯手工 Write/Edit |
| 0 全库 status / page_status 迁移 | ✅ | 本批所有 active 仍 `status: active` |
| 3 标准只新增子节,不改主旨 | ✅ | INTAKE-GATE / PAGE-TEMPLATES / LINT-RULES 均保 `document_status: ready` |
| 至少 1 个非空 related_* | ✅ | 7 active 全部有 ≥ 1 条 |
| 无空 related_*: [] | ✅ | grep 验证 |
| 无嵌套审计对象(origin / l4_manifest_ref)| ✅ | grep 验证 |
| `evidence_provenance` 字段必填 | ✅ | 7 active 全部有 |
| 4 类 claim 分离 | ⚠️ PARTIAL | 7 active 中绝大多数段为 source_fact;少量 akb_interpretation 明示标注;agent_draft 0 段(因为 4 新 concept gate_reason 在 manifest 标 `gate_reason_authored_by: Claude Code (drafted)`,正文均 source-grounded)|
| `evidence_provenance: inference_only` 不出现 | ✅ | 7 active 全部 bridging_source_grounded |

---

## §7. 文件清单(本批 v2 修改/新增)

### 修改(11 文件)

```
docs/AKB-2.0-INTAKE-GATE.md          (新增 §4 第 8 条 + §4.1 + §13 修订)
docs/AKB-2.0-PAGE-TEMPLATES.md       (新增 §3.7 + §15 v1.3 修订)
docs/AKB-2.0-LINT-RULES.md           (新增 §11.2 + §18 v1.2 修订)
wiki/sources/karpathy-intro-to-llms.md           (v2 walkthrough-grounded 严格收紧重写)
wiki/sources/harness-engineering-deep-eval.md    (v2 NLM-grounded 重写)
wiki/sources/jenny-wen-ai-design-philosophy.md   (v2 NLM-grounded 重写)
wiki/concepts/large-language-model.md            (v2 hub 入口收紧重写)
wiki/concepts/harness-engineering.md             (v2 NLM-grounded 重写)
wiki/concepts/context-engineering.md             (v2 cluster_center 收紧重写)
wiki/designs/implementation-aware-design.md      (v2 NLM-grounded 重写)
manifests/ingest/2026-05-04-l4-pilot.jsonl       (追加 7 v2 record;10 → 17 行)
```

### 新增(1 文件)

```
docs/phase-c-reports/l4-active-source-grounded-rewrite-validation-2026-05-04.md  (本报告)
```

合计:**1 新建 + 11 修改 = 12 文件操作**;**0 删除**(v1 内容由 Edit 替换,Obsidian / Git 历史可查)。

---

## §8. 残余风险与下一步

### 残余风险

| 风险 | 评估 |
|---|---|
| Karpathy active `graph_status: orphan_risk`(单 walkthrough 桥接)| 中 — 用户答 2 选 A 已明示;待 transcript 升级;upgrade_pending 字段标记 |
| concept-llm `graph_status: orphan_risk`(单 karpathy 桥接)| 中 — hub 入口而非深度教科书;evidence 升级路径已写在升级路径节 |
| concept-ce `graph_status: orphan_risk`(对照项 + 单源)| 中 — 等专门 CE 主题 source 入库 |
| 4 新 concept/design gate_reason 由 Claude Code 草拟 | 低 — manifest 标 `gate_reason_authored_by: Claude Code (drafted)` + plan_default_3 授权;reviewer 在 /review 阶段可复核 |
| 3 标准被改动 | 低 — 用户 plan 答 3 明确允许;只新增子节;`status: ready` 保持 |
| **v2 自我命中 LINT P2**:`METADATA-WALL-FRONTMATTER-OVERSIZE`(7 active frontmatter 37-53 行,超 §3.7.5 ≤30 行硬上限)| **PARTIAL — 承认未达**:根因是 §3.6.2 推荐的"对象格式 `related_*`"(每条 4 行:target/relation/strength/evidence)+ 多关系字段 + future_questions 嵌套 = 30+ 行基础;不可在不牺牲对象格式或减少关系数的前提下满足。**P2 不阻断 active**(承接 LINT-RULES §11.2);留 v3 考虑放宽到 50 行,或允许对象格式 evidence 字段下放正文 ## 图谱关系 表(frontmatter 只保留 target/relation/strength) |
| **v2 标准内部冲突**:§3.7.5 ≤30 行 与 §3.6.2 对象格式推荐之间张力 | 低 — 本 v2 现实抉择:严格 source-grounding 优先于 frontmatter 行数;v3 应在 §3.7.5 / §3.6.2 / LINT-RULES META-WALL-FRONTMATTER-OVERSIZE 三处协调一致 |

### 下一步候选

1. **/review code** — Codex 复核本批 12 文件操作 + v2 标准补丁
2. **Karpathy transcript 入库** — 升级 karpathy + concept-llm 到 source_grounded
3. **专门 CE 主题 source 入库** — 升级 concept-ce 到 healthy + strong evidenced_by
4. **Anthropic / Martin Fowler / OpenAI / Stripe / Jenny Wen / Boris Cherny entity 页** — 把 pending 节点逐步 materialize
5. **L4 Pilot 第二批**(claude-code-skills / figma-eval / goal-driven / skill-description)— 在新 v2 标准下做(避免再走 v1 LLM 推论扩写老路)

---

## §10. Codex review followup fix(2026-05-05 追加)

### §10.1 Codex review 触发

2026-05-04 14:21Z 用户对本次 v2 工作 `/review code`,Codex 返回 **REQUIRES_CHANGES + 3 findings**(2 P1 + 1 P2):

| # | 严重性 | 标题 | 实证 |
|---|---|---|---|
| F1 | P1 | Karpathy 短板清单越过 walkthrough 证据 | karpathy:87 + concept-llm:69 含 multimodal / agent / 长 context / system 2 / security 5 项枚举,超出 walkthrough §Step 5.1 仅记标签的范围 |
| F2 | P1 | core_summary 新旧标准冲突会误判 active | PAGE-TEMPLATES §3 通用契约(line 86)+ §3.2.1 + §3.2.2 + §3.4 + 反模式表 5 处 + LINT-RULES TEMPLATE-NO-CORE-SUMMARY 旧 P1 与新 §11.2 METADATA-WALL-CORE-SUMMARY-IN-YAML P2 ✅auto_fix 内部冲突 |
| F3 | P2 | 结构 lint 漏报 5 个 active 缺核心论点节 | LINT-RULES §11.2 BODY-QUALITY-MISSING-STRUCTURE 字面要求 ## 核心论点;5 个 active(karpathy / concept-llm / concept-he / concept-ce / iad)用了别名(## 标签级主题清单 / ## 概念定义 / ## 设计原则陈述)未被 lint 接受 |

完整 result:`~/.claude/review-baselines/c9c2dd365172/result-20260504T142104Z.md`

### §10.2 修复 plan + plan review

写干净 plan 文件 `/Users/praise/.claude/plans/joyful-squishing-moonbeam.md`(L4 v2 Codex 3 Findings 修正);触发 `/review plan` → Codex **APPROVED**(0 findings / 0 residual risk / 4 检查面全 PASS)。

完整 plan review result:`~/.claude/review-baselines/c9c2dd365172/result-20260505T051447Z.md`

### §10.3 实施(2026-05-05 13:32Z)

**F1 修复**:
- `wiki/sources/karpathy-intro-to-llms.md` line 87 — 删 5 项短板枚举,改为"Talk 中 Karpathy 提及了 2023-11 视角下 LLM 的若干短板方向,但具体清单 / 每项的具体论证 / 例子 / 评估全部依赖 transcript;walkthrough-grounded 范围内不展开具体短板枚举"
- `wiki/concepts/large-language-model.md` line 69 — 删括号枚举,改为"具体短板项 / 完整清单需 transcript 升级(walkthrough-grounded 范围不展开具体枚举)"
- 验收:`rg -n "multimodal / agent\|长 context / system 2\|security 等方向" karpathy + concept-llm` 0 命中 ✓

**F2 修复**:
- `docs/AKB-2.0-PAGE-TEMPLATES.md`:line 86 frontmatter 模板 `core_summary:` 字段示例改为废弃注释指向正文 ## TLDR;line 145(§3.2.1 第 1 项)/ line 155(§3.2.2 表)/ line 204-205(§3.4 30 秒 5 答案)/ line 217(§3.4.2 反模式表)4 处 `core_summary` 引用全部改为正文 ## TLDR
- `docs/AKB-2.0-LINT-RULES.md`:line 147 `TEMPLATE-NO-CORE-SUMMARY` P1 改写为 `BODY-QUALITY-MISSING-TLDR`(检查 ^## TLDR 而非 frontmatter 字段);line 149 `TEMPLATE-SUMMARY-COPY` P2 改写为 `BODY-TLDR-COPY`
- 验收:`grep -E "^core_summary:" PAGE-TEMPLATES` 0 命中;`grep "TEMPLATE-NO-CORE-SUMMARY\|TEMPLATE-SUMMARY-COPY" LINT-RULES` 0 命中 ✓

**F3 修复**:
- `docs/AKB-2.0-LINT-RULES.md` `BODY-QUALITY-MISSING-STRUCTURE` 加模板别名子节(source 默认 ## 核心论点 / walkthrough-grounded ## 标签级主题清单 / concept ## 概念定义 / design ## 设计原则陈述 / synthesis ## 综合论点;Lint 按 template_type 接受对应 anchor section 之一)
- `docs/AKB-2.0-PAGE-TEMPLATES.md` §3.7.3 同步 alias 表注释
- `wiki/concepts/context-engineering.md` 补 ## 概念定义节(NLM §一.2 表 CE 列直接陈述,不超 source-grounded 边界)
- 验收:7 active 全部命中 anchor section 别名前缀(karpathy=## 标签级主题清单 / harness=## 核心论点 / jenny=## 核心论点 / concept-llm=## 概念定义 / concept-he=## 概念定义 / concept-ce=## 概念定义 / iad=## 设计原则陈述)✓

### §10.4 实施验收矩阵

| 项 | 状态 | 证据 |
|---|---|---|
| F1 验收 | pass | 5 项短板枚举 0 命中 |
| F2 验收 | pass | core_summary frontmatter 字段示例 0 + TEMPLATE-NO-CORE-SUMMARY 0 命中;改写规则可索引 |
| F3 验收 | pass | 7 active 全部命中 anchor section alias |
| 0 改 candidate | pass | mtime 仍 May 3 21:23-21:24 |
| 0 改 toolbox active | pass | `find toolbox -newer L3` 空 |
| 3 ready 标准 status:ready 保持 | pass | `grep "^status: ready"` 3 标准全部 |
| manifest 追加而非修改 | pass | 17 → 18 行(追加 1 codex_followup_fix record) |
| 5 已 PASS active 不动 | pass | harness / jenny / concept-he / concept-llm 主体 / iad 正文未触(只 concept-ce 补 ## 概念定义节 + concept-llm:69 单行替换 + karpathy:87 单段替换) |

### §10.5 残余风险(post-fix)

- F3 alias 规则现仅写在 LINT-RULES + PAGE-TEMPLATES 中,Lint CLI 实施前实际无强制;但 7 active 现已合规于该规则,未来 CLI 实施即可
- F1 修复后 karpathy 短板节内容更稀;符合 walkthrough-grounded 严格策略;待 transcript 升级后可补充
- v3 标准协调(§3.7.5 ≤30 行 vs §3.6.2 对象格式张力)未处理 — 留独立 plan
- 旧 active 全库 core_summary 迁移(H6)未处理 — 留独立 phase

---

## §9. 修订历史

| 日期 | 改动 | 作者 |
|---|---|---|
| 2026-05-04 | 初始本验证报告 — Phase A→D 第三轮 quality_repair v2(source-grounded);3 标准 v2 补丁 + 7 active 重写;严格按 plan v2 + plan mode 3 答执行;3 active orphan_risk 标注 vs 4 active healthy;不变量 PASS(claim_type 分离 partial)| praise + Claude Code |
| 2026-05-05 | **§10 Codex review followup fix 追加** — Codex 2026-05-04 14:21Z REQUIRES_CHANGES 3 findings(F1 P1 短板枚举 / F2 P1 core_summary 新旧冲突 / F3 P2 结构 lint 漏报)按 plan(plan review APPROVED)6 步实施完成;3 findings 全部 PASS;不变量保持 | praise + Claude Code |
