---
report_type: phase_d_lint_cli_run
report_id: lint-cli-v0.2-2026-05-08
date: 2026-05-08
operation_id: akb2-lint-2026-05-08T140706
tool: akb2-lint.py v0.2
baseline: v0.2 (15 active P0=0/P1=0/P2=0 2026-05-08 baseline)
scanned_count: 15
p0_count: 0
p1_count: 0
p2_count: 0
---

# AKB2.0 LINT CLI v0.2 Run Report

## 摘要

- 工具：`akb2-lint.py` v0.2（Python stdlib，无依赖）
- 位置：`.akb-runtime/lint/akb2-lint.py`
- 规则：18 条（all standards-backed）
- 扫描 active 页数：15
- baseline: v0.2 (15 active P0=0/P1=0/P2=0 2026-05-08 baseline)
- P0 findings：**0**
- P1 findings：**0**
- P2 findings：**0**

## 规则清单

| Rule ID | Severity | 上游标准 |
|---|---|---|
| METADATA-LONG-FIELD | P1 | INTAKE-GATE §5.1 |
| BODY-MAINTENANCE-LOG-OVERFLOW | P2 | INTAKE-GATE §5.2.1 |
| BODY-MAINTENANCE-LOG-VERBOSE | P2 | INTAKE-GATE §5.2.2 |
| TOOL-UNDERSTANDING-MISSING-STRUCTURE | P1 | PAGE-TEMPLATES §4.7 + INTAKE-GATE §4.3 |
| WIKI-TOOLS-CALL-CONTRACT-LEAK | P2 | INTAKE-GATE §4.3.3 + FOLDER-STRUCTURE §3.4 |
| BODY-QUALITY-MISSING-STRUCTURE | P1 | PAGE-TEMPLATES §3.7.3 + LINT-RULES §11.2 |
| SOURCE-GROUNDED-MISSING-FIELD | P1 | INTAKE-GATE §4 第 8 条 + LINT-RULES §11.2 |
| SOURCE-GROUNDED-INFERENCE-ONLY | P0 | INTAKE-GATE §4 第 8 条 不允许 inference_only active |
| SOURCE-KEY-FINDINGS-MISSING-FRONTMATTER | P1 | PAGE-TEMPLATES §4.2 H7 |
| SOURCE-KEY-FINDINGS-MISSING-PROSE | P2 | PAGE-TEMPLATES §4.2 H7 |
| GRAPH-ROLE-MISSING | P1 | GRAPH-LINKING §6.1 + PAGE-TEMPLATES §4.0 |
| GRAPH-ROLE-INVALID | P1 | GRAPH-LINKING §6.1(7 enum) |
| GRAPH-STATUS-INVALID | P2 | GRAPH-LINKING §6.2(3 enum) |
| ACTIVE-MISSING-RELATED | P1 | PAGE-TEMPLATES §3 active 必填 + GRAPH-LINKING §9.5 |
| NAMING-FILENAME-SLUG-MISMATCH | P1 | NAMING-CONVENTION §17 #5 |
| TEMPLATE-DIRECTORY-MISMATCH | P1 | PAGE-TEMPLATES §4.x 12 模板 |
| RELATED-FIELD-INVALID | P2 | GRAPH-LINKING §9.3(12 whitelist) |
| WIKI-TOOLS-TOOLBOX-PAIRING | P1 | PAGE-TEMPLATES §4.7 必须链接 |

## 扫描清单（active pages）

- ✅ `wiki/concepts/concept-context-engineering.md`
- ✅ `wiki/concepts/concept-harness-engineering.md`
- ✅ `wiki/concepts/concept-large-language-model.md`
- ✅ `wiki/concepts/concept-mcp-tool-use.md`
- ✅ `wiki/designs/implementation-aware-design.md`
- ✅ `wiki/sources/anthropic-effective-context-engineering.md`
- ✅ `wiki/sources/harness-engineering-deep-eval.md`
- ✅ `wiki/sources/jenny-wen-ai-design-philosophy.md`
- ✅ `wiki/sources/karpathy-intro-to-llms.md`
- ✅ `wiki/sources/mcp-spec.md`
- ✅ `wiki/tools/cc-akb-search.md`
- ✅ `wiki/tools/cc-executable-plan.md`
- ✅ `wiki/tools/cc-local-llm.md`
- ✅ `wiki/tools/cc-review.md`
- ✅ `wiki/tools/cc-skill-stocktake.md`

## P0 violations

**none**

## P1 violations

**none** ✅

## P2 violations

**none**
## 不变量

- CLI 不修改任何 wiki/** active 内容（read-only scan）
- CLI 不修改 standards doc / toolbox / FOLDER-STRUCTURE
- manifest 写入 `manifests/lint/`（per LINT-RULES §1.1）