---
report_type: phase_d_lint_cli_run
report_id: lint-cli-v0.3-2026-05-08
date: 2026-05-08
operation_id: akb2-lint-2026-05-08T192342
tool: akb2-lint.py v0.3
baseline: v0.2 (15 active P0=0/P1=0/P2=0 2026-05-08)
scanned_count: 19
p0_count: 0
p1_count: 0
p2_count: 0
---

# AKB2.0 LINT CLI v0.3 Run Report

## 摘要

- 工具：`akb2-lint.py` v0.3（Python stdlib，无依赖）
- 位置：`.akb-runtime/lint/akb2-lint.py`
- 规则：22 条（all standards-backed）
- 扫描 active 页数：19
- 扫描 raw/ 文件数：4
- 扫描 deprecated 页数：0
- baseline: v0.2 (15 active P0=0/P1=0/P2=0 2026-05-08)
- P0 findings：**0**
- P1 findings：**0**
- P2 findings：**0**

## 规则清单

| Rule ID | Severity | 上游标准 |
|---|---|---|
| METADATA-LONG-FIELD | P1 | INTAKE-GATE §5.1 |
| BODY-MAINTENANCE-LOG-OVERFLOW | P2 | INTAKE-GATE §5.2.1 |
| BODY-MAINTENANCE-LOG-VERBOSE | P2 | INTAKE-GATE §5.2.2 |
| TOOL-UNDERSTANDING-MISSING-STRUCTURE | P1 | PAGE-TEMPLATES §4.7 + INTAKE-GATE §4.3 |
| WIKI-TOOLS-CALL-CONTRACT-LEAK | P2 | INTAKE-GATE §4.3.3 + FOLDER-STRUCTURE §3.4 |
| BODY-QUALITY-MISSING-STRUCTURE | P1 | PAGE-TEMPLATES §3.7.3 + LINT-RULES §11.2 |
| SOURCE-GROUNDED-MISSING-FIELD | P1 | INTAKE-GATE §4 第 8 条 + LINT-RULES §11.2 |
| SOURCE-GROUNDED-INFERENCE-ONLY | P0 | INTAKE-GATE §4 第 8 条 不允许 inference_only active |
| SOURCE-KEY-FINDINGS-MISSING-FRONTMATTER | P1 | PAGE-TEMPLATES §4.2 H7 |
| SOURCE-KEY-FINDINGS-MISSING-PROSE | P2 | PAGE-TEMPLATES §4.2 H7 |
| GRAPH-ROLE-MISSING | P1 | GRAPH-LINKING §6.1 + PAGE-TEMPLATES §4.0 |
| GRAPH-ROLE-INVALID | P1 | GRAPH-LINKING §6.1(7 enum) |
| GRAPH-STATUS-INVALID | P2 | GRAPH-LINKING §6.2(3 enum) |
| ACTIVE-MISSING-RELATED | P1 | PAGE-TEMPLATES §3 active 必填 + GRAPH-LINKING §9.5 |
| NAMING-FILENAME-SLUG-MISMATCH | P1 | NAMING-CONVENTION §17 #5 |
| TEMPLATE-DIRECTORY-MISMATCH | P1 | PAGE-TEMPLATES §4.x 12 模板 |
| RELATED-FIELD-INVALID | P2 | GRAPH-LINKING §9.3(12 whitelist) |
| WIKI-TOOLS-TOOLBOX-PAIRING | P1 | PAGE-TEMPLATES §4.7 必须链接 |
| RAW-NO-WIKILINK | P2 | AKB-2.0-GRAPH-LINKING.md:L37（v0.3 新增）|
| ACTIVE-SLUG-NO-DATE | P2 | AKB-2.0-NAMING-CONVENTION.md:L39（v0.3 新增）|
| DEPRECATED-SUPERSEDED-BY | P1 | AKB-2.0-CONTENT-LIFECYCLE.md:L134（v0.3 新增）|
| WIKILINK-NO-RAW-PATH | P2 | AKB-2.0-GRAPH-LINKING.md:L367（v0.3 新增）|

## 扫描清单（active pages）

- ✅ `wiki/concepts/concept-agent-collaboration.md`
- ✅ `wiki/concepts/concept-context-engineering.md`
- ✅ `wiki/concepts/concept-harness-engineering.md`
- ✅ `wiki/concepts/concept-large-language-model.md`
- ✅ `wiki/concepts/concept-mcp-tool-use.md`
- ✅ `wiki/concepts/concept-plan-and-execute.md`
- ✅ `wiki/designs/implementation-aware-design.md`
- ✅ `wiki/sources/anthropic-effective-context-engineering.md`
- ✅ `wiki/sources/anthropic-multi-agent-research-system.md`
- ✅ `wiki/sources/harness-engineering-deep-eval.md`
- ✅ `wiki/sources/jenny-wen-ai-design-philosophy.md`
- ✅ `wiki/sources/karpathy-intro-to-llms.md`
- ✅ `wiki/sources/langchain-plan-and-execute-agents.md`
- ✅ `wiki/sources/mcp-spec.md`
- ✅ `wiki/tools/cc-akb-search.md`
- ✅ `wiki/tools/cc-executable-plan.md`
- ✅ `wiki/tools/cc-local-llm.md`
- ✅ `wiki/tools/cc-review.md`
- ✅ `wiki/tools/cc-skill-stocktake.md`

## v0.3 扫描清单（raw/ 文件）

- ✅ `raw/anthropic-effective-context-engineering--raw--2026-05-07.md`
- ✅ `raw/anthropic-multi-agent-research-system--raw--2026-05-08.md`
- ✅ `raw/langchain-plan-and-execute-agents--raw--2026-05-08.md`
- ✅ `raw/mcp-spec--raw--2026-05-07.md`

## v0.3 扫描清单（deprecated pages）

- （当前无 deprecated 页面）

## P0 violations

**none**

## P1 violations

**none** ✅

## P2 violations

**none**
## 不变量

- CLI 不修改任何 wiki/** active 内容（read-only scan）
- CLI 不修改 standards doc / toolbox / FOLDER-STRUCTURE
- manifest 写入 `manifests/lint/`（per LINT-RULES §1.1）
- v0.3 report 写入 `docs/phase-d-reports/`（Census Week Phase D 产出）