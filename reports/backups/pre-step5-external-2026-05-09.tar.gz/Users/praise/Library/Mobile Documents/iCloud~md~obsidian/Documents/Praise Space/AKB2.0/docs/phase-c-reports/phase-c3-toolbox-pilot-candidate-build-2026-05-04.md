---
title: Phase C-3 工具库首批工具候选五件套建档报告
doc_type: phase-c-report
phase: C-3
report_kind: toolbox_pilot_candidate_build
automation_layer: L0_documentation_only
not_active_promotion: true
report_date: 2026-05-04
slugs_in_round:
  - cc-akb-search
  - cc-executable-plan
  - cc-local-llm
  - cc-review
  - cc-skill-stocktake
---

# Phase C-3 工具库首批工具候选五件套建档报告 — 2026-05-04

> 本报告记录 C-3 把 C-2 排名 top 5 的 Codex skill 推进到"可审查的工具候选档案"的过程。**所有产出仍为 candidate**,不可作为生产调用入口。`review-result-writer` 按 plan §非目标本轮**不**纳入。

---

## §1 输入

- C-2 ranking manifest:`manifests/toolbox-ranking/2026-05-04-toolbox-candidate-ranking.jsonl`
- C-2 报告:`docs/phase-c-reports/phase-c2-toolbox-candidate-ranking-2026-05-04.md`
- 选取规则:从 ranking pilot_next 中按 rank 顺序取前 5(全部为 codex_skill,全部 phase_b_shadow_match)

| rank | slug | score | kind | workspace_version |
|---|---|---|---|---|
| 1 | `cc-akb-search` | 61 | codex_skill | `sha256:b669380de8a0 mtime:2026-04-26` |
| 2 | `cc-executable-plan` | 61 | codex_skill | `sha256:69364def87af mtime:2026-04-28` |
| 3 | `cc-local-llm` | 61 | codex_skill | `sha256:b8050d3c236a mtime:2026-04-26` |
| 4 | `cc-review` | 61 | codex_skill | `sha256:d6e7ce54dce6 mtime:2026-04-29` |
| 5 | `cc-skill-stocktake` | 61 | codex_skill | `sha256:52d10db4618d mtime:2026-04-26` |

---

## §2 五件套覆盖矩阵

每个 slug 必须有 5 个文件;25/25 全部生成。

| slug | wiki/tools | toolbox/tools | toolbox/registry | toolbox/interfaces | toolbox/evals | 五件套齐 |
|---|---|---|---|---|---|---|
| cc-akb-search | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| cc-executable-plan | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| cc-local-llm | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| cc-review | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| cc-skill-stocktake | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |

---

## §3 字段缺口审计

按 plan §"接口与数据合约" 必须字段逐项核对。

### interface 必填字段(每行 5/5 命中)

`slug` / `asset_type` / `invocation_type` / `status` / `automation_allowed` / `automation_tier` / `risk_level` / `side_effects` / `workspace_path` / `workspace_owner` / `workspace_version` / `backlink_status` / `registry_path` / `eval_path` / `wiki_understanding_path` / `tool_card_path`

### eval 必填字段(每行 5/5 命中)

`eval_level: L0` / `last_run_status: not_run` / `automation_allowed: false` / `l1_fixture_plan` / `c4_smoke_candidate`

### 已知字段缺口(写入报告而非现场补)

- 标准文档(`AKB-2.0-TOOL-INTERFACE-SCHEMA` / `AKB-2.0-TOOL-EVAL-RULES`)未定义 `c4_smoke_candidate` 字段,但 C-3 plan 明示需要 → **建议**将该字段纳入下一版 `TOOL-EVAL-RULES`(本轮不改标准)
- `cc-skill-stocktake` 的 SKILL.md 信息密度低(只描述 trigger / safety,缺具体 subagent 调度参数) → eval 标 `needs_l1_fixture_design`,C-4 前需补

---

## §4 backlink_status 状态

| slug | backlink_status | workspace 侧 SKILL.md 内是否含 `[[AKB2.0/...]]` 反链 |
|---|---|---|
| cc-akb-search | **pending** | 无 |
| cc-executable-plan | **pending** | 无 |
| cc-local-llm | **pending** | 无 |
| cc-review | **pending** | 无 |
| cc-skill-stocktake | **pending** | 无 |

5/5 全 `pending`。本轮**不**修改 workspace 侧 SKILL.md 注入反链(plan §非目标)。C-4 前需要单独决定:
- 选项 A:在 workspace SKILL.md 头部加 `<!-- akb-backlink: ../../wiki/tools/<slug>.md -->` 类轻量标记 → backlink_status 升 `ok`
- 选项 B:维持 `pending`,C-4 后再评估
- ❌ 不允许填 `vendor_locked`(plan §接口与数据合约 明示)

---

## §5 C-4 推荐先跑批次

按 eval 中 `c4_smoke_candidate` 字段 + 风险面 + 外部依赖综合判断:

### 第一批(推荐 C-4 先跑 2-3 条)

| 优先 | slug | 理由 |
|---|---|---|
| 1 | `cc-akb-search` | read_only + 已有 5 query 对照基线 + 是其它 skill 的检索前置依赖 |
| 2 | `cc-review` | read_only + 现有 wrapper 可复用 + 跨端协作核心 |
| 3 | `cc-executable-plan` | 仅 write_local 副作用 + 已有 dry-run + 模板 drift check 内置 |

### 第二批(C-4 第一批通过后再跑)

| 优先 | slug | 延后理由 |
|---|---|---|
| 4 | `cc-local-llm` | 依赖本地 Ollama 服务可达 + 模型已 pulled,外部依赖较多 |
| 5 | `cc-skill-stocktake` | 标 `needs_l1_fixture_design`,先补 fixture 设计 + subagent 调度需要 token quota 评估 |

---

## §6 不变量自检

- [x] 25/25 文件全部 `status: candidate`
- [x] 0 文件含 `status: active`
- [x] 5/5 interface 含 `automation_allowed: false`
- [x] 0 文件含 `automation_allowed: true`
- [x] 5/5 interface 含 `backlink_status` 字段
- [x] 5/5 eval 含 `eval_level: L0` + `last_run_status: not_run`
- [x] 5/5 registry 含完整路径字段(`tool_card_path` / `wiki_understanding_path` / `interface_path` / `eval_path`)
- [x] 0 文件读写 `~/.codex/skills/`(workspace 侧只读)
- [x] 0 自动化调用入口被创建

---

## §7 是否允许进入 C-4

**允许进入 C-4 L1 smoke/eval**,但有以下前置条件:

1. C-4 只允许跑 §5 第一批 3 条(cc-akb-search / cc-review / cc-executable-plan)
2. 每条 skill 跑 L1 之前必须先建对应 fixture(`tests/baseline-*` 路径见每个 eval 文件的 `l1_fixture_plan`)
3. `cc-skill-stocktake` 不进 C-4 第一批,先补 fixture 设计文档
4. `cc-local-llm` 不进 C-4 第一批,先确认 Ollama 服务健康
5. C-4 任一 skill 跑通 L1 才能进 Tool Intake Gate;`automation_allowed` 仍保持 false 直到 L2(自动化授权)单独评估

---

## §8 执行边界确认

- ✅ workspace 侧 5 个 SKILL.md 只读取 sha256 + mtime,未修改
- ✅ 旧 AKB / 旧 toolbox.db / LaunchAgent / cron / hooks / MCP 配置全部未碰
- ✅ AKB2.0 工具标准文档未改(标准缺口在 §3 写入报告)
- ✅ live runtime / 密钥 / 外部服务 / 持久配置未碰
- ✅ `review-result-writer` wrapper 按 plan §非目标本轮**不**纳入

---

## §9 链接

- C-3 register manifest:[[../../manifests/toolbox-c3/2026-05-04-c3-tool-candidate-register|2026-05-04-c3-tool-candidate-register.jsonl]]
- C-2 上游报告:[[phase-c2-toolbox-candidate-ranking-2026-05-04|Phase C-2 报告]]
- 5 个 wiki/tools:[[../../wiki/tools/cc-akb-search]] / [[../../wiki/tools/cc-executable-plan]] / [[../../wiki/tools/cc-local-llm]] / [[../../wiki/tools/cc-review]] / [[../../wiki/tools/cc-skill-stocktake]]
- 5 个 toolbox/tools:[[../../toolbox/tools/cc-akb-search]] / [[../../toolbox/tools/cc-executable-plan]] / [[../../toolbox/tools/cc-local-llm]] / [[../../toolbox/tools/cc-review]] / [[../../toolbox/tools/cc-skill-stocktake]]
- 5 个 registry:[[../../toolbox/registry/cc-akb-search]] / [[../../toolbox/registry/cc-executable-plan]] / [[../../toolbox/registry/cc-local-llm]] / [[../../toolbox/registry/cc-review]] / [[../../toolbox/registry/cc-skill-stocktake]]
- 5 个 interfaces:[[../../toolbox/interfaces/cc-akb-search]] / [[../../toolbox/interfaces/cc-executable-plan]] / [[../../toolbox/interfaces/cc-local-llm]] / [[../../toolbox/interfaces/cc-review]] / [[../../toolbox/interfaces/cc-skill-stocktake]]
- 5 个 evals:[[../../toolbox/evals/cc-akb-search]] / [[../../toolbox/evals/cc-executable-plan]] / [[../../toolbox/evals/cc-local-llm]] / [[../../toolbox/evals/cc-review]] / [[../../toolbox/evals/cc-skill-stocktake]]
