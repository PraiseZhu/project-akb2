---
title: AKB 2.0 工具库状态快照目录
akb_layer: index
doc_type: index
template_type: manifests-index
document_status: ready
canonical: true
updated_at: 2026-05-04
---

# AKB 2.0 工具库状态快照目录

> **本目录用于每周工具库状态快照**(`<YYYY-MM-DD>-toolbox-status.md`),不是 active 内容区。
> 快照是 manifest / control plane,**不决定** active / **不迁移**旧工具 / **不修改**真实工具资产。
> 真实工具资产在 Claude Code workspace,见 [[../../toolbox/00-Index|工具库控制台]]。

---

## 用途

- 记录 AKB2.0 工具库的**周度状态**(asset_type 分布 / lifecycle 状态 / workspace_path 覆盖率 / eval / freshness / automation 风险面)
- 作为**审计快照**:每周一份手工或半自动生成的快照,留痕便于追溯
- 作为**维护优先级输入**:每份快照含"下一步优先级"指导后续动作
- 作为**控制台数据源**:[[../../toolbox/00-Index|toolbox/00-Index]] 引用最新快照

---

## 命名规范

`<YYYY-MM-DD>-toolbox-status.md`(承接 [[../../docs/AKB-2.0-NAMING-CONVENTION|NAMING-CONVENTION]] §4 时间末尾硬规则)

例:
- `2026-05-04-toolbox-status.md` — 第一份手工基线
- `2026-05-11-toolbox-status.md` — 后续每周(若启动)

---

## frontmatter 必填字段

```yaml
title: AKB2.0 工具库状态快照 <YYYY-MM-DD>
doc_type: manifest
manifest_type: toolbox_status
snapshot_status: manual_baseline | manual | semi_auto | auto
snapshot_date: <YYYY-MM-DD>
generated_by: manual | <scanner-name>
source_scope: obsidian_control_plane_only | obsidian_plus_workspace_scan
workspace_root_status: unknown | candidate_found | confirmed
scan_mode: none | readonly | full
data_confidence: partial | high
automation_status: not_implemented | implemented
```

字段值语义见各份快照内的"状态值语义"章节(承接 plan §接口与数据合约)。

---

## 边界(快照不是 active 内容页)

- ❌ 快照**不**适用 PAGE-TEMPLATES `future_questions` / `gate_reason` / `gate_decision` 字段(那是 active 内容页要求)
- ❌ 快照**不**进入工具库 active 统计(它本身是 manifest)
- ❌ 快照**不**决定任何工具 active / stale / broken(只记录现状和待确认项)
- ❌ 快照**不**迁移旧工具 / **不**修改真实工具资产
- ✅ 快照可被 reviewer 引用作为"当时点状态证据"
- ✅ 快照可触发后续优先级动作(如 P0 确认 workspace 根目录 / P1 建样本 / P2 计划扫描器)

---

## 现有快照

| 日期 | 文件 | 摘要 |
|------|------|------|
| 2026-05-04 | [[2026-05-04-toolbox-status|2026-05-04 工具库状态快照]] | 手工基线;`workspace_root_status: unknown` / 0 active 工具 / 5+3 子区 0 条目 / 旧库 4413 条仅历史参考 |

---

## 相关标准

| 标准 | 用途 |
|------|------|
| [[../../docs/AKB-2.0-AUTOMATION-BOUNDARY|AUTOMATION-BOUNDARY]] §6.2 | manifest 路径标准(本目录是 toolbox-status 类型,与 ingest/migrate/lint/archive 等并列)|
| [[../../docs/toolbox/AKB-2.0-TOOLBOX-CONTRACT|TOOLBOX-CONTRACT]] | 工具库总契约 |
| [[../../docs/toolbox/AKB-2.0-TOOL-LIFECYCLE|TOOL-LIFECYCLE]] | 8 状态机 |
| [[../../docs/toolbox/AKB-2.0-TOOL-EVAL-RULES|TOOL-EVAL-RULES]] | L0-L4 证据 + freshness |
| [[../../toolbox/00-Index|工具库控制台]] | 引用最新快照 |

---

## 修订历史

| 日期 | 改动 | 作者 |
|------|------|------|
| 2026-05-04 | 初始建立目录索引;首份快照 2026-05-04-toolbox-status.md;明示快照是 manifest 不是 active 内容页 | Claude Code |
