---
report_type: maintenance_p2_cleanup_and_baseline_freeze
report_id: active-maintenance-p2-clean-baseline-2026-05-08
date: 2026-05-08
operation: BODY-MAINTENANCE-LOG-VERBOSE P2 清零
plan: AKB2.0 最短路径收口 v2.1 — Stage 1
lint_before: P0=0 / P1=0 / P2=21
lint_after: P0=0 / P1=0 / P2=0
lint_report_before: docs/phase-c-reports/lint-cli-v0.2-2026-05-08T001657.md
lint_report_after: docs/phase-c-reports/lint-cli-v0.2-2026-05-08T011944.md
lint_manifest_after: manifests/lint/2026-05-08T011944-v0-2.jsonl
files_touched: 10
p2_cleared: 21
---

# Active 维护记录 P2 清零 + Baseline Freeze

日期：2026-05-08  
执行人：Claude Code  
依据：AKB2.0 最短路径收口 v2.1（plan review APPROVED 2026-05-07T170513Z）

---

## §1. 执行摘要

- **目标**：清零 21 个 `BODY-MAINTENANCE-LOG-VERBOSE` P2（维护记录单行 >200 chars）
- **方法**：对每条命中行压缩至 ≤200 chars，保留 日期 + 动作类别 + 依据 plan/report + 关键元数据；细节可查原 phase 报告
- **结果**：P2=21 → P2=0；P0/P1 全程为 0
- **约束合规**：仅改 `## 维护记录` 表格行，未改正文论点/frontmatter/source evidence/graph relation

---

## §2. Before/After 对比表

| 文件 | P2 命中数 | 压缩行（before 字符数 → after 字符数） |
|---|---|---|
| `wiki/concepts/concept-context-engineering.md` | 2 | 253→172；663→194 |
| `wiki/concepts/concept-harness-engineering.md` | 3 | 249→108；749→172；384→158 |
| `wiki/concepts/concept-large-language-model.md` | 2 | 399→147；723→172 |
| `wiki/concepts/concept-mcp-tool-use.md` | 1 | 336→187 |
| `wiki/designs/implementation-aware-design.md` | 2 | 339→131；798→172 |
| `wiki/sources/anthropic-effective-context-engineering.md` | 1 | 455→196 |
| `wiki/sources/harness-engineering-deep-eval.md` | 5 | 宽列格式整体重排；原 669/685/733/768/887 → 全部 ≤200 |
| `wiki/sources/jenny-wen-ai-design-philosophy.md` | 2 | 389→159；901→170 |
| `wiki/sources/karpathy-intro-to-llms.md` | 2 | 391→171；908→170 |
| `wiki/sources/mcp-spec.md` | 1 | 429→185 |
| **合计** | **21** | — |

---

## §3. Lint 前后对照

| 指标 | Before (2026-05-08T001657) | After (2026-05-08T011944) |
|---|---|---|
| P0 violations | 0 | 0 |
| P1 violations | 0 | 0 |
| P2 violations | 21 | 0 |
| 扫描页数 | 15 | 15 |
| 规则数 | 18 | 18 |

---

## §4. 触碰文件清单

**仅改 `## 维护記錄` 段，未改其他章节**：

1. `wiki/concepts/concept-context-engineering.md`
2. `wiki/concepts/concept-harness-engineering.md`
3. `wiki/concepts/concept-large-language-model.md`
4. `wiki/concepts/concept-mcp-tool-use.md`
5. `wiki/designs/implementation-aware-design.md`
6. `wiki/sources/anthropic-effective-context-engineering.md`
7. `wiki/sources/harness-engineering-deep-eval.md`
8. `wiki/sources/jenny-wen-ai-design-philosophy.md`
9. `wiki/sources/karpathy-intro-to-llms.md`
10. `wiki/sources/mcp-spec.md`

---

## §5. Baseline Freeze（v0.2 Clean State — 2026-05-08）

> **条件**：lint P2=0 成立，写入本段。

### 5.1 Active 页面清单（15 页）

| slug | template_type | graph_role | graph_status |
|---|---|---|---|
| concept-context-engineering | concept | hub | healthy |
| concept-harness-engineering | concept | hub | healthy |
| concept-large-language-model | concept | hub | orphan_risk |
| concept-mcp-tool-use | concept | hub | healthy |
| implementation-aware-design | design | design-memory | healthy |
| anthropic-effective-context-engineering | source | evidence | healthy |
| harness-engineering-deep-eval | source | evidence | healthy |
| jenny-wen-ai-design-philosophy | source | evidence | healthy |
| karpathy-intro-to-llms | source | evidence | orphan_risk |
| mcp-spec | source | evidence | healthy |
| cc-akb-search | tool-understanding | leaf | — |
| cc-executable-plan | tool-understanding | leaf | — |
| cc-local-llm | tool-understanding | leaf | — |
| cc-review | tool-understanding | leaf | — |
| cc-skill-stocktake | tool-understanding | leaf | — |

### 5.2 Template 分布

| template_type | 数量 | slug 列表 |
|---|---|---|
| concept | 4 | concept-context-engineering, concept-harness-engineering, concept-large-language-model, concept-mcp-tool-use |
| design | 1 | implementation-aware-design |
| source | 5 | anthropic-effective-context-engineering, harness-engineering-deep-eval, jenny-wen-ai-design-philosophy, karpathy-intro-to-llms, mcp-spec |
| tool-understanding | 5 | cc-akb-search, cc-executable-plan, cc-local-llm, cc-review, cc-skill-stocktake |

### 5.3 Lint v0.2 状态

- 最新 lint run：`lint-cli-v0.2-2026-05-08T011944.md`
- P0=0 / P1=0 / P2=0
- 18 条规则全部 PASS
- JSONL manifest：`manifests/lint/2026-05-08T011944-v0-2.jsonl`

### 5.4 Toolbox Matrix 状态

- 5 个 tool-understanding 页面均为 `status: active`
- 最后一次结构 lint：`p2-toolbox-structure-lint-v1-2026-05-08.md`（APPROVED）
- toolbox/ 目录对应 5 工具 card 已存在且与 wiki/tools/ 1:1 配对

### 5.5 `cc-akb-search` Split 状态

- `wiki/tools/cc-akb-search.md`：`status: active`（wiki active gate PASS 2026-05-07）
- toolbox/tools/cc-akb-search：对应 card 存在
- MCP mount（`mcp__akb-search`）：**尚未挂载**（已知阻塞，非本计划处理范围）
- 后续启动条件：用户明确启用意图

### 5.6 Known Deferred（不影响本 freeze）

| 项 | 状态 | 启动条件 |
|---|---|---|
| LINT CLI v0.3 实现 | 未启动 | Stage 2 standards census ≥3 条候选规则 |
| BL-D-014 concept census | 待 Stage 2 执行 | Stage 2 akb2-census-week 报告 |
| 内容扩展 / 概念建页 | 未启动 | Stage 2 census 完成 + 用户确认 |
| `mcp__akb-search` MCP 挂载 | 已知阻塞 | 用户明确启用意图 |
| `concept-large-language-model` orphan_risk | 已知 | 单 source 桥接，非阻塞 |
| `karpathy-intro-to-llms` orphan_risk | 已知 | 桥接源，非阻塞 |

---

## §6. 接续

- Stage 2（standards census + BL-D-014 concept census）在 Stage 1 review APPROVED 后启动
- 输出：`docs/phase-d-reports/akb2-census-week-2026-05-08.md`
