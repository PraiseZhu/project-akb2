---
manifest_type: toolbox-structure-lint-rules
version: v1
scope: current_5_tools
created_at: 2026-05-08
phase: p2-toolbox-structure-lint-v1
automation_boundary: §6.2 registered subdirectory
lint_kind: structure
note: v1 = v0 + r04 false-negative fix + --strict mode + 3 new r04 fixtures。与 akb2-lint.py 正交。
---

# AKB2.0 Toolbox Structure Lint Rules v1

## v1 vs v0 变更摘要

| 变更 | 类型 | 说明 |
|------|------|------|
| r04 eval 侧 false-negative 修复 | bug fix | v0: 缺 workspace_version 字段时静默跳过；v1: active 工具 → hard_fail；blocked candidate → handoff |
| --strict 模式 | 新增 | exit 1 当 fixture expected≠actual 数 > 0 OR hard_fail 数 > 0；默认 exit 0 不变 |
| 3 个新 r04 fixture | 新增 | r04-eval-workspace-version-missing / r04-eval-workspace-version-drift / r04-blocked-candidate-eval-missing |
| fixture 总数 | 8 → 11 | 新增 3 个 r04 boundary cases |

**v0 规则 r01-r03, r05-r08 全部不变。**

---

## 规则一览

| rule_id | 名称 | severity | auto_decidable | v1 变更 |
|---------|------|----------|----------------|---------|
| r01 | five_file_present | hard_fail | ✓ | 无 |
| r02 | status_consistency | **handoff** | ✗ | 无 |
| r03 | workspace_path_exists | hard_fail | ✓ | 无 |
| r04 | sha256_match | hard_fail | ✓ | **v1 fix**: eval 侧字段缺失 → active=hard_fail / candidate=handoff |
| r05 | backlink_linked | hard_fail | ✓ | 无 |
| r06 | active_needs_l1 | hard_fail | ✓ | 无 |
| r07 | eval_freshness | **handoff** | ✗ | 无 |
| r08 | automation_allowed_false | hard_fail（P0） | ✓ | 无 |

---

## r04 v1 修复详情（核心变更）

### v0 问题（false-negative）

```bash
# v0 r04_sha256_match.sh 行 57（存在 false-negative）:
if [ -n "$eval_sha" ] && [ "$eval_sha" != "$actual_sha" ]; then
  # 仅当 eval_sha 非空时才检查 → 字段缺失时静默跳过
fi
```

**后果**：eval 文件中 `workspace_version` 字段缺失时，r04 不报告任何问题，产生 false-negative。

### v1 修复

```bash
# v1 r04_sha256_match.sh — 字段缺失时根据 toolbox_status 分支
if [ -z "$eval_sha" ]; then
  if [ "$iface_status" = "active" ]; then
    failures="${failures}eval:workspace_version_field_absent "  # → hard_fail
  else
    # blocked candidate → handoff（预期状态，P1a 例外）
    emit_finding "$slug" "r04" "handoff" "hard_fail" ... "blocked candidate (status=$iface_status)..."
    return
  fi
fi
```

**修复逻辑**：
- `iface_status = "active"` + eval 字段缺失 → `hard_fail`（双侧检查强制）
- `iface_status != "active"` (如 `candidate`) + eval 字段缺失 → `handoff`（cc-akb-search 等 blocked 候选工具预期状态）

### 当前 5 工具 v1 r04 预期结果

| 工具 | eval workspace_version 字段 | v1 r04 预期 |
|------|---------------------------|------------|
| cc-executable-plan | 有（sha 应匹配） | pass |
| cc-review | 有（sha 应匹配） | pass |
| cc-local-llm | 有（sha 应匹配） | pass |
| cc-skill-stocktake | 有（sha 应匹配） | pass |
| cc-akb-search | 无（blocked candidate） | **handoff**（预期，P1a 例外） |

**当前 5 工具 v1 lint 预期：0 新 hard fail，cc-akb-search r04 产生 1 个 handoff（blocked exception）。**

---

## --strict 模式（新增）

```bash
bash run-lint.sh --strict
```

| 条件 | exit code |
|------|-----------|
| fixture expected≠actual 数 = 0 AND hard_fail 数 = 0 | exit 0 |
| fixture expected≠actual 数 > 0 | exit 1 |
| hard_fail 数 > 0（current 5 tools） | exit 1 |

**默认（无 --strict）**：exit 0 不变，lint 只 detect 不 block。

---

## Fixture 总览（11 cases）

### v0 继承（8 cases，规则不变）

| fixture | trigger rule | expected |
|---------|-------------|---------|
| r01-missing-fivefile | r01 | fail |
| r02-split-status | r02 | handoff |
| r03-workspace-missing | r03 | fail |
| r04-sha-drift | r04 | fail |
| r05-backlink-pending | r05 | fail |
| r06-active-l0 | r06 | fail |
| r07-eval-stale | r07 | handoff |
| r08-automation-true | r08 | fail |

### v1 新增（3 cases，r04 boundary）

| fixture | trigger rule | expected | 说明 |
|---------|-------------|---------|------|
| r04-eval-workspace-version-missing | r04 | **fail** | active + eval 字段缺失 → v1 fix 捕获 |
| r04-eval-workspace-version-drift | r04 | **fail** | active + eval sha 错误 → v0/v1 均捕获 |
| r04-blocked-candidate-eval-missing | r04 | **handoff** | candidate + eval 字段缺失 → 预期 handoff |

---

## 例外列表

| rule | 工具 | 条件 | verdict | 原因 |
|------|------|------|---------|------|
| r05 | cc-akb-search | blocked candidate | handoff | mcp__akb-search 未 mount；backlink_status: pending 预期 |
| r04 | cc-akb-search | eval workspace_version 字段缺失 | handoff | blocked candidate；eval 字段缺失预期；P1a 例外 |

---

## v0 baseline sha256（byte-identical 守门）

v1 实施期间，v0 目录必须 byte-identical（lint 只读守门）：

- `run-lint.sh`：`6768f454e4baecba831705267a530c89927848403b3268c184adce6e9ede96b7`
- `r04_sha256_match.sh`：`f10364e5c874f5790af0a869b727167220e90cfe7cbb76458c68a3376e024c2d`

---

*本 manifest 与 `akb2-lint.py`（content quality lint）正交：akb2-lint.py 检查内容字段（BODY-MAINTENANCE-LOG / GRAPH-ROLE / SOURCE-* 等），本 manifest 只检查 5 件套结构字段合规性，不检查内容字段，不调用、不修改 akb2-lint.py。*
