---
title: AKB2.0 工具库状态快照 2026-05-04
doc_type: manifest
manifest_type: toolbox_status
snapshot_status: manual_baseline
snapshot_date: 2026-05-04
generated_by: manual
source_scope: obsidian_control_plane_only
workspace_root_status: unknown
scan_mode: none
data_confidence: partial
automation_status: not_implemented
---

# AKB2.0 工具库状态快照 2026-05-04(手工基线)

> 本快照是 **manifest / control plane**,不是 active 内容页。
> 不适用 PAGE-TEMPLATES `future_questions / gate_reason / gate_decision`。
> 不决定任何工具 active / stale / broken,只记录现状 + 待确认项。
> 真实工具资产在 Claude Code workspace,见 [[../../toolbox/00-Index|工具库控制台]]。

---

## 状态值语义(本份快照适用)

| 值 | 含义 |
|---|------|
| `observed` | 从现有文件可直接确认 |
| `historical_reference` | 来自旧工具库,只能参考,**不**作为 AKB2.0 当前状态权威 |
| `unknown` | 当前未扫描或未确认 |
| `planned` | 标准已定义但未落地 |
| `blocked` | 缺 workspace 扫描器或缺真实 registry/eval 数据,暂时无法测量 |

---

## §1. 当前可确认事实(observed)

| 事实 | 来源 | 状态 |
|------|------|------|
| AKB2.0 工具库 8 份子标准全部 ready | docs/toolbox/AKB-2.0-*.md frontmatter `document_status: ready` | observed |
| Phase A-toolbox 完成日期 | 2026-05-03(Step 8 两批 + Step 9 三轮 codex review APPROVED)| observed |
| toolbox 状态收口完成日期 | 2026-05-04(CONTENT-STANDARD §12/§14 + PAGE-TEMPLATES §6/§12 + TOOLBOX-CONTRACT §10)| observed |
| Obsidian 侧已有目录:`toolbox/registry/` / `toolbox/interfaces/` / `toolbox/evals/` | `ls toolbox/` | observed |
| Obsidian 侧 5 类 active 内容子区(tools/workflows/prompts/checklists/agent-procedures)| 子目录 | unknown(未创建)|
| 工具库控制台 [[../../toolbox/00-Index]] 已建立 | 本轮 Step 2 | observed |
| 状态快照目录 [[00-Index]] 已建立 | 本轮 Step 3 | observed |
| Phase B 真实样本 8 份入 staging shadow | [[../../staging/candidate/toolbox-phase-b-2026-05-04/00-Index]] | observed |
| Phase B 样本登记表 | [[../toolbox-samples/2026-05-04-toolbox-phase-b-register]] | observed |
| Phase B 样本数:6 必选 + 2 扩展;5件套 5 份(cc-review/cc-executable-plan/cc-akb-search/cc-local-llm/cc-skill-stocktake);3件套 3 份(execution-result-gate/akb-ingest-gate/review-result-writer)| 本轮 Step 5-6 | observed |
| workspace_root candidate(read-only 确认存在)| `~/.codex/skills/`、`~/.claude/scripts/hooks/`、`~/.claude/scripts/` | observed |
| 所有 Phase B 样本 `not_active: true` + `automation_allowed: false` | 各 draft frontmatter | observed |
| Phase B 样本 backlink_status 全 pending(workspace 端未注入反链)| 各 interface-draft frontmatter | observed |
| Phase B 验证报告产出 | [[../toolbox-samples/2026-05-04-toolbox-phase-b-validation]] — 8/8 完成 / 0 标准冲突 / 允许 Phase C 只读扫描器规划 | observed |

---

## §2. 旧工具库历史数字(historical_reference)

> ⚠️ 以下数字来自旧 `Praise Space/Toolbox/_status.md`,**仅历史参考**,**不**作为 AKB2.0 当前状态权威。

| 旧库指标 | 旧值 | 状态 |
|---------|------|------|
| 旧 toolbox.db 总条目数 | 4413 | historical_reference |
| 旧 active 数 | 2596 | historical_reference |
| 旧 archived 数 | 1817 | historical_reference |
| 旧 _status.md 数字 | (各类版本覆盖 / 质量缺口 / 分类分布) | historical_reference(详见原文档,本快照不复制)|

> 旧库迁移按 [[../../docs/toolbox/AKB-2.0-TOOL-MIGRATION-POLICY|MIGRATION-POLICY]] 走双根迁移 5 步;**本轮明确不迁移**。

---

## §3. AKB2.0 当前指标(unknown / blocked)

### 3.1 asset_type 分布

| asset_type | 数量 | 状态 |
|-----------|------|------|
| `tool` | 0 | unknown(0 active 工具,本身是基线起点)|
| `workflow` | 0 | unknown |
| `prompt` | 0 | unknown |
| `checklist` | 0 | unknown |
| `agent_procedure` | 0 | unknown |

### 3.2 生命周期状态分布(承接 [[../../docs/toolbox/AKB-2.0-TOOL-LIFECYCLE|TOOL-LIFECYCLE]] §2 8 状态)

| status | 数量 | 状态 |
|--------|------|------|
| `candidate` | 0 | observed(staging 未启用)|
| `needs_repair` | 0 | observed |
| `needs_human_review` | 0 | observed |
| `active` | 0 | observed |
| `stale` | 0 | observed |
| `broken` | 0 | observed |
| `deprecated` | 0 | observed |
| `archived` | 0 | observed |

> 全 0 是基线起点,不是异常。

### 3.3 workspace_path 覆盖率(承接 [[../../docs/toolbox/AKB-2.0-TOOLBOX-CONTRACT|TOOLBOX-CONTRACT]] §4.1 反链强制)

| 指标 | 数值 | 状态 |
|------|------|------|
| `workspace_path` 字段填写率 | unknown | blocked(无样本)|
| `workspace_path` resolve 成功率 | unknown | blocked(无扫描器)|
| dead `workspace_path` 数量 | unknown | blocked |

### 3.4 workspace_version 覆盖率

| 指标 | 数值 | 状态 |
|------|------|------|
| `workspace_version` 字段填写率 | unknown | blocked |
| `workspace_version` 与 workspace 真实 commit 一致率 | unknown | blocked(无扫描器)|

### 3.5 backlink_status 覆盖率(承接 [[../../docs/toolbox/AKB-2.0-TOOL-INTERFACE-SCHEMA|TOOL-INTERFACE-SCHEMA]] §3)

| backlink_status | 数量 | 状态 |
|----------------|------|------|
| `ok` | 0 | unknown |
| `pending` | 0 | unknown |
| `vendor_locked` | 0 | unknown |

### 3.6 eval 覆盖率(承接 [[../../docs/toolbox/AKB-2.0-TOOL-EVAL-RULES|TOOL-EVAL-RULES]] §2)

| 指标 | 数值 | 状态 |
|------|------|------|
| L0 文档完整资产数 | 0 | unknown |
| L1 smoke 资产数 | 0 | unknown |
| L2 regression 资产数 | 0 | unknown |
| L3 real task replay 资产数 | 0 | unknown |
| L4 production observation 资产数 | 0 | unknown |
| active 资产 ≥ L1 覆盖率 | unknown | unknown(无 active)|
| automation_allowed=true 资产 ≥ L2 覆盖率 | unknown | unknown |
| risk=high 资产 ≥ L3 覆盖率 | unknown | unknown |

### 3.7 freshness 过期数量(承接 EVAL-RULES §5)

| 指标 | 数值 | 状态 |
|------|------|------|
| `freshness_status: fresh` | 0 | unknown |
| `freshness_status: stale` | 0 | unknown |
| `freshness_status: expired` | 0 | unknown |

### 3.8 automation_allowed 数量(承接 TOOLBOX-CONTRACT §7)

| 指标 | 数值 | 状态 |
|------|------|------|
| `automation_allowed: true` | 0 | unknown |
| `automation_allowed: false` | 0 | unknown |
| `risk: high` 工具数 | 0 | unknown |
| `side_effects: irreversible` 工具数 | 0 | unknown |
| `automation_tier: L3+` 工具数 | 0 | unknown |
| 自动调用 manifest 数(近 7 天)| 0 | unknown(`manifests/tool-calls/` 未启用)|

### 3.9 stale / broken / deprecated 列表

| 状态 | 工具数 | 列表 |
|------|--------|------|
| `stale` | 0 | (无) |
| `broken` | 0 | (无) |
| `deprecated` | 0 | (无) |

> 当前 0 工具入库 = 0 任何降级状态。

---

## §4. Workspace 根目录状态(承接 [[../../docs/toolbox/AKB-2.0-TOOLBOX-CONTRACT|TOOLBOX-CONTRACT]] §3 双根架构)

| 字段 | 值 |
|------|------|
| `workspace_root_status` | **`unknown`** |
| 候选路径(待 reviewer 显式确认) | `~/.claude/skills/` / `~/.claude/scripts/` / `~/.claude/hooks/` / `~/.claude/prompts/` / `bin/` / `mcp-servers/` / 各项目 `scripts/` |
| 已 confirmed 路径 | (无 — 未做只读扫描确认)|
| `scan_mode` | none(本快照纯 Obsidian control plane,未扫描 workspace)|

> 严禁:在未做只读扫描确认前把 `workspace_root_status` 标 `confirmed`。

---

## §5. 本周变化(2026-05-03 → 2026-05-04)

| 日期 | 变化 | 类型 |
|------|------|------|
| 2026-05-03 | Phase A-toolbox 8 份子标准全部升 ready;Step 8 两批 + Step 9 三轮 codex review APPROVED | observed |
| 2026-05-04 | toolbox 8 份升 ready 后状态收口修复(CONTENT-STANDARD §12/§14 + PAGE-TEMPLATES §6/§12 + TOOLBOX-CONTRACT §10 共 9 处文案)| observed |
| 2026-05-04 | 工具库控制台 [[../../toolbox/00-Index]] + 状态快照目录 [[00-Index]] + 本份首基线快照 建立 | observed |

---

## §6. 下周维护优先级

| 优先级 | 项 | 说明 |
|------|------|------|
| **P0** | 确认 workspace 工具根目录 | 把 `workspace_root_status` 从 `unknown` → `candidate_found`(reviewer 列出当前可用路径,不需运行代码)|
| **P1** | 建立 5-10 个 registry/interface/eval 样本 | 选 1-2 个用户日常用的工具(如 `claude-code` / `figma-mcp` 等),手工走 [[../../docs/toolbox/AKB-2.0-TOOL-INTAKE-GATE\|Tool Gate]] 5 步流程,产出 5+5+5 三件套实例(asset_type=tool 5 件套);验证标准在真实场景能跑通 |
| **P2** | 计划只读 workspace 扫描器 | 出独立 plan(只读 / 不创建 / 不修改);列出 `~/.claude/skills/` 等真实资产,写入候选路径;输出当前 workspace 内潜在 candidate 数量 |
| **P3** | 再评估旧工具库 4413 条迁移 | 等 P0-P2 完成后再启动;按 [[../../docs/toolbox/AKB-2.0-TOOL-MIGRATION-POLICY\|MIGRATION-POLICY]] 双根迁移 5 步;每批 ≤ 20 条 |

---

## §7. 边界声明(本快照职责)

- ✅ 本快照是 manifest / control plane,记录 2026-05-04 工具库当前状态
- ✅ 本快照旧工具库数字仅 historical_reference,不作为 AKB2.0 当前状态权威
- ✅ 本快照下一步优先级是建议,reviewer 自行决定何时启动
- ❌ **本快照不是 Tool Gate**(不决定任何工具 active / stale / broken)
- ❌ **本快照不迁移旧工具**(承接 plan §非目标)
- ❌ **本快照不修改真实工具资产**(workspace 侧由工程师维护)
- ❌ **本快照不实现扫描器 / 自动周报 / cron / hook**(本轮全部 not_implemented)

---

## §8. 修订历史

| 日期 | 改动 | 作者 |
|------|------|------|
| 2026-05-04 | 首份手工基线快照建立;`workspace_root_status: unknown`;0 active 工具(基线起点);旧 toolbox.db 4413 条标 historical_reference;P0-P3 下周维护优先级列出 | Claude Code |
