---
title: Phase C-5 Tool Intake Gate 决策报告
doc_type: phase-c-report
phase: C-5
report_kind: tool_intake_gate_decision
automation_layer: gate_decision_only
not_active_promotion: true
report_date: 2026-05-05
slugs_in_round:
  - cc-executable-plan
  - cc-review
slugs_excluded:
  - cc-akb-search  # L0 blocked + risk:high; 不进本轮
---

# Phase C-5 Tool Intake Gate 决策报告 — 2026-05-05

> 本报告记录对 C-4a L1 pass 的两个工具(`cc-executable-plan` / `cc-review`)做的严格 Tool Intake Gate 决策。
> **本轮目标不是把工具升 active**,而是按门控标准如实评估 active 是否成立。
> 当前 backlink_status 都是 `pending`,所以**两个工具的 decision 都是 `needs_repair`**,不是 `active`。

---

## §1 执行总览

| slug | C-4a 状态 | backlink_status | hash check | C-5 decision | next_phase |
|---|---|---|---|---|---|
| `cc-executable-plan` | L1 pass | **pending** | sha256 与 C-4 evidence 完全一致 | **needs_repair** | C-5b backlink repair |
| `cc-review` | L1 pass | **pending** | sha256 与 C-4 evidence 完全一致 | **needs_repair** | C-5b backlink repair |

`cc-akb-search` 不进本轮(L0 blocked + risk:high)。

---

## §2 P0 Gate Matrix(逐项核对)

按 plan §1 P0 7 项检查:

| 检查项 | cc-executable-plan | cc-review |
|---|---|---|
| 五件套存在 | 5/5 ✓ | 5/5 ✓ |
| workspace_path 存在 | ✓(`~/.codex/skills/cc-executable-plan/SKILL.md`) | ✓(`~/.codex/skills/cc-review/SKILL.md`) |
| C-4 evidence 存在 | ✓(`ai-infra/akb2-toolbox-evals/c4a/cc-executable-plan/run-evidence.md`) | ✓(`ai-infra/akb2-toolbox-evals/c4a/cc-review/run-evidence.md`) |
| `eval_level: L1` | ✓ | ✓ |
| `last_run_status: pass` | ✓ | ✓ |
| `risk_level: low` | ✓ | ✓ |
| `automation_allowed: false` | ✓ | ✓ |
| **`backlink_status`** | **pending** | **pending** |

P0 Gate 7 个硬指标里,前 7 项都 pass。**唯一的 blocker 是 backlink_status: pending**。

按 plan §2 决策规则:

> 若 `backlink_status=pending`:decision = `needs_repair`。

→ **两个 slug 都进 `needs_repair`**。

---

## §3 P1 写入(已执行)

### §3.1 五件套 status 同步(10 文件)

每个 slug 5 件套(wiki/tools / toolbox/tools / toolbox/registry / toolbox/interfaces / toolbox/evals)的 frontmatter `status: candidate` → `status: needs_repair`,并加:

```yaml
status_changed_at: 2026-05-05
status_change_reason: "C-5 Tool Intake Gate decision — backlink_status:pending blocks active promotion; eval_level remains L1 (C-4 evidence valid); see C-5b for repair path"
```

**保留**:
- `eval_level: L1`(C-4 evidence 仍有效)
- `automation_allowed: false`
- C-4 evidence 路径不变

**不动**:
- `~/.codex/skills/**`(改 SKILL.md 会改 hash → C-4 evidence 失效;留给 C-5b)

### §3.2 interface repair_actions 段(2 文件,每文件加一段)

在 `toolbox/interfaces/cc-{executable-plan,review}.md` 的 `## backlink_status` 段后追加 `## repair_actions(C-5b 路径)`,5 步:

1. 在 SKILL.md 注入 AKB 反链(轻量 HTML 注释类:`<!-- akb-backlink: AKB2.0/wiki/tools/<slug>.md -->`)
2. 重算 workspace_version sha256
3. backlink_status `pending` → `linked`
4. **重跑 C-4a L1 smoke**(新 hash 使旧 evidence 失效)
5. 重新走 C-5 Tool Intake Gate(在 backlink linked + hash 对齐 + L1 重过的前提下,decision 才允许 `active`)

### §3.3 manifest

`manifests/ingest/2026-05-05.jsonl` 追加 2 行 `tool_gate_decision` 事件,每行字段齐(per plan §接口与数据合约)。

### §3.4 cc-akb-search 未动

`cc-akb-search` 五件套 `status: candidate` 不变(C-4 已 blocked,本轮 plan 明确不进 C-5)。

---

## §4 不变量自检

- ✅ `~/.codex/skills/**` 未改(sha256 前后一致)
- ✅ AKB2.0 toolbox **无 `status: active`**(column-0 grep)
- ✅ AKB2.0 toolbox **无 `automation_allowed: true`**(column-0 grep)
- ✅ 两个 slug 的 5 件套 status 全是 `needs_repair`(对称同步)
- ✅ 两个 slug 的 `eval_level` 全是 `L1`(未回退,C-4 evidence 仍有效)
- ✅ `cc-akb-search` 5 件套 status 仍 `candidate`(未误伤)
- ✅ manifest 路径在 `manifests/ingest/`(plan §代码执行方向 指定),决策可审计
- ✅ 无 active gate / automation gate / Tool Intake Gate active 决策

---

## §5 为什么不直接补 backlink?

按 plan §风险防护:

> 风险:执行窗口想"顺手补 backlink"。
> 防护:本轮禁止改 `.codex/skills`;补 backlink 会使 L1 evidence 失效,必须单独 C-5b。

补 backlink → SKILL.md sha256 改 → C-4 evidence 中 `skill_sha256_after` 不再匹配新 hash → L1 证据失效 → 必须重跑 L1 → 才能再走 C-5。

把这一连串操作分成两轮:
- **C-5(本轮)**:严格门控决策(needs_repair)+ 状态同步 + 报告
- **C-5b(下一轮)**:补 backlink + 重算 hash + 重跑 L1 + 重新走 C-5(届时若全过才允许 `active`)

这样两轮各自的 evidence + decision 都可独立审计,不会出现"中间状态 evidence 不匹配 status"的污染。

---

## §6 C-5b 修复入口(下一轮 plan 锚点)

C-5b plan 应包含:

1. **backlink 注入策略**:在 workspace SKILL.md 加 `<!-- akb-backlink: ... -->` 类轻量标记(不破坏 SKILL.md 语义);具体格式与位置由 C-5b plan 定
2. **逐个工具 backlink + hash 同步**:每个工具改完 SKILL.md 后立即在 AKB2.0 interface 改:
   - `workspace_version: sha256:<新>`
   - `backlink_status: linked`
3. **L1 重跑**:新 hash 使旧 C-4 evidence 失效 → 必须重产 run-evidence.md(新 fixture 或同 fixture 重跑都可,但要新文件 + 新 timestamp)
4. **C-5 重审**:在 backlink linked + hash 对齐 + L1 重过的前提下,Tool Intake Gate 才允许 decision = `active`
5. **active 仍不等于 automation_allowed**:即使 active,`automation_allowed` 仍需 L2 regression 后单独评估

---

## §7 链接

- C-4 上游报告:[[phase-c4-toolbox-l1-smoke-2026-05-05|Phase C-4 报告]]
- C-3 上游报告:[[phase-c3-toolbox-pilot-candidate-build-2026-05-04|Phase C-3 报告]]
- C-5 manifest:[[../../manifests/ingest/2026-05-05|2026-05-05.jsonl]](2 行 tool_gate_decision)
- 五件套(已同步 needs_repair):
  - [[../../wiki/tools/cc-executable-plan]] / [[../../toolbox/tools/cc-executable-plan]] / [[../../toolbox/registry/cc-executable-plan]] / [[../../toolbox/interfaces/cc-executable-plan]] / [[../../toolbox/evals/cc-executable-plan]]
  - [[../../wiki/tools/cc-review]] / [[../../toolbox/tools/cc-review]] / [[../../toolbox/registry/cc-review]] / [[../../toolbox/interfaces/cc-review]] / [[../../toolbox/evals/cc-review]]
