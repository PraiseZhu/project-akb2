---
report_type: phase_d_concept_evidence_census
report_id: bl-d-014-concept-evidence-census-2026-05-08
date: 2026-05-08
status: completed
backlog_item: BL-D-014
plan_source: ~/.claude/plans/rustling-bouncing-marshmallow.md (v2)
related_reports:
  - docs/phase-d-reports/akb2-census-week-2026-05-08.md
  - docs/phase-d-reports/lint-cli-v0.3-2026-05-08T141034.md
---

# BL-D-014 Concept Evidence Census（2026-05-08）

## 1. 摘要

本报告对 BL-D-014 列出的 8 个候选概念做 evidence 判定。**本轮不建任何 wiki/concepts 页，不补 source，不动 lint CLI**。

判定结果：

| Decision | 数量 | 概念 |
|---|---|---|
| `ready_for_candidate` | **0** | （无） |
| `needs_source` | **6** | knowledge-retrieval-first, freshness-tracking, skill-lifecycle, plan-execute-loop, dual-review, agent-collaboration |
| `defer` | **2** | akb-architecture, review-alignment |

**结论**：当前 5 个 active source 页（anthropic-effective-context-engineering / harness-engineering-deep-eval / jenny-wen-ai-design-philosophy / karpathy-intro-to-llms / mcp-spec）对 8 个候选概念**没有 direct_source 级证据**。本轮 evidence census 不解锁任何概念建页。

---

## 2. Review 后约束

| 约束项 | 状态 |
|---|---|
| v0.3 lint review | APPROVED（0 findings，2026-05-08） |
| v0.3 review residual（00-Index 主指针） | 已在本轮收口（`140811` → `141034` 主指针 + 调试 run 标注） |
| A1 ai_infra（mcp__akb-search not_mounted） | APPROVED 只读发现，不在本轮处理 |
| A2 MCP 配置授权 | 不在本轮，需独立计划 |
| `.akb-runtime/lint/akb2-lint.py` | 不改（v0.3 code review 已通过） |
| wiki/concepts/、wiki/sources/、raw/、toolbox/ 正文 | 不改 |

---

## 3. 方法论

### 3.1 扫描范围（强制约束）

| 范围 | 路径 | 排除 |
|---|---|---|
| `current_refs` | `wiki/**/*.md` + `toolbox/**/*.md` | docs/、manifests/、archive/、raw/、staging/ |
| `candidate_source_pages` | `wiki/sources/**/*.md`（status: active 仅 5 页） | 非 active 页面 |

**排除原因**：
- docs/ 与 manifests/ 是 provenance（出处记录），不是 evidence
- archive/、staging/ 不算当前活跃知识
- raw/ 由 R19 RAW-NO-WIKILINK 禁止 wikilink，不计入 graph

### 3.2 `direct_source` 三条件（必须全部满足）

1. source 页 `status: active`
2. 正文含 ≥1 段定义性表述（非引用块、非顺带提及、非"详见 X"式跳转）
3. 概念名或近义表述出现在以下任一节：`## TLDR` / `## 关键发现` / `## 核心论点`

### 3.3 evidence_strength 分级

| 级别 | 判定 |
|---|---|
| `direct_source` | 满足三条件全部 |
| `indirect_source` | 满足条件 1，但条件 2 或 3 不满足；或仅作为背景提及出现 |
| `usage_context_only` | 仅出现在 toolbox/ 工具页、phase-d-reports/、census 报告、backlog 列表 |

### 3.4 Decision 强制映射规则

| evidence_strength | 允许 decision |
|---|---|
| `direct_source` | `ready_for_candidate` |
| `indirect_source` | `needs_source`（不可跨级到 ready） |
| `usage_context_only` | `needs_source` 或 `defer`（不可跨级到 ready） |

### 3.5 双语搜索协议

每个 concept 用 ≥2 个查询命中 current_refs：

1. **英文 slug 形式**：原 slug + hyphen 拆词变体
2. **中文/自然语言形式**：人工先列 1-2 个常见中文表述

每个概念节列出实际查询字符串供审计。

### 3.6 候选 source 池（current snapshot）

```
wiki/sources/anthropic-effective-context-engineering.md  (status: active)
wiki/sources/harness-engineering-deep-eval.md            (status: active)
wiki/sources/jenny-wen-ai-design-philosophy.md           (status: active)
wiki/sources/karpathy-intro-to-llms.md                   (status: active)
wiki/sources/mcp-spec.md                                 (status: active)
```

5 page 的 ## TLDR / ## 关键发现（或别名 ## 标签级主题清单）/ ## 核心论点 行号已逐页确认。

---

## 4. 8 概念 evidence matrix

### CC-001 akb-architecture

| 字段 | 内容 |
|---|---|
| concept_id | CC-001 |
| proposed_slug | concept-akb-architecture |
| 双语查询 | `akb-architecture` / `AKB 架构` / `knowledge base architecture` / `知识库架构` |
| current_refs（命中清单） | `wiki/tools/cc-akb-search.md:77`（"待建" wikilink + 描述："计划入库的 AKB 设计概览"） |
| candidate_source_pages 命中（5 source 内） | 0 |
| evidence_strength | `usage_context_only` |
| decision | **`defer`** |
| blocking_reason | 概念为 AKB2.0 自身架构的元描述（meta-architectural / self-referential），属于 design / architecture 层面文档而非通用知识概念；即使有 source 也不适合做 wiki/concepts 知识页 |
| next_action | 写到 `docs/architecture/` 或 `AKB2.0-CHARTER` 类设计文档；不进 wiki/concepts |

---

### CC-002 knowledge-retrieval-first

| 字段 | 内容 |
|---|---|
| concept_id | CC-002 |
| proposed_slug | concept-knowledge-retrieval-first |
| 双语查询 | `knowledge-retrieval-first` / `knowledge retrieval first` / `search first` / `先查再做` / `检索优先` |
| current_refs（命中清单） | `wiki/tools/cc-akb-search.md:76`（"待建" wikilink + 描述："计划入库的'先查再做'工程原则"） |
| candidate_source_pages 命中（5 source 内） | 0 |
| evidence_strength | `usage_context_only` |
| decision | **`needs_source`** |
| blocking_reason | 概念有效（明确的工程原则），但无 active source 直接定义；散布在 INTAKE-GATE / AUTOMATION-BOUNDARY 等 standards 中（属 docs/ 排除范围），不能作为 evidence_by |
| next_action | 入库一篇关于"search first / retrieval first" 工程原则的 source（可考虑 Anthropic Skills 文档、Karpathy "search before code" 类文章） |

---

### CC-003 freshness-tracking

| 字段 | 内容 |
|---|---|
| concept_id | CC-003 |
| proposed_slug | concept-freshness-tracking |
| 双语查询 | `freshness-tracking` / `freshness` / `新鲜度` / `时效性` / `stale skill` |
| current_refs（命中清单） | `wiki/tools/cc-skill-stocktake.md:95`（维护记录条目，记录 P1d v3 cleanup 时已删该 wikilink）；间接：`wiki/sources/jenny-wen-...md:43,65,183,216` 与 `wiki/sources/harness-...md:197`（均为"数据时效性 = data freshness"，与本概念语义相近但非同义） |
| candidate_source_pages 命中（5 source 内） | "时效性" 5 处，但全在 ## 入选理由 / ## 适用边界 / ## 证据地图 / ## Future Questions 节，**不在 TLDR/关键发现/核心论点 节**；语义为"data freshness"（数据陈旧风险），与"freshness tracking"（巡检知识库新鲜度）不同 |
| evidence_strength | `usage_context_only`（concept 本体）+ semantic-adjacent（"时效性" 在 source 但语义不同） |
| decision | **`needs_source`** |
| blocking_reason | tool 页 wikilink 已被 cleanup 删除；source 中 "时效性" 是 evidence freshness 而非 skill / knowledge freshness tracking 概念；无 direct_source |
| next_action | 入库一篇关于"知识库 / skill 库 freshness 巡检"的 source（如 LLM cache invalidation、knowledge staleness 类研究） |

---

### CC-004 skill-lifecycle

| 字段 | 内容 |
|---|---|
| concept_id | CC-004 |
| proposed_slug | concept-skill-lifecycle |
| 双语查询 | `skill-lifecycle` / `skill lifecycle` / `skill life cycle` / `技能生命周期` / `skill 生命周期` |
| current_refs（命中清单） | `wiki/tools/cc-skill-stocktake.md:95`（维护记录，记录 P1d v3 cleanup 时已删该 wikilink） |
| candidate_source_pages 命中（5 source 内） | 0 |
| evidence_strength | `usage_context_only` |
| decision | **`needs_source`** |
| blocking_reason | tool 页 wikilink 已删；上游 census 已标"source 最薄弱"；无 active source 直接讨论 skill lifecycle（discovery → development → maintenance → deprecation 等阶段） |
| next_action | 入库一篇关于"AI skill lifecycle / skill governance"的 source；或观察后续 6-12 月有无成熟讨论 |

---

### CC-005 plan-execute-loop

| 字段 | 内容 |
|---|---|
| concept_id | CC-005 |
| proposed_slug | concept-plan-execute-loop |
| 双语查询 | `plan-execute-loop` / `plan execute loop` / `plan-execute` / `计划执行循环` / `规划-执行循环` / `PE loop` |
| current_refs（命中清单） | `wiki/tools/cc-executable-plan.md:76`（"待建" wikilink） |
| candidate_source_pages 命中（5 source 内） | 0（针对"plan-execute"/"执行循环" 等查询的 grep 结果为空；**注意**：上游 census §3.2 CC-005 称"harness-engineering-deep-eval §3.1 plan loop 间接支撑"，本轮实际 grep 验证 harness-engineering-deep-eval 内**不含** "plan loop" / "plan-execute" / "执行循环" 字样；上游说法不能成立，按实际 grep 结果判定） |
| evidence_strength | `usage_context_only` |
| decision | **`needs_source`** |
| blocking_reason | 上游"harness-engineering-deep-eval 间接支撑"经实际 grep 反验证不成立；当前无任何 active source 含 plan-execute-loop 概念定义 |
| next_action | 入库一篇专门讨论 plan-execute loop / agentic planning loop 的 source（如 LangGraph plan-and-execute、ReAct 类论文） |

---

### CC-006 review-alignment

| 字段 | 内容 |
|---|---|
| concept_id | CC-006 |
| proposed_slug | concept-review-alignment |
| 双语查询 | `review-alignment` / `review alignment` / `review 对齐` / `审查对齐` |
| current_refs（命中清单） | `wiki/tools/cc-executable-plan.md:77`（"待建" wikilink）；另：`wiki/tools/cc-executable-plan.md:8,34,42`、`toolbox/tools/cc-executable-plan.md:30,31,50`、`toolbox/registry/cc-executable-plan.md:25,43`、`toolbox/interfaces/cc-executable-plan.md:51`（共 9 处，均指 plan 模板里的 "Review 对齐" 字段名） |
| candidate_source_pages 命中（5 source 内） | 0 |
| evidence_strength | `usage_context_only`（且 9/10 引用是模板字段名而非概念本体） |
| decision | **`defer`** |
| blocking_reason | "Review 对齐" 实际是 plan 模板的字段名 / 流程构件，而非通用知识概念；属于内部工具规范文档（toolbox/ 已有 cc-executable-plan / cc-review 工具卡覆盖），不适合作为 wiki/concepts 知识页 |
| next_action | 维持作为 plan 模板字段；如需正式化，写到 `toolbox/conventions/` 或 `docs/standards/` 而非 wiki/concepts |

---

### CC-007 dual-review

| 字段 | 内容 |
|---|---|
| concept_id | CC-007 |
| proposed_slug | concept-dual-review |
| 双语查询 | `dual-review` / `dual review` / `dual eval` / `双重审查` / `双轨审查` / `双重评估` / `double review` |
| current_refs（命中清单） | `wiki/tools/cc-review.md:74`（"待建" wikilink） |
| candidate_source_pages 命中（5 source 内） | 0（**注意**：上游 census §3.2 CC-007 称"harness-engineering-deep-eval 中有 dual-eval 论述"，本轮实际 grep 验证 harness-engineering-deep-eval 内**不含** "dual" / "双重" / "双轨" 字样；上游说法不能成立） |
| evidence_strength | `usage_context_only` |
| decision | **`needs_source`** |
| blocking_reason | 上游"harness-engineering-deep-eval 含 dual-eval"经实际 grep 反验证不成立；当前无 active source 定义 dual-review 模式（双方独立审查、交叉验证） |
| next_action | 入库一篇关于"dual review / multi-agent review / cross-review"模式的 source（如 Anthropic Constitutional AI、SuperAlignment、Reviewer-as-Judge 类研究） |

---

### CC-008 agent-collaboration

| 字段 | 内容 |
|---|---|
| concept_id | CC-008 |
| proposed_slug | concept-agent-collaboration |
| 双语查询 | `agent-collaboration` / `agent collaboration` / `agent collab` / `multi-agent` / `agent 协作` / `代理协作` / `多 agent` |
| current_refs（命中清单） | `wiki/tools/cc-review.md:75`（"待建" wikilink）；间接：`wiki/concepts/concept-large-language-model.md:123`（Future Questions："multi-agent 协作场景...等独立 source 入库"）；`wiki/sources/anthropic-effective-context-engineering.md:204`（Future Questions："多 agent 协作...需独立 source"） |
| candidate_source_pages 命中（5 source 内） | "多 agent" / "agent 协作" 各 1 处，全部出现在 ## Future Questions 节，**显式声明缺 source**（"等独立 source 入库" / "需独立 source"）；不满足 direct_source 条件 2 与条件 3 |
| evidence_strength | `usage_context_only`（source 内的提及反而是反证："需独立 source"） |
| decision | **`needs_source`** |
| blocking_reason | source 内的"多 agent 协作"提及是 Future Questions（明确缺 source 声明），不是定义性段落；概念外延较宽（multi-agent supervisor / agent mesh / blackboard / pipeline 多种语义），需 source 定锚才能建有意义的 wiki 页 |
| next_action | 入库一篇关于 multi-agent collaboration / agent supervision 的 source（如 Anthropic Multi-Agent Research System、AutoGen、CrewAI 类研究）；建页时需明确范围（哪一类 collaboration） |

---

## 5. 决策分组汇总

### 5.1 `ready_for_candidate`（0 个）

无。当前 5 个 active source 页对 8 个候选概念均无 direct_source 级证据。

### 5.2 `needs_source`（6 个）

| 概念 | 建议 source 来源类型 |
|---|---|
| knowledge-retrieval-first | "search first / retrieval first" 工程原则文章 |
| freshness-tracking | 知识库 / skill 库 freshness 巡检相关研究 |
| skill-lifecycle | AI skill lifecycle / governance 类讨论 |
| plan-execute-loop | LangGraph plan-and-execute、ReAct 类论文 |
| dual-review | Constitutional AI、Reviewer-as-Judge、cross-review 类研究 |
| agent-collaboration | Anthropic Multi-Agent Research、AutoGen、CrewAI 类源 |

### 5.3 `defer`（2 个）

| 概念 | defer 原因 | 替代落地路径 |
|---|---|---|
| akb-architecture | self-referential meta-architectural；属设计文档而非知识概念 | `docs/architecture/` 或 `AKB2.0-CHARTER` |
| review-alignment | 实为 plan 模板字段名 / 流程构件，非通用知识概念 | `toolbox/conventions/` 或 `docs/standards/` |

---

## 6. 预期值校准声明

**本次 0/8 ready 是数据现状的客观反映，不构成对 BL-D-014 推进进度的负面评价。**

原因：
- AKB2.0 active source 池目前共 5 篇（context engineering / harness engineering / AI design philosophy / LLM intro / MCP spec），主题集中在 agent infrastructure 与 LLM intro 层，与 BL-D-014 的 8 个工具配套概念（akb 内部架构、search-first 原则、freshness 巡检、skill lifecycle、plan loop、review 模式、agent 协作）几乎不重叠
- BL-D-014 的概念多为"工具配套支撑概念"，其语义来源主要在 standards docs（INTAKE-GATE / LINT-RULES / AUTOMATION-BOUNDARY）与内部 toolbox 工具卡中，而 standards 与 toolbox 按 evidence 锚点定义不能作为 wiki concept 页的 evidence_by
- 本次 census 同时识别出 2 个**结构性错配**（akb-architecture / review-alignment 不应在 wiki/concepts），属于额外信号

**下一步是补 source 还是延后概念建设，由用户决策**。本报告仅完成"哪些概念可建 / 缺什么"的判定。

### 上游 census 校正记录

本轮 grep 反验证发现 `docs/phase-d-reports/akb2-census-week-2026-05-08.md` §3.2 中两处推断不成立：

| 概念 | 上游说法 | 实际 grep 结果 |
|---|---|---|
| CC-005 plan-execute-loop | "harness-engineering-deep-eval §3.1 plan loop 间接支撑" | source 内不含 "plan loop" / "plan-execute" / "执行循环" 字样 |
| CC-007 dual-review | "harness-engineering-deep-eval 含 dual-eval 论述" | source 内不含 "dual" / "双重" / "双轨" 字样 |

故 CC-005、CC-007 的优先级"高"判定（基于这两处推断）需要重新评估。本报告按实际 grep 结果将两者归入 `needs_source`。

---

## 7. 下一步建议

1. **本轮收口**：v0.3 lint residual 已处理；本 census 已交付。无需进一步动作。
2. **若用户决定推进 needs_source 概念**：另开计划，每个概念独立 source 入库（按 INTAKE-GATE 流程），入库后再独立 census 确认 direct_source，再开建页计划。
3. **若用户认可 defer 判定**：将 akb-architecture 移入 `docs/architecture/` 或新建 AKB2.0 设计文档；将 review-alignment 整理进 toolbox conventions（不进 wiki/concepts）。
4. **不在本轮范围**：建任何 wiki/concepts 页 / 补 source / 改 lint / 接抓取链路 / A2 MCP 授权。

---

## 8. 不变量

- 本报告**不创建** `wiki/concepts/*.md`
- 本报告**不修改** wiki/sources/、wiki/concepts/、toolbox/ 正文
- 本报告**不修改** `.akb-runtime/lint/akb2-lint.py`
- 本报告**不挂载** mcp__akb-search、不启用 hooks/cron
- 仅 2 文件改动：`manifests/lint/00-Index.md`（v0.3 主指针修正）+ 本报告新增

## 9. 维护记录

| 日期 | 摘要 | 操作 |
|---|---|---|
| 2026-05-08 | BL-D-014 evidence census v1（按 plan v2 双语搜索 + 客观锚点）— 0 ready / 6 needs_source / 2 defer；同时校正上游 census 中 CC-005、CC-007 两处推断 | praise + Claude Code |
