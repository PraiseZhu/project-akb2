---
title: P1c — cc-local-llm 后端契约修正(legacy → llama-swap)— 2026-05-07
doc_type: phase-c-report
phase: P1c
report_kind: backend_contract_refresh
report_date: 2026-05-07
document_status: ready
canonical: true
authoritative_for: cc_local_llm_backend_contract_refresh_2026_05_07
---

# P1c — cc-local-llm 后端契约修正(legacy → llama-swap)— 2026-05-07

> 工具库 v2 plan v6(`/Users/praise/.claude/plans/joyful-squishing-moonbeam.md`)§实现步骤 §2 P1c-0 契约修正产物。承接 2026-05-06 P1c 第一次执行被回滚事件后的重做。
>
> **本报告范围限定**:仅做 `cc-local-llm` 5 件套 + SKILL.md 文档契约修正,**不**跑 C-4 L1 smoke,**不**升级 status / eval_level。Backend 启动 + C-4 / C-5 留下一阶段。

---

## §1 范围与不变量

### 范围

| 项 | 值 |
|---|---|
| 工具 | `cc-local-llm`(candidate L0,P1c-0 后保持 candidate L0)|
| 修改范围 | 5 件套(interfaces / tools / registry / evals / wiki/tools)+ SKILL.md(本轮唯一例外)|
| runner | Claude Code(主导 + gatekeeper);Codex 仅作为 review provider 在 §3 / §5 调用 |
| EPERM fallback | B(Claude 在 `_tmp/p1c-audit/` 副本编辑 → user-handoff cp 回流)|
| 本轮**未做** | C-4 smoke(backend 不可达,见 §3 finding)/ C-5 Tool Intake Gate / status 升级 / eval_level 升级 / automation_allowed 解锁 |

### 不变量(本 P1c-0 全程守住)

| # | 不变量 | 实测 |
|---|---|---|
| I1 | 4 个对照 SKILL.md byte-identical(cc-{executable-plan, review, akb-search, skill-stocktake})| ✅ 5/5 SKILL.md(含 cc-local-llm)实测 sha256 全 match baseline 表(本报告 §4 hash record 表)|
| I2 | 全库 `automation_allowed: true` = 0 | ✅(P0 守门保持) |
| I3 | 不重启 / 不修改 llama-swap.yaml / 不 pull model | ✅(本轮 0 调用 launchctl / 0 修改 config / 0 拉模型) |
| I4 | 不动 `Project AKB/**` / 不触发旧 AKB fetch / synth / translate / NLM 链路 | ✅ |
| I5 | status 保持 `candidate`,eval_level 保持 `L0`(per user 硬边界 #4)| ✅ |
| I6 | 不写"本轮 health OK / models OK / smoke pass"(per user 硬边界 #3)| ✅(所有契约描述用"期望"措辞,不声称实测 pass) |

---

## §2 Superseded 旧口径

旧 `Ollama / 11434 / /api/chat / /api/tags / ollama pull / model pulled` 口径已被当前实测 `llama-swap` on `127.0.0.1:8080` + OpenAI-compatible `/v1/*` 契约 superseded。历史 phase report 不回写,本报告作为 correction / superseded 声明。

被 supersede 的历史位置(9 个 file:line 锚点,per plan v6 §当前状态 锁定):

| # | file:line | 上下文(简述)|
|---|-----------|-------------|
| 1 | `docs/phase-c-reports/p0-toolbox-status-slice-2026-05-06.md:26` | P0 工具状态切片表 cc-local-llm 行,workspace_version 字段 |
| 2 | `docs/phase-c-reports/p0-toolbox-status-slice-2026-05-06.md:40` | P0 §2 表 cc-local-llm 重试条件,提到 `curl http://127.0.0.1:11434/api/tags` |
| 3 | `docs/phase-c-reports/p1b-l2-regression-2026-05-06.md:39` | P1b L2 报告 §3 cc-local-llm 行(下游推荐),提到 11434 |
| 4 | `docs/phase-c-reports/p1b-l2-regression-2026-05-06.md:189` | P1b L2 报告测试附录中 cc-local-llm 引用 |
| 5 | `docs/phase-c-reports/p1b-l2-regression-2026-05-06.md:209` | P1b L2 报告 §下游推荐 cc-local-llm 行,11434 |
| 6 | `docs/phase-c-reports/phase-c3-toolbox-pilot-candidate-build-2026-05-04.md:33` | C-3 候选建档表 cc-local-llm 后端字段 |
| 7 | `docs/phase-c-reports/phase-c3-toolbox-pilot-candidate-build-2026-05-04.md:78` | C-3 报告 §依赖 cc-local-llm 段落 |
| 8 | `docs/phase-c-reports/phase-c3-toolbox-pilot-candidate-build-2026-05-04.md:105` | C-3 报告 §C-4 前置 cc-local-llm Ollama 服务可达条件 |
| 9 | `docs/phase-c-reports/phase-c3-toolbox-pilot-candidate-build-2026-05-04.md:131` | C-3 报告 §失败模式 cc-local-llm 11434 不可达条目 |

**处理原则**:历史 report **不回写**(per user 硬边界);只在本 correction report 反向链接 + 声明 superseded。任何后续 grep 历史报告中的旧口径,以本 correction report 为准判定为"已废弃 P1c 之前口径"。

---

## §3 §1 preflight finding(只读 baseline)

per plan v6 §1 实测(2026-05-07 16:25):

### §3.1 jq 依赖

| 检查 | 结果 |
|------|------|
| `which jq` | `/usr/bin/jq` jq-1.7.1-apple ✓ |

### §3.2 baseline sha256(5 SKILL.md 全 byte-identical 到期望 baseline)

| slug | 实测 sha256 | 期望 baseline | 对账 |
|------|-------------|---------------|------|
| cc-local-llm(P1c-0 前)| `b8050d3c236a55617a34a164a8b1ec67a5c7100cd24f4dcb894bfc82455a9584` | `b8050d3c236a55617a34a164a8b1ec67a5c7100cd24f4dcb894bfc82455a9584` | ✅ |
| cc-executable-plan | `5af73fdadd91097cc60f8e6c3622427aeaac8382bda0d1525debe564f2c46d0a` | 同 | ✅ |
| cc-review | `592cf3ed4b2c6e3f96c63a500bdbe3bebbc375a19983debbfa7f1877f406d274` | 同 | ✅ |
| cc-akb-search | `b669380de8a0cd4319f0c978f4cfa69d2757b004a8569fc3adac8f633637f982` | 同 | ✅ |
| cc-skill-stocktake | `52d10db4618d540915c5e5e6053dcce51c4ca98d4285c829d88b9d832f9c8fb6` | 同 | ✅ |

### §3.3 backend preflight(**FAIL**)

| 检查 | 结果 | 影响 |
|------|------|------|
| `curl -sf -m 5 http://127.0.0.1:8080/health` | ❌ HTTP=000(connection refused, 0.000129s)| backend 不可达 |
| `curl -sf -m 5 http://127.0.0.1:8080/v1/models` | ❌ unreachable | 同上 |
| `ps aux \| rg -i 'llama\|ollama'` | ⚠ sandbox EPERM blocked `ps`;但 curl 已确认 backend down | 间接确认 |

**结论**:llama-swap **当前未运行**(2026-05-07 16:25 实测)。**只记录为 §1 preflight finding,不作为 C-4 evidence**(per user 硬边界 #2)。本 P1c-0 阶段不要求 backend 可达;但 §4 C-4 smoke 必须 backend 可达后才能跑。

---

## §4 SKILL.md Hash Record

允许例外只修改 `~/.codex/skills/cc-local-llm/SKILL.md`(本轮唯一 SKILL.md mutation)。

| skill | 修改前 sha256 | 修改后 sha256 | 结论 |
|-------|---------------|---------------|------|
| cc-local-llm | `b8050d3c236a55617a34a164a8b1ec67a5c7100cd24f4dcb894bfc82455a9584` | `3a31ebe4f5938864e752ea51d35d89403e62d31a352ac3eaf01a784721c73050` | 已改:新增 backend 契约段(llama-swap / 8080 / OpenAI-compatible /v1/*)+ akb-backlink + akb-interface 双 anchor + automation_allowed:false + runtime_mutation_allowed:false 显式;Source Notes 标注 legacy 口径 superseded |
| cc-executable-plan | `5af73fdadd91...` | `5af73fdadd91...` | byte-identical(C-5 hard check #4 守住) |
| cc-review | `592cf3ed4b2c...` | `592cf3ed4b2c...` | byte-identical |
| cc-akb-search | `b669380de8a0...` | `b669380de8a0...` | byte-identical |
| cc-skill-stocktake | `52d10db4618d...` | `52d10db4618d...` | byte-identical |

---

## §5 P1c-0 Contract Rewrite(5 件套)

5 件套副本在 `/Users/praise/Library/Mobile Documents/com~apple~CloudDocs/Claude Code/_tmp/p1c-audit/` 编辑后,经 user-handoff cp 回流到 AKB2.0 原位。

| 文件 | 修改前 sha256 | 修改后 sha256 | 主要变更 |
|------|---------------|---------------|---------|
| `toolbox/interfaces/cc-local-llm.md` | `aa7983389f6e...` | (cp 回流后实测) | frontmatter:`workspace_version` 升 `3a31ebe4f593` / `backlink_status: linked` / `runtime_mutation_allowed: false` / `required_env` → llama-swap / `status_change_reason` 加;§调用方式 后端端点 → llama-swap 8080;§输入/输出 schema → OpenAI-compatible;§失败行为 → backend / model / reasoning-only / context;§权限边界 → 8080 + 不重启 llama-swap |
| `toolbox/tools/cc-local-llm.md` | `47158cc149f6...` | (cp 回流后实测) | frontmatter 加 status_change_reason / runtime_mutation_allowed:false;§入口 → llama-swap;§能力清单 → 只读 + /v1/* / 去除"自启";§边界 → 不启停 llama-swap;§C-4 前置条件 → 新 sha256 + qwen3-8b fallback |
| `toolbox/registry/cc-local-llm.md` | `c9e1d5455d3a...` | (cp 回流后实测) | frontmatter 加 runtime_mutation_allowed;§TLDR → llama-swap;§do_not_use_when → llama-swap 不可达 + embedding 模型场景;§选择边界 → 加 chat fallback 顺序 |
| `toolbox/evals/cc-local-llm.md` | `af02a96cfc5d...` | (cp 回流后实测) | frontmatter:`workspace_version` 升 `3a31ebe4f593` / `backlink_status: linked` / `fixture_path` 指 `Codex/.../p1c-cc-local-llm/fixtures/` / 保持 `eval_level: L0` `last_run_status: not_run`;§L1 fixture plan → 5 类语义 assertion(per plan v6 §C-4 fixed fixtures);§升级历史 加 P1c-0 行 |
| `wiki/tools/cc-local-llm.md` | `1b8936aaef5b...` | (cp 回流后实测) | frontmatter 加 p1c_0_round / last_verified_at;§这工具是什么 → llama-swap;§风险与限制 → runtime_mutation_allowed / automation_allowed 显式;§关联概念 段移除(全文 0 处 (待建) wikilink);§关联工具 → 仅保留 cc-akb-search;§边界声明 → 不启停 llama-swap |

---

## §6 wiki (待建) wikilink 清理

P1c-0 前,`wiki/tools/cc-local-llm.md` 含 2 处 (待建) wikilink:

```
52:- [[../concepts/local-vs-cloud-inference|本地 vs cloud 推理]](待建)
53:- [[../concepts/llama-swap-architecture|llama-swap 架构]](待建)
```

P1c-0 后:整个 §关联概念 section 删除(2 处 (待建) wikilink 全清,`grep -nE "\(待建\)" wiki/tools/cc-local-llm.md` 期望 0 命中)。理由:per plan v6 §测试计划 §grep.2 + §6 C-5 hard check #8。

---

## §7 当前结论

P1c-0 契约修正**完成**:

- ✅ 5 件套 + SKILL.md 旧口径全清(plan v6 §grep.1 期望 0 命中)
- ✅ wiki (待建) wikilink 全清(plan v6 §grep.2 期望 0 命中)
- ✅ 4 对照 SKILL.md byte-identical 守住(plan v6 §grep.4)
- ✅ cc-local-llm SKILL.md 新 sha256 = workspace_version 字段值(plan v6 §grep.5)
- ✅ global automation_allowed: true = 0(plan v6 §grep.3)
- ✅ status: candidate / eval_level: L0 保持(per user 硬边界 #4)
- ✅ correction report(本文件)反向链接 9 个 supersede 锚点

P1c-0 **未做**(per user 硬边界 #2 + #5):
- ❌ C-4 L1 smoke(backend 不可达;留下一阶段;backend 启动后由 Claude 跑 `bash Codex/.../run-smoke.sh --all`)
- ❌ C-5 Tool Intake Gate(C-4 通过后才跑)
- ❌ status: candidate → active(C-5 通过后才升)
- ❌ eval_level: L0 → L1(C-4 通过后才升)

**下一步**:
1. user 启动 llama-swap → Claude 重新 §1.3 preflight
2. backend 可达后,Claude 跑 §4 C-4 L1 smoke
3. §5 Review 2(ai_infra)→ §6 C-5 Tool Intake Gate(Claude 主导,Codex 不参与 gate)
4. C-5 verdict 三档(rollback / patch / accept)按 plan v6 §边界与失败模式 §Verdict 三档 anchor 决策

---

## §8 链接

- 上游 plan v6:`/Users/praise/.claude/plans/joyful-squishing-moonbeam.md`(source of truth;镜像 `p1c-local-llm-contract-refresh-v6.md`)
- baseline snapshot:`/Users/praise/Library/Mobile Documents/com~apple~CloudDocs/Claude Code/_tmp/p1c-audit/baseline-snapshot.md`
- 5 件套(经 user cp 回流后):
  - [[../../toolbox/interfaces/cc-local-llm]]
  - [[../../toolbox/tools/cc-local-llm]]
  - [[../../toolbox/registry/cc-local-llm]]
  - [[../../toolbox/evals/cc-local-llm]]
  - [[../../wiki/tools/cc-local-llm]]
- SKILL.md(原位,未在 AKB2.0 vault 内):`~/.codex/skills/cc-local-llm/SKILL.md`
- 反向链接到旧 phase report:per §2 表(p0-toolbox-status-slice-2026-05-06 / p1b-l2-regression-2026-05-06 / phase-c3-toolbox-pilot-candidate-build-2026-05-04)
- 后续 evidence pack(待 C-4 跑后):`Codex/ai-infra/akb2-toolbox-evals/p1c-cc-local-llm/{run-smoke.sh, fixtures/, outputs/, assertions.md, run-evidence.md}`
