---
title: Phase C-3 Gate 自动检查验证报告 2026-05-04
doc_type: phase-c-report
phase: C-3
report_kind: gate_check_validation
automation_layer: L3
not_active_promotion: true
operation_id: akb2-gate-check-e349f0a3b1aa
mode: write-proposal
report_date: 2026-05-04
---

# Phase C-3 Gate 自动检查验证报告 — 2026-05-04

> 本报告由 `akb2_gate_check`(只读 L3 提议层)生成；不修改任何 active / candidate / 标准文档。

## §1 总体扫描数

- root: `/Users/praise/Library/Mobile Documents/iCloud~md~obsidian/Documents/Praise Space/AKB2.0`
- candidate_dir: `/Users/praise/Library/Mobile Documents/iCloud~md~obsidian/Documents/Praise Space/AKB2.0/staging/candidate/phase-b-validation`
- 扫描文件总数: 10
- 成功解析: 10
- 解析失败: 0
- L3 proposal manifest: `/Users/praise/Library/Mobile Documents/iCloud~md~obsidian/Documents/Praise Space/AKB2.0/manifests/lint/2026-05-04-phase-c3-gate-proposal.jsonl`

## §2 proposed_gate_decision 分布

| decision | 数量 |
|----------|------|
| active | 7 |
| needs_repair | 3 |
| needs_human_review | 0 |
| brief_only | 0 |
| archive | 0 |
| reject | 0 |

## §3 confidence 分布

| confidence | 数量 |
|------------|------|
| high | 0 |
| medium | 10 |
| low | 0 |

## §4 active_proposal_with_l4_requirements

- `claude-code-skills-cross-call-patterns--phase-b--2026-05-03.md` — graph_readiness=proposed_node_only; l4_requirements=['materialize_graph_link']
- `figma-to-website-one-click-eval--phase-b--2026-05-03.md` — graph_readiness=proposed_node_only; l4_requirements=['materialize_graph_link']
- `goal-driven-multi-agent-methodology--phase-b--2026-05-03.md` — graph_readiness=proposed_node_only; l4_requirements=['materialize_graph_link']
- `harness-engineering-deep-eval--phase-b--2026-05-03.md` — graph_readiness=proposed_node_only; l4_requirements=['materialize_graph_link']
- `jenny-wen-ai-design-philosophy--phase-b--2026-05-03.md` — graph_readiness=proposed_node_only; l4_requirements=['materialize_graph_link']
- `karpathy-intro-to-llms--phase-b--2026-05-03.md` — graph_readiness=proposed_node_only; l4_requirements=['materialize_graph_link']
- `skill-description-vs-my-infra--phase-b--2026-05-03.md` — graph_readiness=proposed_node_only; l4_requirements=['materialize_graph_link']

## §5 out_of_scope_toolbox_gate

- 无

## §6 schema 命名空间发现

- 无

## §7 与 Phase B register 对比

| candidate | phase_b 人工建议 | C-3 自动建议 | 一致 |
|---|---|---|---|
| `awesome-ai-research-writing-prompts--phase-b--2026-05-03.md` | needs_repair | needs_repair | ✅ |
| `claude-code-skills-cross-call-patterns--phase-b--2026-05-03.md` | active | active | ✅ |
| `figma-to-website-one-click-eval--phase-b--2026-05-03.md` | active | active | ✅ |
| `goal-driven-multi-agent-methodology--phase-b--2026-05-03.md` | active | active | ✅ |
| `harness-engineering-deep-eval--phase-b--2026-05-03.md` | active | active | ✅ |
| `jenny-wen-ai-design-philosophy--phase-b--2026-05-03.md` | active | active | ✅ |
| `karpathy-intro-to-llms--phase-b--2026-05-03.md` | active | active | ✅ |
| `legacy-akb-mcp-wiki--phase-b--2026-05-03.md` | needs_repair | needs_repair | ✅ |
| `skill-description-vs-my-infra--phase-b--2026-05-03.md` | active | active | ✅ |
| `upstream-skills-academic-doc-design--phase-b--2026-05-03.md` | needs_repair | needs_repair | ✅ |

## §8 标准缺口与 reviewer 后续项

- docs/AKB-2.0-CONTENT-STANDARD.md 实际不存在(plan 引用),仅有 CONTENT-LIFECYCLE — 后续标准 cross-ref 需校准

## §9 逐条 proposal 摘要

| candidate | proposed_gate_decision | confidence | graph_readiness | future_questions |
|---|---|---|---|---|
| `awesome-ai-research-writing-prompts--phase-b--2026-05-03.md` | needs_repair | medium | proposed_node_only | 0 |
| `claude-code-skills-cross-call-patterns--phase-b--2026-05-03.md` | active | medium | proposed_node_only | 3 |
| `figma-to-website-one-click-eval--phase-b--2026-05-03.md` | active | medium | proposed_node_only | 3 |
| `goal-driven-multi-agent-methodology--phase-b--2026-05-03.md` | active | medium | proposed_node_only | 3 |
| `harness-engineering-deep-eval--phase-b--2026-05-03.md` | active | medium | proposed_node_only | 3 |
| `jenny-wen-ai-design-philosophy--phase-b--2026-05-03.md` | active | medium | proposed_node_only | 3 |
| `karpathy-intro-to-llms--phase-b--2026-05-03.md` | active | medium | proposed_node_only | 3 |
| `legacy-akb-mcp-wiki--phase-b--2026-05-03.md` | needs_repair | medium | proposed_node_only | 0 |
| `skill-description-vs-my-infra--phase-b--2026-05-03.md` | active | medium | proposed_node_only | 3 |
| `upstream-skills-academic-doc-design--phase-b--2026-05-03.md` | needs_repair | medium | proposed_node_only | 0 |

## §10 进入 L4 reviewer 授权计划?

**可以** — 共 7 条 candidate 拟 active；其中 7 条带 L4 requirement(必须先 materialise graph link)。
进入 L4 前必须复核：(a) 没有 active 写入；(b) `gate_reason` 由 L4 写入，不引用 `proposed_gate_reason` 文本；(c) `proposed_graph_nodes` 全部转成正式 `related_*`。

## §11 不变量自检

- [x] 0 active 写入(L3 提议层契约)
- [x] manifest 写入 `manifests/lint/`,不写 `manifests/ingest/`
- [x] 每行 record 含 `not_active_promotion: true`
- [x] `proposed_gate_reason` 与 `gate_reason` 严格分离
- [x] `proposed_graph_nodes` 不被当作正式 `related_*`

