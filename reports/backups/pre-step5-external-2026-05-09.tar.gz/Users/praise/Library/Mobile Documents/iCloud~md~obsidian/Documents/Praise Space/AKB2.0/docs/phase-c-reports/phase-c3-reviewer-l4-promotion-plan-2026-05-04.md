---
title: AKB2.0 Phase C-3 Reviewer L4 授权独立 plan(读 C-3 提议 → 升 active)
doc_type: phase-c-plan
phase: C-3-L4-followup
report_kind: reviewer_l4_authorization_plan
automation_layer: L4
report_date: 2026-05-04
document_status: ready-for-review
canonical: false
authoritative_for: phase_c3_l4_active_promotion_2026_05_04
follows_up: phase-c3-gate-check-validation-2026-05-04
---

> ⚠️ **本 plan 是 draft,未启动执行**。reviewer 必须显式授权后才能执行。
> 执行后 → 第一次创建 `wiki/` active 内容(Phase A→D 来第一次)。

---

# Phase C-3 Reviewer L4 授权 plan

## §0. 上下文

- **C-3 L3 提议层已完成**(2026-05-04)— 7 active 提议 + 3 needs_repair,review APPROVED
- **L3 manifest**:`manifests/ingest/2026-05-04.jsonl`(10 records,operation_id `akb-gate-check-08afbb57895a`)
- **本 plan 范围**:reviewer 显式审 7 active candidate → 实际创建 wiki/<file>.md(L4 提升)+ 写 L4 manifest 引 L3 决策

## §1. Review 对齐

REVIEW_DOMAIN: app_code

REVIEW_FOCUS:
- L4 提升是否严格由 reviewer 显式授权(不允许工具自动判)
- 每条 active 提升前是否 materialize_graph_link(proposed_graph_nodes → 真实 related_* 或同步建目标节点)
- L4 manifest 是否引 L3 manifest operation_id(decision_refs)+ 承接 AUTOMATION §6.3 11 字段
- write lock + 单写者协议(承接 AUTOMATION §5 §7)
- 越权护栏:0 改 candidate / 0 改 ready 标准 / 0 改 toolbox active / 0 接旧链路
- 0 引入新枚举 / 0 LLM

Domain-specific notes:
- app_code:本 plan 实施 = 工具 + reviewer 流程协同;工具是 promote.py(承接 gate_check 工程模式),reviewer 给授权 + 复核
- docs_content:同步建/更新 wiki/sources/00-Index.md(active 入索引)— 本 plan 是 Phase C 第一次触碰 wiki/ active

## §2. 目标与验收

目标:把 C-3 的 7 个 active L3 提议(对每个候选 reviewer 显式批准后)实际升 active,创建 `wiki/<file>.md`,完成 Phase A→D 的第一次 active 数据生产。

成功标准:
- [ ] **每条 active 提升必须 reviewer 逐条显式授权**(不允许批量 yes-all)
- [ ] **每条 active 必须 materialize_graph_link**(proposed_graph_nodes → 真实 related_* 或同步建目标节点)
- [ ] L4 manifest 写到 `manifests/ingest/<YYYY-MM-DD>.jsonl`(同 ingest 路径,新一行,proposal_level: L4)
- [ ] L4 manifest `decision_refs: [L3 manifest operation_id]`(L4 引 L3 决策来源,审计链)
- [ ] write lock 协议:`.akb-runtime/akb-write.lock` PID + heartbeat;单写者(承接 AUTOMATION §5 §7)
- [ ] 越权护栏:0 改 candidate / 0 改 11 docs/ ready 标准 / 0 改 8 docs/toolbox/ ready 标准 / 0 改 toolbox/<active>/ 内容 / 0 触碰旧 AKB / Project AKB
- [ ] 0 接旧 fetch / synth / translate / NLM / cron / 0 LLM
- [ ] 7 个 active 候选 final 状态:`wiki/<file>.md` 存在 + frontmatter `page_status: active` + `gate_decision: active` + `gate_reason` 由 reviewer 写权威理由(不引 proposed_gate_reason 文本)+ 至少 1 个 `related_*` 非空
- [ ] `wiki/sources/00-Index.md` / `wiki/synthesis/00-Index.md` / `wiki/designs/00-Index.md` 同步加新 active 链接(承接 FOLDER-STRUCTURE §1)
- [ ] **本 plan 不实施 C-2 Index updater**(本 plan 自己手工写 00-Index.md;C-2 是后续工具)

非目标:
- 不实施 C-1 / C-2 / C-4
- 不接旧 AKB 自动链路
- 不批量自动升 active(必须 reviewer 逐条)
- 不修改 ready 标准
- 不调用 LLM
- 不实施工具库 workspace 实战(那是平行轨道)

## §3. 当前 7 个 active 候选清单(承接 C-3 manifest)

| sample_id | candidate slug | 拟 active wiki path | template_type | proposed_graph_nodes 数 | l4 前置 |
|---|---|---|---|---|---|
| B1-001 | karpathy-intro-to-llms | `wiki/sources/karpathy-intro-to-llms.md` | source | 8 | materialize_graph_link |
| B1-002 | harness-engineering-deep-eval | `wiki/sources/harness-engineering-deep-eval.md` | source | 7 | materialize_graph_link |
| B1-003 | goal-driven-multi-agent-methodology | `wiki/sources/goal-driven-multi-agent-methodology.md` | source | 8 | materialize_graph_link |
| B1-006 | skill-description-vs-my-infra | `wiki/sources/skill-description-vs-my-infra.md`(若选 source)或 拆 wiki/sources + wiki/projects | source(模板边界 P3)| 6 | materialize_graph_link + reviewer 决定是否拆模板 |
| B1-007 | claude-code-skills-cross-call-patterns | `wiki/synthesis/claude-code-skills-cross-call-patterns.md` | synthesis | 6 | materialize_graph_link |
| B1-008 | jenny-wen-ai-design-philosophy | `wiki/designs/jenny-wen-ai-design-philosophy.md` | design | 7 | materialize_graph_link |
| B1-009 | figma-to-website-one-click-eval | `wiki/designs/figma-to-website-one-click-eval.md` | design | 6 | materialize_graph_link |

## §4. L4 提升流程(每条 candidate 5 步)

### Step 1 — reviewer 复核 candidate + L3 提议

reviewer 读:
- candidate 文件(staging/candidate/phase-b-validation/<slug>--phase-b--2026-05-03.md)
- C-3 L3 manifest 对应 record(`hard_checks` / `gate_reason_proposal` / `repair_actions`)
- candidate frontmatter `proposed_graph_nodes`

判定:
- ✅ 同意 active 提升 → 进 Step 2
- ❌ 否决 → 标 needs_human_review / archive / reject(不进 L4)
- ⏸ 推迟 → 留 candidate 状态(不变)

### Step 2 — materialize_graph_link(关键,L4 前置)

每个 `proposed_graph_nodes` 处理:

| 选项 | 动作 |
|---|---|
| 目标节点已存在 | 在新 active 页 frontmatter 加 `related_concepts: [[[concept-foo]]]` 等 — 真实 wikilink |
| 目标节点不存在 + reviewer 决定同期建 | 同 L4 plan 中创建目标节点(可能多个 active 同时建)|
| 目标节点不存在 + reviewer 决定推后建 | 写"待建节点 manifest"到 `manifests/ingest/<DATE>-pending-graph-nodes.jsonl`;新 active 用 `related_to: [{target: "[[concept-foo]]", reason: "pending creation, see manifest"}]` 弱关系 + reason |

**严禁**:仅靠 `proposed_graph_nodes` 字段就 active(承接 sample-register `proposed_graph_nodes` 边界 + INTAKE-GATE 不变量 4)。

### Step 3 — 创建 wiki/<file>.md(active 提升)

工具(`promote.py`,本 plan 实施时建)动作:

1. 读 candidate frontmatter + body
2. 转换 frontmatter:
   - `page_status: candidate` → `page_status: active`(同时加 `status: active` 兼容旧 PAGE-TEMPLATES — H6 backlog 双写)
   - `gate_decision: null` → `gate_decision: active`
   - `gate_reason`: **reviewer 提供**(不引 `proposed_gate_reason`)
   - `reviewer`: reviewer name
   - `reviewed_at`: 今日日期
   - `phase_b_sample`: 删除(active 后不需要)
   - 12 `related_*` 字段:reviewer 在 Step 2 materialize 后填
3. 创建 `wiki/<dir>/<slug>.md`
4. 不删 candidate(承接 LIFECYCLE — candidate 转 active 后保留 staging 文件作历史)

### Step 4 — 同步更新 `wiki/<dir>/00-Index.md`

加一行 active 链接(本 plan 手工做;C-2 Index updater 后续才自动化)。

### Step 5 — 写 L4 manifest record

每条 active 提升追加一行到 `manifests/ingest/<YYYY-MM-DD>.jsonl`:

```yaml
manifest_type: ingest
schema_version: akb-l4-promotion-v1
proposal_level: L4
operation: l4_active_promotion
operation_id: akb-l4-promote-<uuid12>
candidate_path: staging/candidate/phase-b-validation/<slug>--phase-b--2026-05-03.md
active_path: wiki/<dir>/<slug>.md
gate_decision: active
gate_reason: <reviewer 写的权威理由>
proposed_gate_reason_ref: <C-3 L3 manifest 中对应 record 的 gate_reason_proposal>(供审计链 — 但不被 active 用)
decision_refs:
  - l3_manifest_operation_id: akb-gate-check-08afbb57895a
  - l3_manifest_path: manifests/ingest/2026-05-04.jsonl
materialized_graph_nodes:
  - <list of created or matched concept/entity/source slugs>
pending_graph_nodes:
  - <list of nodes deferred>(若有,引 pending manifest)
actor: <reviewer-id>
reviewer_authorization: explicit
reviewer_authorization_at: <ISO timestamp>
forbidden_active_write_guard: false  # L4 是有授权的 active 写,与 L3 forbidden 区分
not_active_promotion: false  # L4 就是 active promotion
outcome: promoted
# 全局 §6.3 11 字段最小集
started_at: <ISO>
finished_at: <ISO>
source: "reviewer L4 promotion plan 2026-05-04"
reason: "C-3 L3 proposal accepted by reviewer with materialize_graph_link"
affected_files:
  - wiki/<dir>/<slug>.md
  - wiki/<dir>/00-Index.md
  - <created concept/entity files if any>
rollback: "rolled_back: false (active promotion; 不可自动回滚 — 删除走 LIFECYCLE archive)"
```

## §5. 工具范围

新建 `Codex/ai-infra/akb2/gate_check/promote.py`(承接 akb_gate_check.py 工程模式):

```bash
python3 promote.py promote \
  --akb-root "<AKB2.0>" \
  --candidate "staging/candidate/phase-b-validation/karpathy-intro-to-llms--phase-b--2026-05-03.md" \
  --active-path "wiki/sources/karpathy-intro-to-llms.md" \
  --gate-reason "<reviewer 写的权威理由>" \
  --reviewer "<name>" \
  --l3-manifest-ref "akb-gate-check-08afbb57895a" \
  --materialized-nodes "[[concept-large-language-model]],[[entity-andrej-karpathy]]" \
  --pending-nodes "[[concept-rlhf]]" \
  --execute  # 缺此 flag 是 dry-run
```

退出码:
- 0 OK
- 1 参数错误
- 2 越权写入风险(改了 candidate / 改了 ready 标准)
- 3 活锁 / stale lock
- 4 candidate 不存在 / L3 manifest 不可读 / target wiki path 已存在(active 不重复创建)

## §6. 不变量

- ❌ 不允许批量自动升(reviewer 逐条审)
- ❌ 不允许工具自己生成 `gate_reason`(必须 reviewer 提供 `--gate-reason` 参数)
- ❌ 不允许 candidate 缺 materialize_graph_link 就升(Step 2 必须先做)
- ❌ 0 修改 11 docs/ ready 标准 / 0 修改 8 docs/toolbox/ ready 标准
- ❌ 0 修改其他 candidate / staging
- ❌ 0 修改 wiki/<dir>/00-Index.md 之外的 active 内容
- ❌ 0 接旧 fetch / synth / translate / NLM / cron / 0 LLM
- ✅ 写 lock 必须 PID + heartbeat(承接 AUTOMATION §5.4)
- ✅ L4 manifest 必须含 `decision_refs` 引 L3 manifest(审计链)
- ✅ candidate 文件不删(LIFECYCLE 历史保留)

## §7. 边界与失败模式

必须阻断:
- target wiki path 已存在 → 退出 4(不覆盖 active)
- L3 manifest 不可读 / candidate 在 manifest 中不存在 → 退出 4
- 任何越权写入(改 candidate / ready 标准 / 其他 active)→ 退出 2
- candidate 缺 materialize_graph_link 路径 → 退出 1(reviewer 必须 specify)

允许但记录:
- candidate frontmatter 用 status 而非 page_status(H6 backlog) — 工具兼容 + 转换时双写

明确不处理:
- C-2 Index updater 自动化(本 plan 手工写 00-Index.md)
- 多 active 候选的批量升(逐条单写者)
- LIFECYCLE archive(active 删除是另一独立流程)

## §8. 测试计划

实施前(reviewer 复核本 plan 时):
- 仅本 plan 的 review,不实际跑 promote.py

实施期(reviewer 显式授权后):
- 7 个 active 候选逐条:
  - dry-run promote.py 看 active 文件预览
  - reviewer 看预览决策
  - 显式 `--execute` 跑
  - 验证 wiki/<dir>/<slug>.md 创建 + frontmatter 正确 + L4 manifest 一行追加
  - 验证 candidate 文件未改
  - 验证 ready 标准 0 改

实施后:
- 跑 `find wiki -newer manifests/ingest/2026-05-04.jsonl -name "*.md"` 确认只有 7 个新 active(+ 各目录 00-Index.md 更新)
- 跑 `find . -newer ... -name candidate -type d` → 0(candidate 0 改)
- 跑 `find docs -newer ... -name "*.md"` → 0(ready 标准 0 改)
- 出 `phase-c3-l4-active-promotion-validation-2026-05-04.md` 验证报告(承接 phase-c-reports/ 模式)

## §9. Reviewer 决策入口(本 plan 待用户批准点)

| 决策项 | 选项 |
|---|---|
| 7 个 active 候选**逐条审还是分批审** | 逐条(推荐) / 一组 7 条单 review |
| **reviewer 是谁** | 用户本人(需用户写 7 个 gate_reason) / 委托 Claude Code 出 7 个 gate_reason 草稿 + 用户复核 / 用户决定按需 |
| **proposed_graph_nodes 处理策略** | 全部同期建目标节点(7 active + N concept/entity ~ 30 文件)/ 全部 pending(只升 active 不建目标节点)/ 部分建 + 部分 pending |
| **实施时机** | 本会话立即跑 / 单独会话跑(更稳)/ 等其他事 |

## §10. 修订历史

| 日期 | 改动 | 作者 |
|---|---|---|
| 2026-05-04 | 初始本 plan(draft;未启动执行)— Phase C-3 reviewer L4 授权独立 plan;Phase A→D 第一次创建 wiki/ active 内容;7 个 active 候选 5 步流程(reviewer 复核 / materialize_graph_link / 创建 wiki/<file>.md / 同步 00-Index.md / 写 L4 manifest);0 自动升 / reviewer 逐条 / 不修改 ready 标准 / 0 接旧链路 / 0 LLM | Claude Code |
