---
title: Phase C-2 Toolbox Candidate Ranking — 2026-05-04
doc_type: phase-c-report
phase: C-2
report_kind: toolbox_candidate_ranking
automation_layer: L0_read_only
not_active_promotion: true
operation_id: akb2-c2-rank-ac62f71b4640
ranked_at: 2026-05-04T13:52:28Z
report_date: 2026-05-04
---

# Phase C-2 Toolbox Candidate Ranking — 2026-05-04

> Read-only ranking. Never executes a candidate, never promotes anything to active, and never modifies workspace tool source files.

## §1 Inputs

- AKB root: `/Users/praise/Library/Mobile Documents/iCloud~md~obsidian/Documents/Praise Space/AKB2.0`
- Output JSONL: `/Users/praise/Library/Mobile Documents/iCloud~md~obsidian/Documents/Praise Space/AKB2.0/manifests/toolbox-ranking/2026-05-04-toolbox-candidate-ranking.jsonl`
- Pilot limit: 20
- Source manifests:
  - `/Users/praise/Library/Mobile Documents/iCloud~md~obsidian/Documents/Praise Space/AKB2.0/manifests/workspace-scan/2026-05-04-toolbox-workspace-scan.jsonl`
  - `/Users/praise/Library/Mobile Documents/iCloud~md~obsidian/Documents/Praise Space/AKB2.0/manifests/workspace-scan/2026-05-04-toolbox-project-scripts-bin-scan.jsonl`

## §2 Population

- Total records ingested: **1616**
- Duplicate groups detected: 275
- Unique candidates after dedupe: 1227

## §3 Tier distribution

| tier | count |
|---|---|
| pilot_next | 20 |
| manual_review | 99 |
| defer | 1108 |
| exclude_this_round | 389 |

## §4 Detected kind distribution (informational)

| detected_kind | count |
|---|---|
| project_tool_script | 484 |
| project_script | 331 |
| codex_skill | 290 |
| claude_skill | 284 |
| claude_script | 95 |
| claude_hook | 59 |
| project_cli | 40 |
| project_bin | 33 |

## §5 Pilot batch (top of pilot_next)

> Recommended for C-3 small-batch drafting. Each record stays `not_active=true`; C-3 must still walk Tool Intake Gate.

| rank | tier | score | kind | slug | reason |
|---|---|---|---|---|---|
| 1 | pilot_next | 61 | codex_skill | `cc-akb-search` | phase_b_shadow_match |
| 12 | pilot_next | 31 | codex_skill | `cc-agent-design-patterns` | — |
| 5 | pilot_next | 61 | codex_skill | `cc-skill-stocktake` | phase_b_shadow_match |
| 11 | pilot_next | 31 | codex_skill | `cc-about-me` | — |
| 2 | pilot_next | 61 | codex_skill | `cc-executable-plan` | phase_b_shadow_match |
| 17 | pilot_next | 31 | codex_skill | `cc-agentic-engineering` | — |
| 20 | pilot_next | 31 | codex_skill | `cc-ai-regression-testing` | — |
| 15 | pilot_next | 31 | codex_skill | `cc-agent-sort` | — |
| 14 | pilot_next | 31 | codex_skill | `cc-agent-introspection-debugging` | — |
| 3 | pilot_next | 61 | codex_skill | `cc-local-llm` | phase_b_shadow_match |
| 18 | pilot_next | 31 | codex_skill | `cc-agentic-validate` | — |
| 4 | pilot_next | 61 | codex_skill | `cc-review` | phase_b_shadow_match |
| 13 | pilot_next | 31 | codex_skill | `cc-agent-harness-construction` | — |
| 16 | pilot_next | 31 | codex_skill | `cc-agentic-design` | — |
| 19 | pilot_next | 31 | codex_skill | `cc-ai-first-engineering` | — |
| 6 | pilot_next | 53 | claude_script | `review-result-writer` | phase_b_shadow_match, has_akb_backlink |
| 9 | pilot_next | 33 | claude_skill | `file-ingest` | has_akb_backlink |
| 10 | pilot_next | 33 | claude_skill | `obsidian-markdown` | has_akb_backlink |
| 7 | pilot_next | 33 | claude_skill | `architecture-diagram` | has_akb_backlink |
| 8 | pilot_next | 33 | claude_skill | `continue` | has_akb_backlink |

## §6 Manual review queue

- queue size: 99 (capped sample below: 25)

| score | kind | slug | reason | path |
|---|---|---|---|---|
| 11 | claude_hook | `desktop-notify` | — | `desktop-notify.js` |
| 11 | claude_hook | `pre-enter-plan-template` | — | `pre-enter-plan-template.js` |
| 14 | claude_hook | `run-with-flags-shell` | has_akb_backlink | `run-with-flags-shell.sh` |
| 41 | claude_hook | `execution-result-gate` | phase_b_shadow_match | `execution-result-gate.js` |
| 11 | claude_hook | `session-end-marker` | — | `session-end-marker.js` |
| 11 | claude_hook | `review-intent-marker` | — | `review-intent-marker.js` |
| 11 | claude_hook | `akb-knowledge-gate` | — | `akb-knowledge-gate.js` |
| 11 | claude_hook | `review-writer-required-gate` | — | `review-writer-required-gate.js` |
| 11 | claude_hook | `post-bash-build-complete` | — | `post-bash-build-complete.js` |
| 11 | claude_hook | `session-start-bootstrap` | — | `session-start-bootstrap.js` |
| 41 | claude_hook | `akb-ingest-gate` | phase_b_shadow_match | `akb-ingest-gate.js` |
| 11 | claude_hook | `evaluate-session` | — | `evaluate-session.js` |
| 11 | claude_hook | `review-chain-session-init` | — | `review-chain-session-init.js` |
| 11 | claude_hook | `run-with-flags` | — | `run-with-flags.js` |
| 11 | claude_hook | `review-stop-guard` | — | `review-stop-guard.js` |
| 11 | claude_hook | `session-start` | — | `session-start.js` |
| 11 | claude_hook | `session-end` | — | `session-end.js` |
| 11 | claude_hook | `config-protection` | — | `config-protection.js` |
| 11 | claude_hook | `cost-tracker` | — | `cost-tracker.js` |
| 11 | claude_hook | `post-taskupdate-todo-sync` | — | `post-taskupdate-todo-sync.js` |
| 11 | claude_hook | `auto-tmux-dev` | — | `auto-tmux-dev.js` |
| 11 | claude_hook | `pre-bash-git-push-reminder` | — | `pre-bash-git-push-reminder.js` |
| 11 | claude_hook | `pre-bash-tmux-reminder` | — | `pre-bash-tmux-reminder.js` |
| 11 | claude_hook | `stop-todo-gate` | — | `stop-todo-gate.js` |
| 11 | claude_hook | `user-prompt-workflow-priority` | — | `user-prompt-workflow-priority.js` |

## §7 Excluded this round (NOT a permanent rejection)

> `exclude_this_round` only means this candidate is skipped for the **next C-3 batch**. It is **not** a permanent rejection, **not** a deletion, and **not** a permanent ban. Future ranking rounds may revisit any record here.

| reason | count | sample |
|---|---|---|
| skip | 389 | `sod-set-working`, `check-projects-compliance`, `akb-prefetch` |

## §8 Duplicate groups (preferred kept, rest demoted)

- groups: 275 (sample below: 10)

- `dup-002f2daa` keyed on `sha256=950f608c14a78d16`; preferred = `/Users/praise/Library/Mobile Documents/com~apple~CloudDocs/Claude Code/Project AKB/toolbox/repos/claude code/cli/transports/ccrClient.ts`
     `/Users/praise/Library/Mobile Documents/com~apple~CloudDocs/Claude Code/Project CleanCC/backend/cli/transports/ccrClient.ts`
   ★ `/Users/praise/Library/Mobile Documents/com~apple~CloudDocs/Claude Code/Project AKB/toolbox/repos/claude code/cli/transports/ccrClient.ts`
- `dup-02f23f6c` keyed on `sha256=c23ed3f0688dab0f`; preferred = `/Users/praise/Library/Mobile Documents/com~apple~CloudDocs/Claude Code/Project AKB/toolbox/repos/claude code/tools/FileEditTool/prompt.ts`
     `/Users/praise/Library/Mobile Documents/com~apple~CloudDocs/Claude Code/Project CleanCC/backend/tools/FileEditTool/prompt.ts`
   ★ `/Users/praise/Library/Mobile Documents/com~apple~CloudDocs/Claude Code/Project AKB/toolbox/repos/claude code/tools/FileEditTool/prompt.ts`
- `dup-0493064a` keyed on `sha256=82e1e1cf15d40d15`; preferred = `/Users/praise/Library/Mobile Documents/com~apple~CloudDocs/Claude Code/Project AKB/toolbox/repos/claude code/tools/WebFetchTool/prompt.ts`
     `/Users/praise/Library/Mobile Documents/com~apple~CloudDocs/Claude Code/Project CleanCC/backend/tools/WebFetchTool/prompt.ts`
   ★ `/Users/praise/Library/Mobile Documents/com~apple~CloudDocs/Claude Code/Project AKB/toolbox/repos/claude code/tools/WebFetchTool/prompt.ts`
- `dup-0767f77b` keyed on `sha256=a1b0a8da8290f3bc`; preferred = `/Users/praise/Library/Mobile Documents/com~apple~CloudDocs/Claude Code/Project AKB/toolbox/repos/claude code/cli/transports/SerialBatchEventUploader.ts`
     `/Users/praise/Library/Mobile Documents/com~apple~CloudDocs/Claude Code/Project CleanCC/backend/cli/transports/SerialBatchEventUploader.ts`
   ★ `/Users/praise/Library/Mobile Documents/com~apple~CloudDocs/Claude Code/Project AKB/toolbox/repos/claude code/cli/transports/SerialBatchEventUploader.ts`
- `dup-0a7d98df` keyed on `sha256=988ffad70faf9be1`; preferred = `/Users/praise/Library/Mobile Documents/com~apple~CloudDocs/Claude Code/Project AKB/toolbox/repos/claude code/tools/RemoteTriggerTool/prompt.ts`
     `/Users/praise/Library/Mobile Documents/com~apple~CloudDocs/Claude Code/Project CleanCC/backend/tools/RemoteTriggerTool/prompt.ts`
   ★ `/Users/praise/Library/Mobile Documents/com~apple~CloudDocs/Claude Code/Project AKB/toolbox/repos/claude code/tools/RemoteTriggerTool/prompt.ts`
- `dup-0cf88e73` keyed on `sha256=73f61856f736a6e5`; preferred = `/Users/praise/Library/Mobile Documents/com~apple~CloudDocs/Claude Code/Project AKB/toolbox/repos/claude code/tools/WebFetchTool/preapproved.ts`
     `/Users/praise/Library/Mobile Documents/com~apple~CloudDocs/Claude Code/Project CleanCC/backend/tools/WebFetchTool/preapproved.ts`
   ★ `/Users/praise/Library/Mobile Documents/com~apple~CloudDocs/Claude Code/Project AKB/toolbox/repos/claude code/tools/WebFetchTool/preapproved.ts`
- `dup-0e9c6cb9` keyed on `sha256=fd37e87c31b0a790`; preferred = `/Users/praise/Library/Mobile Documents/com~apple~CloudDocs/Claude Code/Project AKB/toolbox/repos/claude code/tools/BashTool/destructiveCommandWarning.ts`
     `/Users/praise/Library/Mobile Documents/com~apple~CloudDocs/Claude Code/Project CleanCC/backend/tools/BashTool/destructiveCommandWarning.ts`
   ★ `/Users/praise/Library/Mobile Documents/com~apple~CloudDocs/Claude Code/Project AKB/toolbox/repos/claude code/tools/BashTool/destructiveCommandWarning.ts`
- `dup-0ed577a3` keyed on `sha256=36d21f3905e5762c`; preferred = `/Users/praise/Library/Mobile Documents/com~apple~CloudDocs/Claude Code/skills/brand/scripts/extract-colors.cjs`
   ★ `/Users/praise/Library/Mobile Documents/com~apple~CloudDocs/Claude Code/skills/brand/scripts/extract-colors.cjs`
     `/Users/praise/Library/Mobile Documents/com~apple~CloudDocs/Claude Code/skills/claude-active/brand/scripts/extract-colors.cjs`
- `dup-111a7528` keyed on `sha256=2c5c063918240ecb`; preferred = `/Users/praise/Library/Mobile Documents/com~apple~CloudDocs/Claude Code/Project AKB/toolbox/repos/claude code/tools/MCPTool/classifyForCollapse.ts`
     `/Users/praise/Library/Mobile Documents/com~apple~CloudDocs/Claude Code/Project CleanCC/backend/tools/MCPTool/classifyForCollapse.ts`
   ★ `/Users/praise/Library/Mobile Documents/com~apple~CloudDocs/Claude Code/Project AKB/toolbox/repos/claude code/tools/MCPTool/classifyForCollapse.ts`
- `dup-112d715d` keyed on `sha256=3227b3274a2294a7`; preferred = `/Users/praise/Library/Mobile Documents/com~apple~CloudDocs/Claude Code/Project AKB/toolbox/repos/claude code/tools/TaskUpdateTool/constants.ts`
     `/Users/praise/Library/Mobile Documents/com~apple~CloudDocs/Claude Code/Project CleanCC/backend/tools/TaskUpdateTool/constants.ts`
   ★ `/Users/praise/Library/Mobile Documents/com~apple~CloudDocs/Claude Code/Project AKB/toolbox/repos/claude code/tools/TaskUpdateTool/constants.ts`

## §9 C-3 recommendation

- Take 5-10 from the top of §5 (pilot_next, currently 20) into a C-3 small batch. Each picked record gets a draft registry / interface / eval; no record is allowed to skip Tool Intake Gate by virtue of a high C-2 score.
- `manual_review` queue (§6) needs human triage before any of those records can move into a future pilot batch.
- `exclude_this_round` (§7) is a per-round skip flag, not a verdict — re-rank as new evidence arrives.

## §10 Invariants self-check

- [x] every record carries `not_active: true`
- [x] every record carries `automation_allowed: false`
- [x] every record carries `gate_decision: null`
- [x] no candidate file was executed or imported
- [x] outputs land only in `manifests/toolbox-ranking/` and `docs/phase-c-reports/`
- [x] `exclude_this_round` is a per-round skip, not a deletion

