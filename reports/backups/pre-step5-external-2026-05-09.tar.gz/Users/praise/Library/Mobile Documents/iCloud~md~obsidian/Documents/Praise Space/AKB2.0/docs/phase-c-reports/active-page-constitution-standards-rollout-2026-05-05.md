---
title: AKB2.0 Active Page Constitution 标准收口 — 验证报告 2026-05-05
doc_type: phase-c-report
phase: C-4-active-page-constitution-standards-only
report_kind: standards_rollout_validation
automation_layer: L0
not_active_promotion: true
report_date: 2026-05-05
document_status: ready
canonical: true
follows_up:
  - l4-active-source-grounded-rewrite-validation-2026-05-04
authoritative_for: phase_c4_active_page_constitution_2026_05_05
---

# Active Page Constitution 标准收口 — 验证报告

> 本报告承接 v2 source-grounded rewrite 报告 [[l4-active-source-grounded-rewrite-validation-2026-05-04]] 的 §10 followup 与残余风险节;触发原因:用户在 Obsidian 实际打开 v2 active 页(如 [[harness-engineering-deep-eval]])后反馈"frontmatter 仍是 30-50 行 YAML wall,正文论证没起来" → 不可在已有标准框架下继续打补丁,必须**升级到宪法层** + 把"active 页是 source-grounded 知识文章,不是字段容器"写成不可绕过的硬规则。
> 本轮**只动 5 标准**(CONTENT-STANDARD + 4 子标准),不动任何 wiki/ / toolbox/ / staging/ / raw/ / manifests/ 真实内容;L4 active 重写留给下一轮。

---

## §1. 背景

| 项 | 值 |
|---|---|
| 上游 plan | "AKB2.0 Active 正文质量宪法收口" (用户 2026-05-05 提供完整 plan,supersede 了 14:21Z 直接修复请求) |
| 触发反馈 | harness-engineering-deep-eval.md frontmatter 53 行 + 第一个 H2 在 line 58 → Obsidian 第一屏全 YAML;v2 source-grounded 已修但 metadata wall 仍在 |
| 修改范围 | 5 标准文档(根 1 + 子 4),0 真实内容文件 |
| reviewer | praise + assisted_by Claude Code |
| 不变量 | 0 改 candidate / 0 改 toolbox active / 0 改 manifest / 0 改 staging / 0 改 raw |

---

## §2. 5 标准修改矩阵

| # | 文件 | 新增章节 | 行为效果 | 修订版本 |
|---|---|---|---|---|
| 1 | `AKB-2.0-CONTENT-STANDARD.md`(根) | §3.1 Active Page Constitution(5 子节)| 宪法层硬规则:active 页 = source-grounded knowledge article 不是字段容器;frontmatter ≤25 行硬上限;4 项硬门;supersede 表;冲突仲裁本节优先 | 2026-05-05 v1 收口 |
| 2 | `docs/AKB-2.0-PAGE-TEMPLATES.md` | §3.8 Frontmatter 短索引字段白名单(4 子节)+ §3.7.5 ≤30 行 → ≤25 行收紧 | 17 字段允许白名单(目标 15-20 行)+ 7 类禁止字段黑名单 + 12 类模板 supersede | v1.5 |
| 3 | `docs/AKB-2.0-INTAKE-GATE.md` | §4.2 active 标准追加第 9-11 项 + §5.1 Metadata Wall 拒收条件(8 失败模式表)+ §4.1 4 类 → 5 类 claim(新增 source_inference)| active 页拒收硬门:首屏可读 / frontmatter ≤25 / 正文必备结构齐;LLM 扩写边界明示 | v3 |
| 4 | `docs/AKB-2.0-LINT-RULES.md` | §11.3 Active Page Constitution 规则域(9 条规则,5 子节)| 9 条 lint 规则:METADATA-FRONTMATTER-WALL P1 / METADATA-ARTICLE-IN-YAML P1 / GRAPH-RELATION-IN-FRONTMATTER P2 / BODY-STARTS-TOO-LATE P1 / BODY-MISSING-TLDR P1 / BODY-MISSING-EVIDENCE-MAP P2 / BODY-MISSING-ARGUMENT P1 / BODY-CLAIM-PROVENANCE-MISSING P1 / BODY-UNSUPPORTED-CLAIM P1 + 与 §11.1/§11.2 覆盖关系 + 5 类 claim 表 | v1.4 |
| 5 | `docs/AKB-2.0-GRAPH-LINKING.md` | §9.6 frontmatter 轻量 link list 规则(6 子节)| frontmatter 只能写轻量 wikilink 列表(`["[[A]]"]`);完整 relation/strength/evidence 移正文 ## 图谱关系 表;manifest 承载审计;supersede 旧 PAGE-TEMPLATES §3.6.2 对象格式推荐 | v1.2 |

合计:**5 文件修改 + 1 新建报告 = 6 文件操作**;**0 删除**。

---

## §3. 不变量自检

| 不变量 | 状态 | 证据 |
|---|---|---|
| 0 改 candidate | ✅ | `find staging -newer LINT-RULES.md` 空 |
| 0 改 toolbox active | ✅ | `find toolbox -newer LINT-RULES.md` 空 |
| 0 改 wiki active | ✅ | `find wiki -newer LINT-RULES.md` 空 |
| 0 改 raw | ✅ | `find raw -newer LINT-RULES.md` 空 |
| 0 改 manifest | ✅ | manifest 仍 18 行(2026-05-04-l4-pilot.jsonl)|
| 4 子标准 status: ready 保持 | ✅ | grep `^status: ready` 4 子标准命中 |
| CONTENT-STANDARD 无 status 字段(根标准固有)| ✅ | grep 验证 |
| 不引入 LLM 推论或新 active 内容 | ✅ | 全程 Edit + Write 直接操作标准文档,纯结构添加 |
| 0 LLM ingest / 0 cron / 0 CLI | ✅ | 纯手工 Edit/Write |
| 5 标准修订历史均加 2026-05-05 行 | ✅ | grep 5 文件最后 1 行均为 2026-05-05 行 |

---

## §4. 5 标准协同实施关系图

```
[根]
AKB-2.0-CONTENT-STANDARD §3.1 (Active Page Constitution v1 收口)
  │ 4 项硬门
  │ supersede 规则表
  │ frontmatter ≤25 行
  │
  ├──→ PAGE-TEMPLATES §3.7.5 (≤25 行收紧) + §3.8 (字段白名单)
  │       │ 17 字段允许 + 7 类禁止
  │       │ 12 类模板按白名单 supersede
  │
  ├──→ INTAKE-GATE §4.2 (active 标准 9-11 项) + §5.1 (Metadata Wall 拒收)
  │       │ 首屏可读 / frontmatter ≤25 / 正文必备结构齐
  │       │ 8 失败模式 → LINT 规则映射
  │       │ §4.1 5 类 claim(新增 source_inference)
  │       │ LLM 扩写边界明示
  │
  ├──→ LINT-RULES §11.3 (Active Page Constitution 规则域)
  │       │ 9 条 P1/P2 规则
  │       │ 覆盖关系明示(升级原 §11.1/§11.2 P2 → P1)
  │       │ 5 类 claim Lint 检查
  │
  └──→ GRAPH-LINKING §9.6 (frontmatter 轻量 link list 规则)
          │ frontmatter 轻量 wikilink 列表
          │ 完整 relation/strength/evidence → 正文 ## 图谱关系 表
          │ supersede 旧 PAGE-TEMPLATES §3.6.2 对象格式推荐
```

---

## §5. 4 项硬门 → 5 标准实施对照(宪法 §3.1.3 落地)

| 宪法 §3.1.3 硬门 | INTAKE-GATE 拒收 | PAGE-TEMPLATES 字段约束 | LINT-RULES 检测 | GRAPH-LINKING 配套 |
|---|---|---|---|---|
| 1️⃣ 首屏可读(Obsidian 30-40 行内见 H1+TLDR+为什么值得入库) | §4.2 第 9 项 + §5.1 行 1 | §3.7.5 ≤25 行 + §3.8 白名单 | `BODY-STARTS-TOO-LATE` P1 + `METADATA-FRONTMATTER-WALL` P1 | — |
| 2️⃣ source-grounded(每段绑定证据 / 5 类 claim 明示)| §4.2 间接(承接 §4 第 8 条 + §4.1)| §3.7.2 三原则 | `BODY-CLAIM-PROVENANCE-MISSING` P1 + `BODY-UNSUPPORTED-CLAIM` P1 | — |
| 3️⃣ frontmatter ≤25 行硬上限 | §4.2 第 10 项 + §5.1 行 1 | §3.7.5 + §3.8.1 17 字段 + §3.8.2 7 类禁止 | `METADATA-FRONTMATTER-WALL` P1 + `METADATA-ARTICLE-IN-YAML` P1 + `GRAPH-RELATION-IN-FRONTMATTER` P2 | §9.6.2 frontmatter 轻量列表禁对象格式 |
| 4️⃣ 正文必备结构齐(8 节最小集 + alias)| §4.2 第 11 项 | §3.7.3 8 节最小推荐 | `BODY-MISSING-TLDR` P1 + `BODY-MISSING-EVIDENCE-MAP` P2 + `BODY-MISSING-ARGUMENT` P1 | §9.6.3 ## 图谱关系 表必备 |

---

## §6. supersede 关系汇总(本轮显式 supersede 旧规则)

| 旧规则 | supersede 规则 | severity 变化 |
|---|---|---|
| PAGE-TEMPLATES §3.6.2 frontmatter 对象格式 `target/relation/strength/evidence` | GRAPH-LINKING §9.6.2 + LINT-RULES `GRAPH-RELATION-IN-FRONTMATTER` P2 | 推荐 → 禁止(对象格式只能写正文表)|
| LINT-RULES §11.2 `METADATA-WALL-FRONTMATTER-OVERSIZE` P2(> 30 行) | LINT-RULES §11.3.1 `METADATA-FRONTMATTER-WALL` P1(> 25 行) | P2 → P1(阻断 active)|
| LINT-RULES §11.2 `METADATA-WALL-CORE-SUMMARY-IN-YAML` P2 ✅ auto_fix | LINT-RULES §11.3.1 `METADATA-ARTICLE-IN-YAML` P1(覆盖 core_summary + 长 gate_reason + 长 future_questions + 嵌套对象)| P2 → P1;auto_fix 不再可用 |
| LINT-RULES §6 `BODY-QUALITY-MISSING-TLDR` P1(模板域)| LINT-RULES §11.3.2 `BODY-MISSING-TLDR` P1(宪法域)| 沿用 P1,模板域规则保留作为 §6 引用 |
| LINT-RULES §11.2 `BODY-QUALITY-NO-EVIDENCE-MAP` P2 | LINT-RULES §11.3.2 `BODY-MISSING-EVIDENCE-MAP` P2 | 沿用 P2 |
| LINT-RULES §11.2 `SOURCE-GROUNDED-CLAIM-UNTAGGED` P2 | LINT-RULES §11.3.3 `BODY-CLAIM-PROVENANCE-MISSING` P1(核心论点章节内升级)| P2 → P1(限定核心论点章节内)|
| INTAKE-GATE §4.1 4 类 claim | INTAKE-GATE §4.1 5 类 claim(新增 source_inference)| 扩展(向后兼容)|

---

## §7. 下一轮工作交接(L4 active 内容重写)

> 本轮**不重写任何 active 内容**;以下为下一轮交接清单。

### §7.1 待重写 active 列表(7 文件,按宪法 §3.1.3 4 项硬门)

| 文件 | 当前 frontmatter 行数(估)| 当前 evidence_provenance | 重写优先级 |
|---|---|---|---|
| `wiki/sources/harness-engineering-deep-eval.md` | ~53 | bridging_source_grounded | 高(用户首篇反馈对象,作为样板)|
| `wiki/sources/karpathy-intro-to-llms.md` | ~50 | bridging_source_grounded | 高 |
| `wiki/sources/jenny-wen-ai-design-philosophy.md` | ~45 | bridging_source_grounded | 高 |
| `wiki/concepts/large-language-model.md` | ~40 | bridging_source_grounded | 中(orphan_risk)|
| `wiki/concepts/harness-engineering.md` | ~45 | bridging_source_grounded | 中 |
| `wiki/concepts/context-engineering.md` | ~40 | bridging_source_grounded | 中(orphan_risk)|
| `wiki/designs/implementation-aware-design.md` | ~45 | bridging_source_grounded | 中 |

### §7.2 重写要求(必须满足宪法 §3.1.3 4 项硬门)

每个 active 重写时:

1. **frontmatter 收紧到 ≤25 行**(目标 15-20),按 PAGE-TEMPLATES §3.8.1 17 字段白名单
2. **删 frontmatter 中**:`core_summary`(改写到正文 ## TLDR)/ 长 `gate_reason`(>120 字 → 正文 ## 为什么值得入库)/ 长 `future_questions`(每条 >80 字 → 正文 ## Future Questions)/ 复杂 `related_*` 对象(对象格式 → 正文 ## 图谱关系 表 + frontmatter 留轻量 wikilink 列表)/ 嵌套 `origin / l4_manifest_ref / decision_refs`(展开为短标量字段或写 manifest 路径字符串)
3. **正文必备 8 节齐**(承接 §3.7.3 + alias 表):`## TLDR` / `## 为什么值得入库` / `## 证据地图` / `## 核心论点`(或 alias) / `## 论证与解释` / `## 适用边界` / `## 图谱关系` / `## Future Questions` / `## 维护记录`
4. **正文每段绑定证据**(承接 §4.1 5 类 claim):source_fact 引 source / source_inference 标"基于 source §X+§Y 推论" / akb_interpretation 标"AKB2.0 视角:" / user_judgment 标"praise 认为:" / agent_draft 标"⚠️ Claude Code 草拟,待 review"
5. **首屏可读**:H1 + ## TLDR + ## 为什么值得入库 必须在 Obsidian 默认视窗第一屏(约 30-40 行)内可见
6. **manifest 追加重写 record**:`operation: l4_v3_constitution_rewrite`,逐文件记录
7. **不引入新 LLM 推论**:严格 source-grounded;若发现 v2 重写仍含 LLM 扩写段(无 source 锚 + 无 4.1 类 claim 前缀)→ 删除或加 source

### §7.3 推荐重写顺序

1. **harness-engineering-deep-eval.md**(用户首篇反馈对象,作为样板,先修一篇过 review 再批量)
2. 通过 review 后批量套到其余 6 个 active

### §7.4 验收准则(下一轮)

- 7 active frontmatter 全部 ≤25 行 → `METADATA-FRONTMATTER-WALL` 0 命中
- 7 active 第一个 H2 ≤ line 30 → `BODY-STARTS-TOO-LATE` 0 命中
- 7 active 正文 ## TLDR ≥ 100 字 → `BODY-MISSING-TLDR` 0 命中
- 7 active 正文 ## 证据地图 / ## 核心论点(或 alias)/ ## 图谱关系 全部存在 → `BODY-MISSING-EVIDENCE-MAP` / `BODY-MISSING-ARGUMENT` 0 命中
- 7 active 核心论点章节段落均有证据锚 → `BODY-CLAIM-PROVENANCE-MISSING` 0 命中
- frontmatter `related_*` 全部为轻量 wikilink 列表(无对象格式)→ `GRAPH-RELATION-IN-FRONTMATTER` 0 命中
- Obsidian 实际打开 7 active,第一屏均可见 H1 + TLDR + 为什么值得入库

---

## §8. 残余风险

| 风险 | 评估 |
|---|---|
| 5 标准内部协调(本轮新增多处 supersede,可能与历史章节产生潜在冲突)| 低 — supersede 关系全部明示;如有冲突由宪法 §3.1.5 冲突仲裁(本节优先);Codex review 可复核 |
| 7 active 真实内容尚未按宪法重写 → 当前 active 状态实际**违反宪法 §3.1.3** | 高(已知 — **本轮不修复**)— 标准已就位但内容未对齐;下一轮 §7 重写后才闭环;在此期间 7 active 处于"历史不合规但未降级"过渡态;Lint CLI 上线后会全部出 P1 finding |
| Lint CLI 未实现 → 9 条 §11.3 规则只是文档约束 | 中 — 与现有 §11.1/§11.2/§11/§10 全 lint 域同状态(Phase A-7 定义 + 阶段 C 实施);本宪法补丁不引入新延期 |
| 用户 Obsidian 实际查看体验未即时改善 | 高(本轮预期 — **本轮不解决**)— 5 标准修改后 Obsidian 打开 active 体验不变;必须等 §7 active 重写完成才改善;用户 plan 已明示本轮"只动标准不动内容" |
| 历史 active 中 `core_summary` / 长 `gate_reason` / 嵌套对象 / 复杂 related_* 对象广泛存在 | 中 — H6 全库迁移留独立 phase(已在 v2 残余风险记录);本轮宪法补丁是迁移的标准前提条件 |
| INTAKE-GATE §4.1 5 类 claim 与 LINT-RULES §11.3.5 5 类一致;但 PAGE-TEMPLATES §3.7.x 仍写 4 类 | 低 — INTAKE-GATE 是 claim 类型权威源,PAGE-TEMPLATES 章节引用 INTAKE-GATE §4.1;v3 修订历史已注明 5 类(新增 source_inference);如需可在 PAGE-TEMPLATES §3.7.2 加注释指向 INTAKE-GATE §4.1 5 类(留 v3.1)|

---

## §9. 与 v2 报告 §10 的连接

v2 报告 [[l4-active-source-grounded-rewrite-validation-2026-05-04]] §8 残余风险列出了:

> "**v2 自我命中 LINT P2**:`METADATA-WALL-FRONTMATTER-OVERSIZE`(7 active frontmatter 37-53 行,超 §3.7.5 ≤30 行硬上限) — **PARTIAL — 承认未达**:根因是 §3.6.2 推荐的"对象格式 `related_*`"... 留 v3 考虑放宽到 50 行,或允许对象格式 evidence 字段下放正文 ## 图谱关系 表"

**本轮 v3 选择了后者**(放宽 frontmatter 行数被 reject;改为对象格式 evidence 下放正文 ## 图谱关系 表 + frontmatter 收紧到 ≤25 行 + 严格白名单 + supersede 旧 §3.6.2 对象格式推荐)。v2 残余风险中提到的"v3 应在 §3.7.5 / §3.6.2 / LINT-RULES META-WALL-FRONTMATTER-OVERSIZE 三处协调一致"已通过本轮:

- §3.7.5 ≤30 → ≤25 行(收紧)
- §3.6.2 推荐对象格式 → §3.8.2 + GRAPH-LINKING §9.6.2 supersede(禁止)
- LINT-RULES §11.2 `METADATA-WALL-FRONTMATTER-OVERSIZE` P2 → §11.3.1 `METADATA-FRONTMATTER-WALL` P1(升级)

三处协调已闭环。

---

## §10. 文件清单

### 修改(5 文件)

```
AKB-2.0-CONTENT-STANDARD.md          (新增 §3.1 Active Page Constitution + §16 修订历史)
docs/AKB-2.0-PAGE-TEMPLATES.md       (新增 §3.8 + §3.7.5 收紧 + §15 修订历史)
docs/AKB-2.0-INTAKE-GATE.md          (新增 §4.2 + §5.1 + §4.1 5 类 + §13 修订历史)
docs/AKB-2.0-LINT-RULES.md           (新增 §11.3 9 条规则 + §18 修订历史)
docs/AKB-2.0-GRAPH-LINKING.md        (新增 §9.6 + §15 修订历史)
```

### 新建(1 文件)

```
docs/phase-c-reports/active-page-constitution-standards-rollout-2026-05-05.md  (本报告)
```

合计:**5 修改 + 1 新建 = 6 文件操作**;**0 删除**;**0 改 candidate / toolbox / wiki / raw / staging / manifest**。

---

## §11. 修订历史

| 日期 | 改动 | 作者 |
|---|---|---|
| 2026-05-05 | 初始本验证报告 — Phase C-4 active page constitution 标准收口轮;5 标准修改 + 1 新建报告;0 改真实内容;承接 v2 §8 残余风险闭环;§7 交接清单移交下一轮 active 重写 | praise + Claude Code |
