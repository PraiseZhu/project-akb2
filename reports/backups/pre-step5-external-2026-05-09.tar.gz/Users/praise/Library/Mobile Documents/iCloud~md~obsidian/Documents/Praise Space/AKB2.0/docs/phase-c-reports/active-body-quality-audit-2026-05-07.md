---
report_type: phase_c_active_body_quality_audit
report_id: active-body-quality-audit-2026-05-07
date: 2026-05-07
scope: wiki/** active 全集（含 wiki/tools；明确排除 toolbox/**）
predecessor_reports:
  - docs/phase-c-reports/phase-c1-active-usability-validation-2026-05-06.md
  - docs/phase-c-reports/phase-c2-query-gap-closure-2026-05-07.md
manifest: manifests/ingest/2026-05-07-active-body-quality-repair.jsonl
verdict: PASS
---

# AKB2.0 Phase C3 — Active 正文质量宪法验收闭环报告

## 执行摘要

C1 / C2 完成 10 篇 source/concept/design active；本轮 C3 把审计扩到全 wiki/** active 集合，**首次纳入 wiki/tools active**。

**结论**：`PASS`

- 10 篇 source/concept/design active：**全部 pass**（C1+C2 已审 APPROVED；C3 别名兼容验收 0 MISS）
- 2 篇 wiki/tools active（cc-executable-plan / cc-review）：**全部 demote_candidate**（fm/body status 矛盾 + META-WALL P1 + 缺 6/9 必备节 + 死链 + tool-understanding 模板无 active gate spec）
- demote 后 wiki/** active 全集干净：10 篇全部 source-grounded（4 source_grounded + 6 bridging_source_grounded，详见 §2）+ 全部 9 必备节齐 + frontmatter 17-23 行
- 4 条标准冲突进 §"标准冲突清单"，本轮按 plan 不修标准 doc

---

## §1. 章节别名映射表（用户确认 A 路径，2026-05-07）

C1+C2 已审页面采用旧节名；C3 plan 列新名。本表确立别名兼容，避免误判 repair。

| canonical（C3 plan 列） | 接受别名（C1/C2 实际页面用）|
|---|---|
| `## TLDR` | （无别名，统一） |
| `## 为什么值得入库` | `## 入选理由`、`## 这工具是什么`、`## 解决什么问题`（tool-understanding 用） |
| `## 证据地图` | （无别名，统一） |
| `## 核心观点` | `## 核心论点`、`## 概念定义`（concept template）、`## 标签级主题清单`（karpathy walkthrough）、`## 设计原则陈述`（design）、`## 主题要点` |
| `## 论证与解释` | （无别名，统一） |
| `## 适用边界` | `## 何时用` + `## 何时不用`（tool-understanding 用，需两个并存） |
| `## 图谱关系` | `## 关联概念` + `## 关联工具`（tool-understanding 用） |
| `## Future Questions` | `## 后续缺口` |
| `## 维护记录` | （无别名，统一） |

**约定**：
- 任一别名出现 = 该必备节 PASS
- 别名出现 ≠ 模板规范化要求；仅作"避免误判 repair"使用
- canonical 名待后续标准修订任务统一

---

## §2. wiki/** active 全集审计表

`wiki/projects/` / `wiki/synthesis/` / `wiki/entities/` 当前为空目录，无 active；本轮不涉。

| # | 路径 | tt | fm | H2 | 别名兼容必备节 | evidence_level | graph_status | allowed_rewrite_depth | decision |
|---|---|---|---|---|---|---|---|---|---|
| 1 | `wiki/sources/karpathy-intro-to-llms.md` | source | 22 | 28 | 9/9 ✅ | bridging_source_grounded | orphan_risk | no_rewrite_until_source | **pass** |
| 2 | `wiki/sources/harness-engineering-deep-eval.md` | source | 23 | 27 | 9/9 ✅ | bridging_source_grounded | healthy | bounded_rewrite | **pass** |
| 3 | `wiki/sources/jenny-wen-ai-design-philosophy.md` | source | 22 | 28 | 9/9 ✅ | bridging_source_grounded | healthy | bounded_rewrite | **pass** |
| 4 | `wiki/sources/mcp-spec.md` | source | 22 | 26 | 9/9 ✅ | source_grounded | healthy | deep_rewrite | **pass** |
| 5 | `wiki/sources/anthropic-effective-context-engineering.md` | source | 22 | 26 | 9/9 ✅ | source_grounded | healthy | deep_rewrite | **pass** |
| 6 | `wiki/concepts/large-language-model.md` | concept | 17 | 23 | 9/9 ✅ | bridging_source_grounded | orphan_risk | no_rewrite_until_source | **pass** |
| 7 | `wiki/concepts/harness-engineering.md` | concept | 18 | 22 | 9/9 ✅ | bridging_source_grounded | healthy | bounded_rewrite | **pass** |
| 8 | `wiki/concepts/context-engineering.md` | concept | 17 | 21 | 9/9 ✅ | source_grounded | healthy | deep_rewrite | **pass** |
| 9 | `wiki/concepts/mcp-tool-use.md` | concept | 17 | 21 | 9/9 ✅ | source_grounded | healthy | deep_rewrite | **pass** |
| 10 | `wiki/designs/implementation-aware-design.md` | design | 18 | 24 | 9/9 ✅ | bridging_source_grounded | healthy | bounded_rewrite | **pass** |
| 11 | `wiki/tools/cc-executable-plan.md` | tool-understanding | 14 → 11（demote 后）| 20 | 3/9（缺 TLDR / 证据地图 / 核心论点 / 论证与解释 / Future Questions / 维护记录）| n/a（模板无 evidence_provenance）| n/a | n/a | **demote_candidate** |
| 12 | `wiki/tools/cc-review.md` | tool-understanding | 14 → 11（demote 后）| 20 | 3/9（同上） | n/a | n/a | n/a | **demote_candidate** |

> **fm 数字说明**：tools 两行 fm 值左 = 审计发现时（demote 前），右 = 本轮 demote 后；其余 10 行 fm 值审计前后未变（pass 决议不动 frontmatter）。

### 三级标注分布

**evidence_level**：
- source_grounded：4 篇（mcp-spec / anthropic-CE / concept-CE / concept-MCP）
- bridging_source_grounded：6 篇（karpathy / harness-NLM / jenny / concept-LLM / concept-HE / IAD）
- n/a：2 篇（tools demote）

**allowed_rewrite_depth**：
- deep_rewrite：4 篇（同 source_grounded）
- bounded_rewrite：4 篇（jenny / harness-NLM / concept-HE / IAD）
- no_rewrite_until_source：2 篇（karpathy / concept-LLM；BL-C1-001 deferred）
- n/a：2 篇（tools demote）

**decision**：
- pass：10 篇（全部 source/concept/design）
- demote_candidate：2 篇（全部 wiki/tools）
- repair / source_needed / archive：0

---

## §3. wiki/tools/ 单列审计结论

按 plan §3 "wiki/tools/ 先审计，再决定 repair 范围"，本节单列。

### §3.1 wiki/tools/ 全集

| 文件 | status | 备注 |
|---|---|---|
| `cc-executable-plan.md` | active → **candidate**（C3 demote） | 见下方分析 |
| `cc-review.md` | active → **candidate**（C3 demote） | 同上 |
| `cc-akb-search.md` | candidate | 不在 wiki/** active 范围 |
| `cc-local-llm.md` | candidate | 同上 |
| `cc-skill-stocktake.md` | candidate | 同上 |

### §3.2 cc-executable-plan + cc-review demote 理由（5 项）

1. **fm/body status 矛盾**
   - frontmatter 写 `status: active`
   - 正文 line 18 写 `> **状态**:`candidate` — C-3 候选建档,不是 active 工具;不可作为生产调用入口。`
   - 任意一处需修改才一致；body 才是作者意图，frontmatter 是历史晋升残留

2. **META-WALL P1 触发**（INTAKE-GATE §5.1）
   - cc-executable-plan.md `status_change_reason` 字段值 259 字符
   - cc-review.md `status_change_reason` 字段值 276 字符
   - INTAKE-GATE §5.1 列 `gate_reason >120 字 / 长 narrative 字段` → `META-ARTICLE-IN-YAML` P1 拒收
   - 两页都触发

3. **缺 6/9 必备节**（别名兼容后）
   - 缺：TLDR / 证据地图 / 核心论点 / 论证与解释 / Future Questions / 维护记录
   - 有别名命中：入选理由（这工具是什么 + 解决什么问题）/ 适用边界（何时用 + 何时不用）/ 图谱关系（关联概念 + 关联工具）

4. **死链 / 跨边界引用**
   - cc-executable-plan：3 死链（2 个 待建 + 1 个 toolbox/）
   - cc-review：3 死链（2 个 待建 + 1 个 toolbox/）
   - `[[../../toolbox/tools/...]]` 跨 wiki ↔ toolbox 边界，违反 plan 约束（toolbox/** 明确不在本轮 wiki/** active 范围）

5. **tool-understanding 模板无 active gate spec**
   - INTAKE-GATE §4 active 7-item checklist + §4.2 4 项追加，未规定 tool-understanding 模板的 active 标准
   - PAGE-TEMPLATES §3.7.3 给的 active 9 必备节规范是基于 source/concept/design 模板写的
   - 当前 tool-understanding 模板使用的"这工具是什么 / 解决什么问题 / 何时用 / 何时不用 / 风险与限制 / Claude / Codex 使用判断 / 关联概念 / 关联工具 / 边界声明"是另一套结构
   - 没有标准 spec 就没法判定 active；安全做法是 demote 到 candidate 等标准化

### §3.3 demote 执行细节

- 备份 → `archive/active-pre-body-quality-2026-05-07/{cc-executable-plan,cc-review}.md`
- frontmatter 改动：
  - `status: active` → `status: candidate`
  - `status_changed_at: 2026-05-06` → `2026-05-07`
  - `status_change_reason: <C-5b Tool Intake Gate ...259 字...>` → `Phase C3 demote — fm/body status 矛盾(body 自陈 candidate)+ 缺 6/9 必备节 + tool-understanding 模板无 active gate spec；详见 manifests/ingest/2026-05-07-active-body-quality-repair.jsonl`
  - 删除 `prior_status: needs_repair` → 改为 `prior_status: active`（demote 前实际状态）
  - 删除 `prior_status_changed_at` 旧值 → 加新值 `2026-05-06`
  - 删除 `phase_b_shadow_match` / `c3_round` / `last_verified_at` 三个旧审计 cruft 字段
- frontmatter 行数：14 → 11
- **正文不改**（决议是 demote，非 rewrite；待 tool-understanding 标准化后再决定如何升 active）

### §3.4 wiki/tools 后续路径

后续若要让 cc-executable-plan / cc-review 重新 active，需先做（不在本轮）：

1. 在 INTAKE-GATE / PAGE-TEMPLATES 增 tool-understanding 模板 active 规范
2. 标准化"这工具是什么 / 解决什么问题 / 何时用 / 何时不用"是否等同于 9 必备节中的某些 alias
3. 决定 tool-understanding 是否需要 evidence_provenance / graph_role / graph_status 等字段
4. 解决与 toolbox/** 的边界（wiki/tools 是理解层，toolbox/tools 是可执行层；当前 link 跨边界）

进 BL-C3-001（标准冲突）。

---

## §4. Obsidian 阅读体验验收（抽样 3 篇）

按 plan §5 "抽样至少 3 篇：source、concept、design 各 1 篇"。

| 抽样 | 路径 | fm | 阅读视图首屏可见正文核心 | 静态判定 |
|---|---|---|---|---|
| source | wiki/sources/mcp-spec.md | 22 | static-pass（fm 22 行 + 有 H1 + ## TLDR 1500+ 字段，正文层次分明） | pending_user_visual_check |
| concept | wiki/concepts/context-engineering.md | 17 | static-pass（fm 17 行最短，TLDR 段落紧接 H1） | pending_user_visual_check |
| design | wiki/designs/implementation-aware-design.md | 18 | static-pass（fm 18 行 + H1 + TLDR 立即可见） | pending_user_visual_check |

**说明**：
- 静态判定：fm ≤ 25 + 必备节齐 + TLDR 在正文起始 = 不会有 metadata 墙
- 实际阅读视图需用户在 Obsidian 中打开判定；继承 C1+C2 的 `pending_user_visual_check` 状态

---

## §5. 不变量验收

| 检查项 | 状态 | 证据 |
|---|---|---|
| 10 篇 source/concept/design active 内容未改 | pass | mtime 全部 ≤ 5/7（最近一次是 5/7 15:03 CE concept v4 + harness link，C3 操作时间 5/7 16:28 之后无任何 source/concept/design 改动） |
| C2 manifest（2026-05-07-c2-query-gap-closure.jsonl）未改 | pass | 9 行未变 |
| C2 raw 归档未改 | pass | 2 个 raw 文件未动 |
| 旧 manifest 2026-05-04-l4-pilot.jsonl / 2026-05-05-active-rewrite.jsonl 未追加 | pass | 18 / 7 行未变 |
| `toolbox/**` 未改 | pass | 本轮无 toolbox 操作 |
| `docs/AKB-2.0-*` 标准 doc 未改 | pass | 4 条标准冲突仅记 §6 backlog；无任何 standards doc 修改 |
| `raw/**` / Obsidian 配置 / 自动化 / 旧 AKB / Project AKB | pass | 本轮全未触及 |
| 备份齐 | pass | `archive/active-pre-body-quality-2026-05-07/` 含 2 个 tools v1 备份 |

---

## §6. 标准冲突清单（仅记录，本轮不修）

按 plan §6 + 用户确认第 3 点："标准文档只记录冲突，不在本窗口顺手改"。以下进 backlog，待后续单开标准修订任务。

### BL-C3-001 [P2]：tool-understanding 模板无 active gate spec

- **触发**：cc-executable-plan / cc-review demote 时发现
- **现状**：INTAKE-GATE §4 active 7-item + §4.2 4 项追加 + PAGE-TEMPLATES §3.7.3 9 必备节，全部基于 source/concept/design 模板；tool-understanding 模板没有专属 active 标准
- **影响**：tool-understanding 类页面无法被门控规则评判，只能 candidate 或绕过门控
- **建议**：后续标准修订任务在 INTAKE-GATE 加 §4.3 "tool-understanding active 追加标准"（含 9 必备节是否必备 + 是否需要 evidence_provenance 等字段 + 与 toolbox/tools 的边界规则）

### BL-C3-002 [P2]：META-WALL P1 规则未明示禁 `status_change_reason` 长字段

- **触发**：cc-executable-plan / cc-review 的 status_change_reason 259/276 字
- **现状**：INTAKE-GATE §5.1 META-WALL 表只列 `core_summary` / `gate_reason >120 字` / `future_questions` / `origin/l4_manifest_ref/decision_refs` 长字段
- **影响**：`status_change_reason` 不在禁列，但语义上同样是 narrative wall；现行规则未捕获
- **建议**：在 INTAKE-GATE §5.1 META-WALL 表加通用规则 "任何 frontmatter 字符串字段 >120 字符 → META-ARTICLE-IN-YAML P1"

### BL-C3-003 [P2]：节标题别名映射未在标准中固化

- **触发**：C3 别名映射表（§1）作用全靠本报告记录
- **现状**：PAGE-TEMPLATES §3.7.3 仅列 canonical 节名 + LINT-RULES BODY-QUALITY-MISSING-STRUCTURE alias 规则提及"alias 规则"但未列具体映射
- **影响**：未来 lint CLI 实现 / 新 reviewer 上手时缺 canonical 别名表，可能误判 active 缺节
- **建议**：在 PAGE-TEMPLATES §3.7.3 加"节名 canonical + 别名映射表"，固化 §1 的 9 行映射

### BL-C3-004 [P3]：wiki/tools 与 toolbox/tools 边界规则未明示

- **触发**：cc-executable-plan / cc-review 中 `[[../../toolbox/tools/...]]` 跨边界 wikilink
- **现状**：FOLDER-STRUCTURE / NAMING-CONVENTION 把 wiki/ 与 toolbox/ 分层，但未明示"wiki/tools/ 不应直接 wikilink toolbox/tools/"或"应通过哪种关系字段引用"
- **影响**：wiki/tools 理解层与 toolbox/tools 可执行层关联机制不清；继续放任会造成两套体系互相穿透
- **建议**：在 FOLDER-STRUCTURE 加 wiki/ ↔ toolbox/ 边界规则（推荐：wiki/tools 通过 frontmatter `references_toolbox: [...]` 字段引用，正文用纯文本说明，不用 wikilink）

---

## §7. C1/C2 backlog 追溯（C3 视角更新）

| C1/C2 backlog | C2 状态 | C3 视角 |
|---|---|---|
| BL-C1-001 Karpathy transcript / LLM concept 升级 | deferred | 仍 deferred；karpathy / concept-LLM 在 C3 审计中明确标 `no_rewrite_until_source` |
| BL-C1-002 MCP tool-use concept | closed (C2) | C3 审计验证 mcp-spec / concept-mcp-tool-use 全 pass |
| BL-C1-003 CE 专门 source | closed (C2) | C3 审计验证 anthropic-CE / concept-CE 全 pass |
| BL-C1-004 entity-claude-code 等 | open P2 | C3 不动；wiki/entities/ 仍空目录 |
| BL-C1-005 design tokens governance | open P2 | C3 不动 |
| BL-C1-006 entity-anthropic 等 | open P2 | C3 不动 |
| BL-C1-007 LLM concept 上游单源 | open P2 | C3 不动；与 BL-C1-001 联动 |
| BL-C1-008 LLM frontmatter CE 直链 | open P3 | C3 不动 |
| BL-C2-001 mcp-spec OAuth 完整 flow | open P2 | C3 不动 |
| BL-C2-002 Sampling/Elicitation 完整模式 | open P2 | C3 不动 |
| BL-C2-003 "正文质量宪法" 4 条规则升标准 | open P3 | **本轮 C3 通过审计 + demote 实操，规则缺口扩到 4 条新（BL-C3-001~004）；建议合并 BL-C2-003 + BL-C3-001~004 单开"标准修订"plan** |
| BL-C2-004/005 Pending 节点 21 个 | open P3 | C3 不动 |

---

## §8. C3 新增 backlog 汇总

| ID | 类别 | 描述 |
|---|---|---|
| BL-C3-001 | P2 | tool-understanding 模板无 active gate spec（详见 §6） |
| BL-C3-002 | P2 | META-WALL P1 未明示禁 `status_change_reason` 等通用 frontmatter 长字段 |
| BL-C3-003 | P2 | 节标题别名映射未在 PAGE-TEMPLATES §3.7.3 固化 |
| BL-C3-004 | P3 | wiki/tools ↔ toolbox/tools 边界规则未明示 |

---

## §9. Review 结论

verdict: **PASS**

理由：
- 12 篇 wiki/** active 全部审计完毕；含 wiki/tools active（plan §"必须处理 - wiki/tools active 页面遗漏" 已闭环）
- 别名兼容映射表确立（plan 用户确认 A 路径），10 篇 C1+C2 已审 active 不被误判 repair
- decision 三级（pass / demote_candidate / 其他）严格，0 LLM 自编扩写，0 越界改 docs/AKB-2.0-* 标准
- 2 篇 wiki/tools demote 严格按 plan "demote_candidate" 决议执行；不假装升级
- BL-C1-001 (Karpathy) 持续标 `no_rewrite_until_source`，不强行升 source-grounded
- 4 条标准冲突进 §6 backlog，等单开标准修订 plan

下一步等用户决定：
- 单开 plan 处理 BL-C3-001~004（合并 BL-C2-003 一起做"标准修订"plan）
- 或先休停 C3，等 wiki/projects / wiki/synthesis / wiki/entities 有新 active 入库再启 C4
- Obsidian 抽查继续 pending_user_visual_check（用户给截图后再翻 user-confirmed）

---

## §10. 维护记录

| 日期 | 改动 | 依据 | reviewer |
|---|---|---|---|
| 2026-05-07 | 初始 C3 active 正文质量宪法验收报告；10 pass + 2 demote_candidate；4 条标准冲突进 §6 backlog | plan: AKB2.0 Phase C3 Active 正文质量宪法验收闭环 v2 + 用户确认 4 点修订 | praise |
| 2026-05-07 | Codex review APPROVED 后修两处 P3 残余：执行摘要 5+5 → 4+6；§2 表 tools fm 14 → 14→11(demote 后) + 加 fm 数字说明脚注 | Codex result-20260507T083302Z.md Residual Risk | praise |
