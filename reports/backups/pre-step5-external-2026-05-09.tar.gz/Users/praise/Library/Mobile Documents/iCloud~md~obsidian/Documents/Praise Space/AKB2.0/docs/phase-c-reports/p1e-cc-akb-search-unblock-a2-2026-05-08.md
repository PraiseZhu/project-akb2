# P1e A2 Phase Report — cc-akb-search Unblock 配置授权计划

```yaml
phase: p1e-a2-config-authorization
date: 2026-05-08
verdict: complete
predecessor_phase: p1e-a1-readonly-discovery (verdict: not_mounted)
successor_phase: p1e-a3-mcp-mount (pending user approval)
mutations_performed: false
config_files_modified: false
skill_sha256_drift: false
automation_allowed_changed: false
```

---

## 阶段目标

在 **0 配置变更**的前提下，生成完整的 cc-akb-search MCP mount 授权包，供用户审批后作为 A3 执行唯一依据。

A2 全程只读：不改 `mcp-configs`，不改 `settings.json`，不修改五件套 / SKILL.md，不运行 wrapper。

---

## Deliverable 完整性

| 文件 | 路径 | sha256（截断）| 状态 |
|------|------|-------------|------|
| `wrapper-draft.py` | `Codex/ai-infra/akb2-toolbox-evals/p1e-cc-akb-search-a2/` | `0ef83866...` | ✓ |
| `server.py`（canonical draft）| `Codex/plugins/claude-code-ai-infra/mcp-servers/akb-search-readonly/` | `0ef83866...`（byte-identical） | ✓ |
| `mcp-entry-draft.json` | `p1e-cc-akb-search-a2/` | — | ✓ |
| `a2-config-baseline.json` | `p1e-cc-akb-search-a2/` | — | ✓ |
| `a2-verification-plan.md` | `p1e-cc-akb-search-a2/` | — | ✓ |
| `a2-preflight.md` | `p1e-cc-akb-search-a2/` | — | ✓ |
| `run-evidence.md` | `p1e-cc-akb-search-a2/` | — | ✓ |

wrapper-draft.py ↔ server.py byte-identical（`cmp -s` exit 0）✓

---

## A3 Mutations 明示（4 项）

| # | mutation | 操作对象 | 可逆方式 |
|---|---------|---------|---------|
| M1 | 确认 wrapper server.py sha256 = `0ef83866...` | `Codex/plugins/claude-code-ai-infra/mcp-servers/akb-search-readonly/server.py` | 删文件 |
| M2 | 修改 live config 追加 akb-search | `~/.claude/mcp-configs/mcp-servers.json` | 删 akb-search key |
| M3 | 修改 mirror config（与 M2 同步）| iCloud mcp-configs/mcp-servers.json | 同 M2 |
| M4 | 验证 mcp 包可用性（只读）| `~/.pyenv/versions/3.13.12/bin/python3 -c "import mcp"` | N/A |

> A3 不改 `settings.json`（mcpServers = {} 保持不动，避免双源冲突）。

---

## 只读合约分析（F1 修复后）

### catalog.db 写操作（已修复 F1）

**问题**：原 wrapper 在 `app_lifespan` 中调用 `CatalogDB.init_tables()`，执行 schema executescript + migration INSERT → 写 `catalog.db`，违反只读合约。

**修复**：移除 `init_tables()` 调用。AKB 正式库 `catalog.db` 已完全初始化，只读场景仅需 `CatalogDB()` 设置 `db_path`，无需 schema check。

**验证**：wrapper-draft.py + server.py 均已移除该调用（sha256 = `0ef83866...`）。

### cache.db 写操作（接受为预期行为）

**问题**：`search_knowledge`（`scripts/core/search.py:50`）硬编码实例化 `KnowledgeCache()`，构造时执行 `_init_db()`（写 cache.db schema），search 时执行 `cache.set()`（写 cache entries）。无法从 wrapper 层注入 NullCache（需改 Project AKB 核心文件，超出 A2 范围）。

**决策**：接受 cache.db 写入为预期性能行为。`cache.db` 存储关键词搜索结果缓存，**不存储 AKB 知识内容**，写入不违反 AKB 数据完整性合约。

**文档化**：V3 snapshot 显式排除 `cache.db*`，注释说明排除原因。

### V3 数据完整性检查（F2 扩展）

A3 验证 V3 snapshot 现在覆盖：

| 范围 | 检查目标 | 期望 |
|------|---------|------|
| `*.json` / `*.jsonl`（index + notes + embeddings）| AKB 知识内容文件 | diff 0 行 |
| `catalog.db`, `catalog.db-wal`, `catalog.db-shm` | 数据库 schema（F1 修复后不应有变化）| diff 0 行 |
| `cache.db*` | 关键词搜索缓存 | **排除**（预期写入，已文档化） |

---

## 配置 Baseline（A3 Rollback 参考）

| 文件 | sha256 | 含 akb-search |
|------|--------|--------------|
| `~/.claude/mcp-configs/mcp-servers.json` | `04cb0509...`（27 servers）| ✗ |
| iCloud `mcp-configs/mcp-servers.json` | `04cb0509...`（27 servers）| ✗ |

两文件 byte-identical。A3 执行前必须 re-verify sha256 与 baseline 一致。

---

## A2 不变量验证

| 约束 | 状态 |
|------|------|
| SKILL.md sha256 = `b669380de8a0...` | ✓ PASS |
| mcp-configs sha256 = `04cb0509...`（live + mirror 均不变）| ✓ PASS |
| settings.json mcpServers = {} | ✓ PASS |
| automation_allowed: false（cc-akb-search 五件套）| ✓ PASS |
| toolbox_status = candidate（未升级）| ✓ PASS |
| wrapper-draft.py / server.py byte-identical | ✓ PASS |

---

## Review 记录

### Review 1（docs_content）

- timestamp: 2026-05-08T07:00:00Z（R3 后 APPROVED）
- **VERDICT: APPROVED**（经 3 轮 P2 修复）
- P1: 0; P2: 3（已全关闭）
  - R1-P2: evidence pack 缺 wrapper-draft.py → 创建 byte-identical copy
  - R2-P2: sha256 不一致 → `cp server.py wrapper-draft.py` 后验证
  - R3-P2: run-evidence.md §Next Step + a2-verification-plan.md rollback 措辞矛盾 → 统一"verify not create"语义

### Review 2（ai_infra）

- timestamp: 2026-05-08T16:04:23Z（R3 后 APPROVED）
- **VERDICT: APPROVED**（经 3 轮 R1→R2→R3）
- R1: REQUIRES_CHANGES — P1: 只读路径仍会写 DB/cache（init_tables + KnowledgeCache + V3 盲点）
- R2: REQUIRES_CHANGES — P2: run-evidence.md:125 旧 sha256 26055920 残留
- R3: APPROVED — 0 P1/P2

---

## A3 前置条件（全部就绪）

- [x] A2 plan APPROVED（用户审批）
- [x] wrapper-draft.py 只读合约 static review 通过
- [x] mcp-entry-draft.json pyenv python3 路径正确（`import mcp` exit 0 实测）
- [x] a2-config-baseline.json sha256 冻结（A3 rollback baseline）
- [x] a2-verification-plan.md V3 扩展（含 catalog.db* + cache.db* 文档化）
- [x] Review 1（docs_content）APPROVED
- [x] Review 2（ai_infra）APPROVED
- [x] 0 mutation 守门：mcp-configs / settings.json / SKILL.md / 五件套全程 byte-identical

---

## 下一步（A3，需用户明确授权）

1. 确认本 A2 报告 + plan APPROVED
2. A3 开始前 re-verify config sha256（`04cb0509...`）
3. 执行 M4 → M1 → M2 → M3
4. 重启 Claude Code session
5. 执行 V1 → V2 → V3 验证
