---
title: Phase C-1 Toolbox Workspace Scan — 2026-05-04
doc_type: phase-c-report
phase: C-1
report_kind: workspace_scan
automation_layer: L0_read_only
not_active_promotion: true
scan_id: akb2-toolbox-scan-504ec71e6b7e
scanned_at: 2026-05-04T05:43:12Z
report_date: 2026-05-04
---

# Phase C-1 Toolbox Workspace Scan — 2026-05-04

> Read-only scanner output. Never executes a candidate, never writes outside `manifests/workspace-scan/` and `docs/phase-c-reports/`, never promotes anything to active.

## §1 Scan summary

- AKB root: `/Users/praise/Library/Mobile Documents/iCloud~md~obsidian/Documents/Praise Space/AKB2.0`
- JSONL manifest: `/Users/praise/Library/Mobile Documents/iCloud~md~obsidian/Documents/Praise Space/AKB2.0/manifests/workspace-scan/2026-05-04-toolbox-workspace-scan.jsonl`
- Total candidates: **728**
- Roots scanned: 4

## §2 Root status

| root | kind | status | candidates | error |
|---|---|---|---|---|
| `/Users/praise/.codex/skills` | user | scanned | 290 |  |
| `/Users/praise/.claude/scripts` | user | scanned | 95 |  |
| `/Users/praise/.claude/scripts/hooks` | user | scanned | 59 |  |
| `/Users/praise/Library/Mobile Documents/com~apple~CloudDocs/Claude Code/skills/claude-active` | user | scanned | 284 |  |

## §3 Detected kind distribution

| detected_kind | count |
|---|---|
| codex_skill | 290 |
| claude_skill | 284 |
| claude_script | 95 |
| claude_hook | 59 |

## §4 Risk + side-effects hints

| risk_hint | count |
|---|---|
| low | 669 |
| medium | 59 |

| side_effects_hint | count |
|---|---|
| read_only | 574 |
| write_local | 154 |

## §5 Suspected high-risk / sensitive headers

- `post-bash-command-log.js` — secret_in_header
- `secret-detection.js` — secret_in_header
- `archived/pre-bash-dev-server-block.js` — secret_in_header
- `kotlin-exposed-patterns/SKILL.md` — secret_in_header
- `laravel-security/SKILL.md` — secret_in_header
- `x-api/SKILL.md` — secret_in_header
- `docker-patterns/SKILL.md` — secret_in_header
- `videodb/SKILL.md` — secret_in_header
- `springboot-security/SKILL.md` — secret_in_header
- `eval-harness/SKILL.md` — secret_in_header
- `Doki周报执行/SKILL.md` — secret_in_header
- `backend-patterns/SKILL.md` — secret_in_header
- `nutrient-document-processing/SKILL.md` — secret_in_header
- `jira-integration/SKILL.md` — secret_in_header
- `Doki健康检查/SKILL.md` — secret_in_header
- `飞书机器人开发/SKILL.md` — secret_in_header
- `security-scan/SKILL.md` — secret_in_header
- `evm-token-decimals/SKILL.md` — secret_in_header
- `django-tdd/SKILL.md` — secret_in_header
- `security-review/SKILL.md` — secret_in_header

## §6 Phase B sample coverage in workspace

- `cc-akb-search` ← `cc-akb-search/SKILL.md`
- `cc-skill-stocktake` ← `cc-skill-stocktake/SKILL.md`
- `cc-executable-plan` ← `cc-executable-plan/SKILL.md`
- `cc-local-llm` ← `cc-local-llm/SKILL.md`
- `cc-review` ← `cc-review/SKILL.md`
- `review-result-writer` ← `review-result-writer.sh`
- `execution-result-gate` ← `execution-result-gate.js`
- `akb-ingest-gate` ← `akb-ingest-gate.js`

## §7 AKB 2.0 toolbox coverage gaps

- candidates without `toolbox/registry/<slug>.md`: 728
- candidates without `toolbox/interfaces/<slug>.md`: 728
- candidates without `toolbox/evals/<slug>.md`: 728

## §8 Next-batch Tool Gate suggestions (advisory only)

> Scanner does NOT decide gate outcomes. The list below highlights candidates that look like solid first picks for human review.

| slug | detected_kind | size | shadow? | path |
|---|---|---|---|---|
| `cc-akb-search` | codex_skill | 1742B | ✅ | `cc-akb-search/SKILL.md` |
| `cc-skill-stocktake` | codex_skill | 2120B | ✅ | `cc-skill-stocktake/SKILL.md` |
| `cc-executable-plan` | codex_skill | 3359B | ✅ | `cc-executable-plan/SKILL.md` |
| `cc-local-llm` | codex_skill | 2198B | ✅ | `cc-local-llm/SKILL.md` |
| `cc-review` | codex_skill | 4673B | ✅ | `cc-review/SKILL.md` |
| `cc-frontend-design` | codex_skill | 2121B | — | `cc-frontend-design/SKILL.md` |
| `cc-eagle` | codex_skill | 2116B | — | `cc-eagle/SKILL.md` |
| `cc-inventory-demand-planning` | codex_skill | 1784B | — | `cc-inventory-demand-planning/SKILL.md` |
| `cc-laravel-security` | codex_skill | 1986B | — | `cc-laravel-security/SKILL.md` |
| `cc-nutrient-document-processing` | codex_skill | 2043B | — | `cc-nutrient-document-processing/SKILL.md` |
| `cc-springboot-verification` | codex_skill | 1980B | — | `cc-springboot-verification/SKILL.md` |
| `cc-autonew` | codex_skill | 1679B | — | `cc-autonew/SKILL.md` |
| `cc-workday` | codex_skill | 1665B | — | `cc-workday/SKILL.md` |
| `cc-configure-ecc` | codex_skill | 2236B | — | `cc-configure-ecc/SKILL.md` |
| `cc-start-work-flow` | codex_skill | 1658B | — | `cc-start-work-flow/SKILL.md` |

## §9 Invariants self-check

- [x] every record carries `not_active: true`
- [x] every record carries `automation_allowed: false`
- [x] every record carries `gate_decision: null`
- [x] no candidate file was executed or imported
- [x] no symlink was followed (recorded only)
- [x] outputs land only in `manifests/workspace-scan/` and `docs/phase-c-reports/`

