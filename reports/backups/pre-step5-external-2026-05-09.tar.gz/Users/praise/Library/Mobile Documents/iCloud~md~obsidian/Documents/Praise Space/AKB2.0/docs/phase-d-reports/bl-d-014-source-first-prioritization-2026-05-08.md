---
report_type: phase_d_source_first_prioritization
report_id: bl-d-014-source-first-prioritization-2026-05-08
date: 2026-05-08
status: completed
backlog_item: BL-D-014
plan_source: ~/.claude/plans/rustling-bouncing-marshmallow.md (v2)
upstream_report: docs/phase-d-reports/bl-d-014-concept-evidence-census-2026-05-08.md
---

# BL-D-014 Source-First Prioritization 报告（2026-05-08）

## 1. 摘要

本报告固定本轮 BL-D-014 source-first 推进的 3 个 lane，并记录每个 lane 的 source 入库决策、自检结果、术语校准结论。**本轮不建任何 wiki/concepts 页**。

| Lane | 概念 | 决策 | 入库 source |
|---|---|---|---|
| A | `agent-collaboration` (CC-008) | 入库 | `wiki/sources/anthropic-multi-agent-research-system.md` |
| B | `plan-execute-loop` (CC-005) | 入库 | `wiki/sources/langchain-plan-and-execute-agents.md` |
| C | `knowledge-retrieval-first` (CC-002) | **不入库**（术语校准） | — |

**暂不做**：`dual-review` (CC-007) / `freshness-tracking` (CC-003) / `skill-lifecycle` (CC-004)

## 2. Review 后约束（明确写入本报告）

| 约束 | 处置 |
|---|---|
| Lint 复跑产物（manifests/lint/*.jsonl + docs/phase-d-reports/lint-cli-v0.3-*.md） | **允许验证输出**，不算主体内容改动；closure summary 单列 |
| MCP `mcp__akb-search not_mounted` | 不在本轮处理（A2 授权另开计划） |
| `.akb-runtime/lint/akb2-lint.py` | 不改（v0.3 已 APPROVED） |
| `wiki/concepts/`、`toolbox/`、standards docs | 不改 |
| 上游 `docs/phase-d-reports/akb2-census-week-2026-05-08.md` §3.2 错误推断 | 保留历史，由用户决策是否回写 |

## 3. 方法论摘要（继承 plan v2）

### 3.1 Source 获取

- **唯一通道**：WebFetch（一次性，不接 fetch pipeline）
- 每篇配套 `raw/<slug>--raw--2026-05-08.md` 归档文件
- raw 文件不含 wikilink（遵守 R19 RAW-NO-WIKILINK）

### 3.2 Source 页正文模板（11 节强制）

```
## TLDR / ## 入选理由 / ## 证据地图 / ## 关键发现 / ## 核心论点 /
## 论证与解释 / ## 应用场景 / ## 适用边界 / ## 图谱关系 /
## Future Questions / ## 维护记录
```

### 3.3 摘录硬约束（v2 plan）

| 项 | 限制 |
|---|---|
| 直接引用次数（全文） | ≤1 处 |
| 单次直接引用长度 | ≤30 字 |
| 引用形式 | 加引号 `"..."` 或反引号 `` `...` `` 且明确标注"直接引用" |
| 其余正文 | 全部 paraphrase / AKB interpretation |

### 3.4 Active 前 direct_source 三条件自检

1. source 页 `status: active`
2. 正文含 ≥1 段定义性表述
3. 概念名或近义表述出现在 ## TLDR / ## 关键发现 / ## 核心论点 之一

不满足 → 保留 candidate，记入下一轮 source 改写计划。

---

## 4. Lane A：anthropic-multi-agent-research-system

### 4.1 入库 source

- **文件**：`wiki/sources/anthropic-multi-agent-research-system.md`
- **raw 归档**：`raw/anthropic-multi-agent-research-system--raw--2026-05-08.md`
- **source URL**：https://www.anthropic.com/engineering/built-multi-agent-research-system
- **source published_at**：2025-06-13
- **target_concept**：CC-008 `agent-collaboration`

### 4.2 直接引用合规

- 直接引用次数：**1**（在 ## 关键发现 §1）
- 直接引用内容：`` `orchestrator-worker pattern` ``
- 长度：27 字（≤30）✅

### 4.3 Active 前 direct_source 三条件自检

| 条件 | 结果 | 证据 |
|---|---|---|
| 1. status: active | ✅ | frontmatter `status: active` |
| 2. 含定义性段落 | ✅ | ## 核心论点 §2 给 4 角色分工定义 + ## 论证与解释 给量化 benchmark |
| 3. TLDR/关键发现/核心论点 含概念命中 | ✅ | TLDR=1 hit、关键发现=3 hits、核心论点=7 hits（实测命中：agent collaboration / multi-agent / orchestrator-worker / sub-agent） |

**结论**：三条件全过 → `status: active`

### 4.4 Scope 限定提醒

source 主体是 **research 域**多 agent 系统。下一轮 concept 页需在 scope 字段明确限定为 research/orchestrator-worker 子型，或继续补宽域 source 覆盖通用 agent collaboration（如 supervisor / blackboard / agent mesh 模式）。

---

## 5. Lane B：langchain-plan-and-execute-agents

### 5.1 入库 source

- **文件**：`wiki/sources/langchain-plan-and-execute-agents.md`
- **raw 归档**：`raw/langchain-plan-and-execute-agents--raw--2026-05-08.md`
- **source URL**：https://blog.langchain.dev/planning-agents/（已 301 → https://www.langchain.com/blog/planning-agents）
- **source published_at**：2024-02-13
- **target_concept**：CC-005 `plan-execute-loop`

### 5.2 直接引用合规

- 直接引用次数：**1**（在 ## 关键发现 §1）
- 直接引用内容：`` `"plan-and-execute"` ``
- 长度：16 字（≤30）✅

### 5.3 Active 前 direct_source 三条件自检

| 条件 | 结果 | 证据 |
|---|---|---|
| 1. status: active | ✅ | frontmatter `status: active` |
| 2. 含定义性段落 | ✅ | ## 核心论点 §2 给 planner/executor 工程结构定义 + §3-§4 给 ReWOO/LLMCompiler 变体 |
| 3. TLDR/关键发现/核心论点 含概念命中 | ✅ | TLDR=1 hit、关键发现=1 hit、核心论点=6 hits（实测命中：plan-and-execute / planner / executor） |

**结论**：三条件全过 → `status: active`

### 5.4 术语对齐提醒

source 用 `plan-and-execute`（连字符），AKB 内部 slug `plan-execute-loop`。下一轮 concept 页应：
- 主 slug 跟 source 术语对齐（建议 rename 到 `concept-plan-and-execute`）
- 旧 slug `plan-execute-loop` 保留为 alias
- ReAct paper（arxiv 2210.03629）作为 related_sources 保留供后续补强（本轮不补）

### 5.5 上游 census 校正闭环

上轮 BL-D-014 evidence census 中 CC-005 推测"harness-engineering-deep-eval §3.1 plan loop 间接支撑"经实际 grep 反验证不成立（已在该 census §6 校正）。本 lane 入库 source 后，CC-005 不再依赖该错误推断，闭环了上游 census 的悬空。

---

## 6. Lane C：knowledge-retrieval-first 术语校准（不入库）

### 6.1 校准参考 source

- **校准用 URL**：https://www.anthropic.com/research/contextual-retrieval（Anthropic Contextual Retrieval，2024-09-19）
- **WebFetch 结论**：文章定义 Contextual Retrieval 为"prepending chunk-specific explanatory context to each chunk before embedding"——即一种 RAG 优化技术，**不是**"先查再做"工程原则

### 6.2 术语错配诊断

`knowledge-retrieval-first` 当前 slug 暗示"知识检索优先 / search-before-doing"工程原则。校准 source 实际定义的是 retrieval optimization 技术（chunk-level pre-processing），二者**不同主题**：

| 维度 | knowledge-retrieval-first（AKB 内部口径） | Contextual Retrieval（Anthropic source） |
|---|---|---|
| 关注层 | agent 决策原则（先查 vs 直接动手） | RAG 数据预处理（chunk embedding 优化） |
| 主张 | engineering 流程优先级 | 检索准确率优化 |
| 适用 | agent 工程治理 | knowledge base 检索质量 |

### 6.3 校准结论

**不入库 Anthropic Contextual Retrieval 作为 knowledge-retrieval-first 的 source**——会造成 evidence 错配，违反 direct_source 三条件中的"≥1 段定义性表述"。

### 6.4 候选处置（供下一轮决策）

| 选项 | 含义 |
|---|---|
| A. Rename | 把 AKB slug 改为 source 术语对应名（如 `concept-just-in-time-retrieval` / `concept-contextual-retrieval`），但语义已偏离原意（"先查再做"被丢失） |
| B. Defer | 标 `defer`，等找到真正定义"先查再做工程原则"的 source 再入库（候选：Karpathy "search before code" 类、Anthropic Skills doc） |
| C. 保持 needs_source | 概念有效但 source 缺失，下一轮另开 source 寻找计划 |

**本报告建议**：选 **C（保持 needs_source）**——概念在 cc-akb-search 中确实承担有效语义（"先查 AKB 再做工程"），不应因术语错配就放弃；继续找匹配 source。

### 6.5 Rename 链路收尾（plan v2 强制声明）

即使下一轮决议为 rename，本轮**不修改** `wiki/tools/cc-akb-search.md:76` 的旧 wikilink `[[../concepts/knowledge-retrieval-first|...]]`。

**rename + tool 页 wikilink 同步更新留给下一轮独立计划**，本轮不动 cc-akb-search.md。

---

## 7. 不变量

- 本报告**不创建** `wiki/concepts/*.md`
- 本报告**不修改** lint CLI、tool 页、standards docs
- 本轮新增主体内容：4 文件
  - `wiki/sources/anthropic-multi-agent-research-system.md`
  - `wiki/sources/langchain-plan-and-execute-agents.md`
  - `raw/anthropic-multi-agent-research-system--raw--2026-05-08.md`
  - `raw/langchain-plan-and-execute-agents--raw--2026-05-08.md`
- 配套登记（不算主体）：`wiki/sources/00-Index.md` + `manifests/ingest/*.jsonl` 增条目
- 验证产物（允许）：v0.3 lint 复跑产生的 manifest + report

## 8. 维护记录

| 日期 | 改动 | 作者 |
|---|---|---|
| 2026-05-08 | 初始创建 — plan: AKB2.0 BL-D-014 Source-First 1-3 v2；3 lane 决策：A/B 入库 active source、C 保持 needs_source；A/B 三条件自检全过；C 校准结论为术语错配不入库 | praise + Claude Code |
