---
report_type: phase_d_lint_cli_run
report_id: lint-cli-v0.2-2026-05-07
date: 2026-05-07
operation_id: akb2-lint-20260507T195852
tool: akb2-lint.py v0.2
baseline: v0.1 (15 active P1=0)
scanned_count: 15
p0_count: 0
p1_count: 24
p2_count: 21
---

# AKB2.0 LINT CLI v0.2 Run Report

## 摘要

- 工具：`akb2-lint.py` v0.2（Python stdlib，无依赖）
- 位置：`.akb-runtime/lint/akb2-lint.py`
- 规则：18 条（all standards-backed）
- 扫描页数：15
- baseline: v0.1 (15 active P1=0)
- P0 findings：**0**
- P1 findings：**24**
- P2 findings：**21**

## 规则清单

| Rule ID | Severity | 上游标准 |
|---|---|---|
| METADATA-LONG-FIELD | P1 | INTAKE-GATE §5.1 |
| BODY-MAINTENANCE-LOG-OVERFLOW | P2 | INTAKE-GATE §5.2.1 |
| BODY-MAINTENANCE-LOG-VERBOSE | P2 | INTAKE-GATE §5.2.2 |
| TOOL-UNDERSTANDING-MISSING-STRUCTURE | P1 | PAGE-TEMPLATES §4.7 + INTAKE-GATE §4.3 |
| WIKI-TOOLS-CALL-CONTRACT-LEAK | P2 | INTAKE-GATE §4.3.3 + FOLDER-STRUCTURE §3.4 |
| BODY-QUALITY-MISSING-STRUCTURE | P1 | PAGE-TEMPLATES §3.7.3 + LINT-RULES §11.2 |
| SOURCE-GROUNDED-MISSING-FIELD | P1 | INTAKE-GATE §4 第 8 条 + LINT-RULES §11.2 |
| SOURCE-GROUNDED-INFERENCE-ONLY | P0 | INTAKE-GATE §4 第 8 条 不允许 inference_only active |
| SOURCE-KEY-FINDINGS-MISSING-FRONTMATTER | P1 | PAGE-TEMPLATES §4.2 H7 |
| SOURCE-KEY-FINDINGS-MISSING-PROSE | P2 | PAGE-TEMPLATES §4.2 H7 |
| GRAPH-ROLE-MISSING | P1 | GRAPH-LINKING §6.1 + PAGE-TEMPLATES §4.0 |
| GRAPH-ROLE-INVALID | P1 | GRAPH-LINKING §6.1(7 enum) |
| GRAPH-STATUS-INVALID | P2 | GRAPH-LINKING §6.2(3 enum) |
| ACTIVE-MISSING-RELATED | P1 | PAGE-TEMPLATES §3 active 必填 + GRAPH-LINKING §9.5 |
| NAMING-FILENAME-SLUG-MISMATCH | P1 | NAMING-CONVENTION §17 #5 |
| TEMPLATE-DIRECTORY-MISMATCH | P1 | PAGE-TEMPLATES §4.x 12 模板 |
| RELATED-FIELD-INVALID | P2 | GRAPH-LINKING §9.3(12 whitelist) |
| WIKI-TOOLS-TOOLBOX-PAIRING | P1 | PAGE-TEMPLATES §4.7 必须链接 |

## 扫描清单

- ⚠️ 3 `wiki/concepts/context-engineering.md`
- ⚠️ 4 `wiki/concepts/harness-engineering.md`
- ⚠️ 3 `wiki/concepts/large-language-model.md`
- ⚠️ 2 `wiki/concepts/mcp-tool-use.md`
- ⚠️ 2 `wiki/designs/implementation-aware-design.md`
- ⚠️ 2 `wiki/sources/anthropic-effective-context-engineering.md`
- ⚠️ 6 `wiki/sources/harness-engineering-deep-eval.md`
- ⚠️ 3 `wiki/sources/jenny-wen-ai-design-philosophy.md`
- ⚠️ 3 `wiki/sources/karpathy-intro-to-llms.md`
- ⚠️ 2 `wiki/sources/mcp-spec.md`
- ⚠️ 3 `wiki/tools/cc-akb-search.md`
- ⚠️ 3 `wiki/tools/cc-executable-plan.md`
- ⚠️ 3 `wiki/tools/cc-local-llm.md`
- ⚠️ 3 `wiki/tools/cc-review.md`
- ⚠️ 3 `wiki/tools/cc-skill-stocktake.md`

## P0 violations

**none**

## P1 violations


- **NAMING-FILENAME-SLUG-MISMATCH** at `/Users/praise/Library/Mobile Documents/iCloud~md~obsidian/Documents/Praise Space/AKB2.0/wiki/concepts/context-engineering.md`
  - 文件名 `context-engineering.md` ≠ frontmatter slug `concept-context-engineering`
  - proposed_action: 走重命名迁移协议(NAMING §10);旧 slug 进 aliases
- **NAMING-FILENAME-SLUG-MISMATCH** at `/Users/praise/Library/Mobile Documents/iCloud~md~obsidian/Documents/Praise Space/AKB2.0/wiki/concepts/harness-engineering.md`
  - 文件名 `harness-engineering.md` ≠ frontmatter slug `concept-harness-engineering`
  - proposed_action: 走重命名迁移协议(NAMING §10);旧 slug 进 aliases
- **NAMING-FILENAME-SLUG-MISMATCH** at `/Users/praise/Library/Mobile Documents/iCloud~md~obsidian/Documents/Praise Space/AKB2.0/wiki/concepts/large-language-model.md`
  - 文件名 `large-language-model.md` ≠ frontmatter slug `concept-large-language-model`
  - proposed_action: 走重命名迁移协议(NAMING §10);旧 slug 进 aliases
- **NAMING-FILENAME-SLUG-MISMATCH** at `/Users/praise/Library/Mobile Documents/iCloud~md~obsidian/Documents/Praise Space/AKB2.0/wiki/concepts/mcp-tool-use.md`
  - 文件名 `mcp-tool-use.md` ≠ frontmatter slug `concept-mcp-tool-use`
  - proposed_action: 走重命名迁移协议(NAMING §10);旧 slug 进 aliases
- **SOURCE-KEY-FINDINGS-MISSING-FRONTMATTER** at `/Users/praise/Library/Mobile Documents/iCloud~md~obsidian/Documents/Praise Space/AKB2.0/wiki/sources/anthropic-effective-context-engineering.md`
  - source 模板 active 缺 frontmatter `key_findings` array
  - proposed_action: 补 frontmatter `key_findings: [...]` ≥ 3 条精简陈述
- **SOURCE-KEY-FINDINGS-MISSING-FRONTMATTER** at `/Users/praise/Library/Mobile Documents/iCloud~md~obsidian/Documents/Praise Space/AKB2.0/wiki/sources/harness-engineering-deep-eval.md`
  - source 模板 active 缺 frontmatter `key_findings` array
  - proposed_action: 补 frontmatter `key_findings: [...]` ≥ 3 条精简陈述
- **SOURCE-KEY-FINDINGS-MISSING-FRONTMATTER** at `/Users/praise/Library/Mobile Documents/iCloud~md~obsidian/Documents/Praise Space/AKB2.0/wiki/sources/jenny-wen-ai-design-philosophy.md`
  - source 模板 active 缺 frontmatter `key_findings` array
  - proposed_action: 补 frontmatter `key_findings: [...]` ≥ 3 条精简陈述
- **SOURCE-KEY-FINDINGS-MISSING-FRONTMATTER** at `/Users/praise/Library/Mobile Documents/iCloud~md~obsidian/Documents/Praise Space/AKB2.0/wiki/sources/karpathy-intro-to-llms.md`
  - source 模板 active 缺 frontmatter `key_findings` array
  - proposed_action: 补 frontmatter `key_findings: [...]` ≥ 3 条精简陈述
- **SOURCE-KEY-FINDINGS-MISSING-FRONTMATTER** at `/Users/praise/Library/Mobile Documents/iCloud~md~obsidian/Documents/Praise Space/AKB2.0/wiki/sources/mcp-spec.md`
  - source 模板 active 缺 frontmatter `key_findings` array
  - proposed_action: 补 frontmatter `key_findings: [...]` ≥ 3 条精简陈述
- **SOURCE-GROUNDED-MISSING-FIELD** at `/Users/praise/Library/Mobile Documents/iCloud~md~obsidian/Documents/Praise Space/AKB2.0/wiki/tools/cc-akb-search.md`
  - active 缺 frontmatter `evidence_provenance` 字段
  - proposed_action: 补 4 enum 之一: source_grounded / bridging_source_grounded / partial_source_grounded / inference_only
- **GRAPH-ROLE-MISSING** at `/Users/praise/Library/Mobile Documents/iCloud~md~obsidian/Documents/Praise Space/AKB2.0/wiki/tools/cc-akb-search.md`
  - active 缺 frontmatter `graph_role` 字段
  - proposed_action: 补 graph_role 7 enum 之一: bridge, cluster_center, design-memory, evidence, hub, leaf, procedure
- **ACTIVE-MISSING-RELATED** at `/Users/praise/Library/Mobile Documents/iCloud~md~obsidian/Documents/Praise Space/AKB2.0/wiki/tools/cc-akb-search.md`
  - active 0 个非空 related_* 字段(必备至少 1 个)
  - proposed_action: 补任一 related_* 字段(12 whitelist 之一,非空)
- **SOURCE-GROUNDED-MISSING-FIELD** at `/Users/praise/Library/Mobile Documents/iCloud~md~obsidian/Documents/Praise Space/AKB2.0/wiki/tools/cc-executable-plan.md`
  - active 缺 frontmatter `evidence_provenance` 字段
  - proposed_action: 补 4 enum 之一: source_grounded / bridging_source_grounded / partial_source_grounded / inference_only
- **GRAPH-ROLE-MISSING** at `/Users/praise/Library/Mobile Documents/iCloud~md~obsidian/Documents/Praise Space/AKB2.0/wiki/tools/cc-executable-plan.md`
  - active 缺 frontmatter `graph_role` 字段
  - proposed_action: 补 graph_role 7 enum 之一: bridge, cluster_center, design-memory, evidence, hub, leaf, procedure
- **ACTIVE-MISSING-RELATED** at `/Users/praise/Library/Mobile Documents/iCloud~md~obsidian/Documents/Praise Space/AKB2.0/wiki/tools/cc-executable-plan.md`
  - active 0 个非空 related_* 字段(必备至少 1 个)
  - proposed_action: 补任一 related_* 字段(12 whitelist 之一,非空)
- **SOURCE-GROUNDED-MISSING-FIELD** at `/Users/praise/Library/Mobile Documents/iCloud~md~obsidian/Documents/Praise Space/AKB2.0/wiki/tools/cc-local-llm.md`
  - active 缺 frontmatter `evidence_provenance` 字段
  - proposed_action: 补 4 enum 之一: source_grounded / bridging_source_grounded / partial_source_grounded / inference_only
- **GRAPH-ROLE-MISSING** at `/Users/praise/Library/Mobile Documents/iCloud~md~obsidian/Documents/Praise Space/AKB2.0/wiki/tools/cc-local-llm.md`
  - active 缺 frontmatter `graph_role` 字段
  - proposed_action: 补 graph_role 7 enum 之一: bridge, cluster_center, design-memory, evidence, hub, leaf, procedure
- **ACTIVE-MISSING-RELATED** at `/Users/praise/Library/Mobile Documents/iCloud~md~obsidian/Documents/Praise Space/AKB2.0/wiki/tools/cc-local-llm.md`
  - active 0 个非空 related_* 字段(必备至少 1 个)
  - proposed_action: 补任一 related_* 字段(12 whitelist 之一,非空)
- **SOURCE-GROUNDED-MISSING-FIELD** at `/Users/praise/Library/Mobile Documents/iCloud~md~obsidian/Documents/Praise Space/AKB2.0/wiki/tools/cc-review.md`
  - active 缺 frontmatter `evidence_provenance` 字段
  - proposed_action: 补 4 enum 之一: source_grounded / bridging_source_grounded / partial_source_grounded / inference_only
- **GRAPH-ROLE-MISSING** at `/Users/praise/Library/Mobile Documents/iCloud~md~obsidian/Documents/Praise Space/AKB2.0/wiki/tools/cc-review.md`
  - active 缺 frontmatter `graph_role` 字段
  - proposed_action: 补 graph_role 7 enum 之一: bridge, cluster_center, design-memory, evidence, hub, leaf, procedure
- **ACTIVE-MISSING-RELATED** at `/Users/praise/Library/Mobile Documents/iCloud~md~obsidian/Documents/Praise Space/AKB2.0/wiki/tools/cc-review.md`
  - active 0 个非空 related_* 字段(必备至少 1 个)
  - proposed_action: 补任一 related_* 字段(12 whitelist 之一,非空)
- **SOURCE-GROUNDED-MISSING-FIELD** at `/Users/praise/Library/Mobile Documents/iCloud~md~obsidian/Documents/Praise Space/AKB2.0/wiki/tools/cc-skill-stocktake.md`
  - active 缺 frontmatter `evidence_provenance` 字段
  - proposed_action: 补 4 enum 之一: source_grounded / bridging_source_grounded / partial_source_grounded / inference_only
- **GRAPH-ROLE-MISSING** at `/Users/praise/Library/Mobile Documents/iCloud~md~obsidian/Documents/Praise Space/AKB2.0/wiki/tools/cc-skill-stocktake.md`
  - active 缺 frontmatter `graph_role` 字段
  - proposed_action: 补 graph_role 7 enum 之一: bridge, cluster_center, design-memory, evidence, hub, leaf, procedure
- **ACTIVE-MISSING-RELATED** at `/Users/praise/Library/Mobile Documents/iCloud~md~obsidian/Documents/Praise Space/AKB2.0/wiki/tools/cc-skill-stocktake.md`
  - active 0 个非空 related_* 字段(必备至少 1 个)
  - proposed_action: 补任一 related_* 字段(12 whitelist 之一,非空)

## P2 violations


### BODY-MAINTENANCE-LOG-VERBOSE (21 hits)
- `/Users/praise/Library/Mobile Documents/iCloud~md~obsidian/Documents/Praise Space/AKB2.0/wiki/concepts/context-engineering.md`: 维护记录 row 253 chars: | 2026-05-06 | v3 Active Page Constitution 重写（approved_plan:…
- `/Users/praise/Library/Mobile Documents/iCloud~md~obsidian/Documents/Praise Space/AKB2.0/wiki/concepts/context-engineering.md`: 维护记录 row 663 chars: | 2026-05-07 | **v4 Phase C2 Query Gap Closure 升级到 hub**（app…
- `/Users/praise/Library/Mobile Documents/iCloud~md~obsidian/Documents/Praise Space/AKB2.0/wiki/concepts/harness-engineering.md`: 维护记录 row 249 chars: | 2026-05-04 | **quality_repair v2 — source-grounded 重写** — …
- `/Users/praise/Library/Mobile Documents/iCloud~md~obsidian/Documents/Praise Space/AKB2.0/wiki/concepts/harness-engineering.md`: 维护记录 row 749 chars: | 2026-05-06 | **v3 Active Page Constitution 重写**(approved_p…
- `/Users/praise/Library/Mobile Documents/iCloud~md~obsidian/Documents/Praise Space/AKB2.0/wiki/concepts/harness-engineering.md`: 维护记录 row 384 chars: | 2026-05-07 | **Phase C2 增量补丁**(approved_plan: AKB2.0 Phase…
- `/Users/praise/Library/Mobile Documents/iCloud~md~obsidian/Documents/Praise Space/AKB2.0/wiki/concepts/large-language-model.md`: 维护记录 row 399 chars: | 2026-05-04 | **quality_repair v2 — 收紧到 hub 入口** — **删除** v…
- `/Users/praise/Library/Mobile Documents/iCloud~md~obsidian/Documents/Praise Space/AKB2.0/wiki/concepts/large-language-model.md`: 维护记录 row 723 chars: | 2026-05-06 | **v3 Active Page Constitution 重写**(approved_p…
- `/Users/praise/Library/Mobile Documents/iCloud~md~obsidian/Documents/Praise Space/AKB2.0/wiki/concepts/mcp-tool-use.md`: 维护记录 row 336 chars: | 2026-05-07 | 初始创建 — Phase C2 Query Gap Closure（approved_pl…
- `/Users/praise/Library/Mobile Documents/iCloud~md~obsidian/Documents/Praise Space/AKB2.0/wiki/designs/implementation-aware-design.md`: 维护记录 row 339 chars: | 2026-05-04 | **quality_repair v2 — source-grounded 重写** — …
- `/Users/praise/Library/Mobile Documents/iCloud~md~obsidian/Documents/Praise Space/AKB2.0/wiki/designs/implementation-aware-design.md`: 维护记录 row 798 chars: | 2026-05-06 | **v3 Active Page Constitution 重写**(approved_p…
- `/Users/praise/Library/Mobile Documents/iCloud~md~obsidian/Documents/Praise Space/AKB2.0/wiki/sources/anthropic-effective-context-engineering.md`: 维护记录 row 455 chars: | 2026-05-07 | 初始创建 — Phase C2 Query Gap Closure（approved_pl…
- `/Users/praise/Library/Mobile Documents/iCloud~md~obsidian/Documents/Praise Space/AKB2.0/wiki/sources/harness-engineering-deep-eval.md`: 维护记录 row 657 chars: | 2026-05-04 | L4 Pilot 第一批 active 提升(从 candidate)          …
- `/Users/praise/Library/Mobile Documents/iCloud~md~obsidian/Documents/Praise Space/AKB2.0/wiki/sources/harness-engineering-deep-eval.md`: 维护记录 row 657 chars: | 2026-05-04 | quality_repair v1 — 正文扩写到 9 节;frontmatter 收口;…
- `/Users/praise/Library/Mobile Documents/iCloud~md~obsidian/Documents/Praise Space/AKB2.0/wiki/sources/harness-engineering-deep-eval.md`: 维护记录 row 657 chars: | 2026-05-04 | **quality_repair v2 — source-grounded 重写** — …
- `/Users/praise/Library/Mobile Documents/iCloud~md~obsidian/Documents/Praise Space/AKB2.0/wiki/sources/harness-engineering-deep-eval.md`: 维护记录 row 657 chars: | 2026-05-06 | **v3 Active Page Constitution 重写**(approved_p…
- `/Users/praise/Library/Mobile Documents/iCloud~md~obsidian/Documents/Praise Space/AKB2.0/wiki/sources/harness-engineering-deep-eval.md`: 维护记录 row 657 chars: | 2026-05-06 | **v3.1 Codex S1.1 review followup fix** — 修复 …
- `/Users/praise/Library/Mobile Documents/iCloud~md~obsidian/Documents/Praise Space/AKB2.0/wiki/sources/jenny-wen-ai-design-philosophy.md`: 维护记录 row 389 chars: | 2026-05-04 | **quality_repair v2 — source-grounded 重写** — …
- `/Users/praise/Library/Mobile Documents/iCloud~md~obsidian/Documents/Praise Space/AKB2.0/wiki/sources/jenny-wen-ai-design-philosophy.md`: 维护记录 row 901 chars: | 2026-05-06 | **v3 Active Page Constitution 重写**(approved_p…
- `/Users/praise/Library/Mobile Documents/iCloud~md~obsidian/Documents/Praise Space/AKB2.0/wiki/sources/karpathy-intro-to-llms.md`: 维护记录 row 391 chars: | 2026-05-04 | **quality_repair v2 — walkthrough-grounded 严格…
- `/Users/praise/Library/Mobile Documents/iCloud~md~obsidian/Documents/Praise Space/AKB2.0/wiki/sources/karpathy-intro-to-llms.md`: 维护记录 row 908 chars: | 2026-05-06 | **v3 Active Page Constitution 重写**(approved_p…
- `/Users/praise/Library/Mobile Documents/iCloud~md~obsidian/Documents/Praise Space/AKB2.0/wiki/sources/mcp-spec.md`: 维护记录 row 429 chars: | 2026-05-07 | 初始创建 — Phase C2 Query Gap Closure（approved_pl…

## 不变量

- CLI 不修改任何 wiki/** active 内容（read-only scan）
- CLI 不修改 standards doc / toolbox / FOLDER-STRUCTURE
- manifest 写入 `manifests/lint/`（per LINT-RULES §1.1 v0.2 wording）