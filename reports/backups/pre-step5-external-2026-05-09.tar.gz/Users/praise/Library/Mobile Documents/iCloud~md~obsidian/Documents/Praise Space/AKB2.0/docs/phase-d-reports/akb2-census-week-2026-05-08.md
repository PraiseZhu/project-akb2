---
report_type: census_week
report_id: akb2-census-week-2026-05-08
date: 2026-05-08
plan: AKB2.0 最短路径收口 v2.1 — Stage 2
stage: Stage 2
contains:
  - standards_census
  - concept_census
standards_files_scanned: 14
normative_clauses_found: 39
candidate_rules_v03: 5
concept_candidates: 8
status: ready
---

# AKB2.0 Census Week 报告

日期：2026-05-08  
执行人：Claude Code  
依据：AKB2.0 最短路径收口 v2.1（plan review APPROVED 2026-05-07T170513Z）Stage 2

---

## §1. 执行摘要

Stage 2 产出两份 census：

| census | 扫描范围 | 发现数 | 结论 |
|---|---|---|---|
| Standards Census | 14 个 `docs/AKB-2.0-*.md` | 39 条规范性条款 → 5 条候选 v0.3 规则 | v0.3 启动条件满足（≥3 条） |
| Concept Census | BL-D-014 → wiki/tools + phase-c-reports | 8 个待建概念 | 全部有 source 来源标注，但均无 source evidence 页入库 — 构成阻塞 |

两份 census 均为 **仅列表**，不实现规则、不建概念页。

---

## §2. Standards Census（规则候选清单）

### 2.1 扫描方法

- 全量扫描 14 个 `docs/AKB-2.0-*.md`（文件总量核对：14 = 14 ✓）
- 提取含 `必须 / 应该 / 不得 / 不可 / 禁止 / must / shall / MUST / SHALL / required / SHOULD` 的非注释、非标题、非代码行
- 共找到 39 条规范性条款
- 对照 v0.2 已覆盖 18 条规则去重
- 剩余条款按可机器检查程度筛选 → 5 条候选

### 2.2 扫描结果（按文件）

| 文件 | 规范性条款数 | 备注 |
|---|---|---|
| AKB-2.0-AI-QUERY-CONTRACT.md | 4 | AI 回答格式相关，偏 manual check |
| AKB-2.0-ARCHITECTURE.md | 0 | 纯描述文档 |
| AKB-2.0-AUTOMATION-BOUNDARY.md | 2 | 运行时约束，偏 manual check |
| AKB-2.0-CONTENT-LIFECYCLE.md | 13 | 含多条可机器检查条款 |
| AKB-2.0-FETCH-INGEST-CONTRACT.md | 0 | 纯流程描述 |
| AKB-2.0-FOLDER-STRUCTURE.md | 0 | 目录结构，已有结构 lint |
| AKB-2.0-GRAPH-LINKING.md | 4 | 含 raw/ 禁止 wikilink 等可检查条款 |
| AKB-2.0-INTAKE-GATE.md | 3 | 含 wiki/tools ↔ toolbox 对应检查 |
| AKB-2.0-LINT-RULES.md | 2 | meta-lint 文档，自指性条款 |
| AKB-2.0-MIGRATION-POLICY.md | 0 | 纯操作流程 |
| AKB-2.0-NAMING-CONVENTION.md | 4 | 含 slug 日期规则等可检查条款 |
| AKB-2.0-PAGE-TEMPLATES.md | 3 | 部分已被 v0.2 覆盖 |
| AKB-2.0-QUERY-WRITEBACK.md | 4 | writeback 专用，偏 manual check |
| AKB-2.0-SOURCE-TYPE-POLICY.md | 0 | 分类描述，无强制约束语 |
| **合计** | **39** | — |

### 2.3 候选规则列表（v0.3 用）

以下 5 条候选规则满足：有 standards citation、可机器检查、未被 v0.2 覆盖。

#### CR-001 RAW-NO-WIKILINK

| 字段 | 内容 |
|---|---|
| rule_id_proposed | RAW-NO-WIKILINK |
| severity | P2 |
| target_object | `raw/` 目录下所有 `.md` 文件 |
| check_method | regex：在 raw/*.md 中检测 `\[\[` 出现 |
| standards_citation | AKB-2.0-GRAPH-LINKING.md:L37（"raw/ 内文件禁止加 wikilink"）、L402 |
| estimated_finding_count | 未知（当前 raw/ 文件数量未统计）|
| v02_covered | 否 |
| notes | raw 是证据层不是知识层；wikilink 只能在 staging/wiki/toolbox 形成 |

#### CR-002 ACTIVE-SLUG-NO-DATE

| 字段 | 内容 |
|---|---|
| rule_id_proposed | ACTIVE-SLUG-NO-DATE |
| severity | P2 |
| target_object | `wiki/` 目录下 `status: active` 的 `.md` 文件 |
| check_method | regex：文件名含 `\d{4}-\d{2}-\d{2}` 模式 |
| standards_citation | AKB-2.0-NAMING-CONVENTION.md:L39（"active 页 slug 不带日期；raw/staging/archive/manifests 必须带时间后缀"）|
| estimated_finding_count | 预计 0（当前 15 active 文件名均不含日期）|
| v02_covered | 否（v0.2 检查 status 值，不检查 slug 格式）|
| notes | 可做 baseline 健康检查，当前无违规但规则缺失 |

#### CR-003 DEPRECATED-SUPERSEDED-BY

| 字段 | 内容 |
|---|---|
| rule_id_proposed | DEPRECATED-SUPERSEDED-BY |
| severity | P1 |
| target_object | `status: deprecated` 的所有 active 页 |
| check_method | frontmatter key 检测：`status: deprecated` 页是否有 `superseded_by` 字段 |
| standards_citation | AKB-2.0-CONTENT-LIFECYCLE.md:L134（"`active → deprecated` 必须写 `superseded_by`"）|
| estimated_finding_count | 未知（当前无 deprecated 页，但规则缺失）|
| v02_covered | 否（v0.2 不检查 deprecated → superseded_by 关联）|
| notes | 状态跃迁后验约束；无 deprecated 页时 0 finding，但规则应存在 |

#### CR-004 TOOL-ACTIVE-TOOLBOX-PAIR

| 字段 | 内容 |
|---|---|
| rule_id_proposed | TOOL-ACTIVE-TOOLBOX-PAIR |
| severity | P1 |
| target_object | `wiki/tools/*.md`（status: active）|
| check_method | 文件存在性：对每个 active wiki/tools/<slug>.md，检查 `toolbox/tools/<slug>.md` 工具卡文件是否存在 |
| standards_citation | AKB-2.0-INTAKE-GATE.md:L143（"active wiki/tools 页面必须 wikilink 到对应 toolbox/tools/<slug>"）|
| estimated_finding_count | 预计 0（当前 5 active tools 均已配对，toolbox/tools/ 下 5 个 .md 文件 1:1 对应）|
| v02_covered | 部分（toolbox 结构 lint 覆盖工具卡文件存在性，但 v0.2 content lint 未包含跨目录配对自动检查）|
| notes | 当前通过人工结构 lint 保障；自动化可提升可靠性 |

#### CR-005 WIKILINK-NO-RAW-PATH

| 字段 | 内容 |
|---|---|
| rule_id_proposed | WIKILINK-NO-RAW-PATH |
| severity | P2 |
| target_object | `wiki/` 目录下所有 `.md` 文件 |
| check_method | regex：检测 `\[\[(?:\.\./)?raw/` 或 `\[\[/.*raw/` 格式的 wikilink |
| standards_citation | AKB-2.0-GRAPH-LINKING.md:L367（"禁止：绝对路径、纯 slug 跨目录"）|
| estimated_finding_count | 预计 0（当前未见此类链接）|
| v02_covered | 否 |
| notes | 防御性规则；raw/ 不应成为 wiki 内链接目标 |

### 2.4 未纳入候选的条款（含原因）

| 条款摘要 | 来源 | 未纳入原因 |
|---|---|---|
| AI 回答必须包含 6 段（AI-QUERY-CONTRACT） | AKB-2.0-AI-QUERY-CONTRACT.md:L223 | 约束 AI 回答格式，非页面内容，lint 无法检查 |
| 跨设备互斥必须依赖三层组合 | AKB-2.0-AUTOMATION-BOUNDARY.md:L195 | 运行时/操作流程约束，非静态 lint |
| 任何失败必须写 final manifest | AKB-2.0-AUTOMATION-BOUNDARY.md:L310 | 运行时约束，非静态 lint |
| `active → deprecated` `active → archived` 等状态转换约束 | AKB-2.0-CONTENT-LIFECYCLE.md | 状态跃迁后验；部分已纳入 CR-003；余项需 git history 追踪，lint 无法单文件检查 |
| writeback executor 前置条件 | AKB-2.0-QUERY-WRITEBACK.md | writeback 专用流程约束，非 wiki/active 页通用规则 |
| active 页 slug 变更必须走迁移流程 | AKB-2.0-NAMING-CONVENTION.md:L414 | 需 git diff 检测文件名变化，静态 lint 无法实现 |
| gate_decision 字段必须为 active | AKB-2.0-PAGE-TEMPLATES.md:L77 | 部分已被 v0.2 STATUS-VALUE 规则覆盖 |

### 2.5 v0.3 启动条件评估

> 启动条件（plan v2.1）：Stage 2 standards census 出 ≥3 条 standards-backed 候选规则

**结论：满足。** 候选规则 5 条（CR-001 ~ CR-005），均有 standards citation 且可机器检查。

---

## §3. Concept Census（BL-D-014 待建概念）

### 3.1 来源文档

| 来源文件 | 路径 | 作用 |
|---|---|---|
| BL-D-014 列表 | `docs/phase-c-reports/wiki-tools-unblock-2026-05-07.md:L200` | 8 个待建概念首次列出 |
| cc-akb-search.md | `wiki/tools/cc-akb-search.md:L76-77` | 引用 akb-architecture / knowledge-retrieval-first（标注"待建"）|
| cc-executable-plan.md | `wiki/tools/cc-executable-plan.md:L76-77` | 引用 plan-execute-loop / review-alignment（标注"待建"）|
| cc-review.md | `wiki/tools/cc-review.md:L74-75` | 引用 dual-review / agent-collaboration（标注"待建"）|
| cc-skill-stocktake.md | `wiki/tools/cc-skill-stocktake.md:L95` | skill-lifecycle / freshness-tracking 在 wiki cleanup 时已删除待建 wikilink |

### 3.2 候选概念列表

#### CC-001 akb-architecture

| 字段 | 内容 |
|---|---|
| proposed_slug | concept-akb-architecture |
| source_evidence | cc-akb-search.md:L77（"计划入库的 AKB 设计概览"）|
| graph_role | concept hub |
| referred_by | wiki/tools/cc-akb-search.md |
| blocker_note | 无 source evidence 页作为入库依据；无 NLM/paper/transcript 可引用；需用户确认是否写 AKB 自文档作为 source |

#### CC-002 knowledge-retrieval-first

| 字段 | 内容 |
|---|---|
| proposed_slug | concept-knowledge-retrieval-first |
| source_evidence | cc-akb-search.md:L76（"先查再做工程原则"）|
| graph_role | concept hub |
| referred_by | wiki/tools/cc-akb-search.md |
| blocker_note | 无独立 source evidence 页；概念散布在多篇文档中（INTAKE-GATE、AUTOMATION-BOUNDARY 等）；需 source synthesis 或指定 primary source |

#### CC-003 freshness-tracking

| 字段 | 内容 |
|---|---|
| proposed_slug | concept-freshness-tracking |
| source_evidence | cc-skill-stocktake.md:L8（"巡检 285+ skill 库的 freshness，标记 stale skill"）|
| graph_role | concept hub |
| referred_by | wiki/tools/cc-skill-stocktake.md（已删除待建 wikilink，但 solves_problem 仍引用该概念）|
| blocker_note | 待建 wikilink 已在 P1d v3 wiki cleanup 中删除（2026-05-07）；概念仍活跃于 cc-skill-stocktake solves_problem；无 source evidence 页 |

#### CC-004 skill-lifecycle

| 字段 | 内容 |
|---|---|
| proposed_slug | concept-skill-lifecycle |
| source_evidence | cc-skill-stocktake.md（间接：巡检对象本质上是 skill lifecycle 管理）|
| graph_role | concept hub |
| referred_by | wiki/tools/cc-skill-stocktake.md（已删除待建 wikilink）|
| blocker_note | 待建 wikilink 已删除；concept 的直接 source evidence 最薄弱 — 比 freshness-tracking 更缺具体 source；优先级低于其余 7 个 |

#### CC-005 plan-execute-loop

| 字段 | 内容 |
|---|---|
| proposed_slug | concept-plan-execute-loop |
| source_evidence | cc-executable-plan.md:L76（wikilink 仍保留，标注"待建"）|
| graph_role | concept hub |
| referred_by | wiki/tools/cc-executable-plan.md |
| blocker_note | 无 source evidence 页；概念有 harness-engineering-deep-eval 间接支撑（§3.1 plan loop）；可用 harness-engineering-deep-eval 作为 evidence_by，但需确认 |

#### CC-006 review-alignment

| 字段 | 内容 |
|---|---|
| proposed_slug | concept-review-alignment |
| source_evidence | cc-executable-plan.md:L77（wikilink 仍保留，标注"待建"）|
| graph_role | concept hub |
| referred_by | wiki/tools/cc-executable-plan.md |
| blocker_note | 无 source evidence 页；AKB review 体系文档（LINT-RULES §review 部分）可作为部分依据，但非 NLM/外部来源 |

#### CC-007 dual-review

| 字段 | 内容 |
|---|---|
| proposed_slug | concept-dual-review |
| source_evidence | cc-review.md:L74（wikilink 仍保留，标注"待建"）|
| graph_role | concept hub |
| referred_by | wiki/tools/cc-review.md |
| blocker_note | 无 source evidence 页；harness-engineering-deep-eval 中有 dual-eval 论述可用；需确认是否可引用 |

#### CC-008 agent-collaboration

| 字段 | 内容 |
|---|---|
| proposed_slug | concept-agent-collaboration |
| source_evidence | cc-review.md:L75（wikilink 仍保留，标注"待建"）|
| graph_role | concept hub |
| referred_by | wiki/tools/cc-review.md |
| blocker_note | 无 source evidence 页；概念最宽泛，需 source 定锚（何种 agent 协作、何种证据支撑）才可建页 |

### 3.3 公共阻塞说明

**所有 8 个候选概念的共同阻塞**：

> 无已入库的 source evidence 页（wiki/sources/）作为直接依据。  
> AKB2.0 active page constitution 要求：active 概念页 `evidence_provenance` 必须为 `source_grounded` 或 `bridging_source_grounded`，且 `evidence_by` 指向至少 1 个 active source 页。  
> 当前 5 个 active source 页（anthropic-effective-context-engineering、harness-engineering-deep-eval、jenny-wen-ai-design-philosophy、karpathy-intro-to-llms、mcp-spec）对上述 8 个概念仅有间接支撑或无覆盖。

**后续路径**（非本计划范围，供用户决策）：

1. 选定 1-3 个优先概念 → 确认 source 来源（可用现有 source 或新入库 source）→ 建 candidate → 走 L4 门控 → active
2. 优先级建议（基于 wikilink 存活状态 + source 可及性）：
   - 高：CC-005 plan-execute-loop、CC-007 dual-review（harness-engineering-deep-eval 可用）
   - 中：CC-001 akb-architecture（需 AKB 自文档作为 source）、CC-006 review-alignment
   - 低：CC-002 knowledge-retrieval-first、CC-003 freshness-tracking、CC-008 agent-collaboration
   - 最低：CC-004 skill-lifecycle（wikilink 已删、source 最薄弱）

### 3.4 概念 census 完整性核对

BL-D-014 原始列表（来源：wiki-tools-unblock-2026-05-07.md:L200）：  
`akb-architecture / knowledge-retrieval-first / freshness-tracking / skill-lifecycle / plan-execute-loop / review-alignment / dual-review / agent-collaboration`

本 census 覆盖：8/8 ✓

---

## §4. 结论与接续

### 4.1 本计划结论

| 目标 | 结果 |
|---|---|
| Stage 1 P2 清零 + baseline freeze | ✓ 完成（P0=0/P1=0/P2=0，2026-05-08T011944）|
| Stage 2 standards census | ✓ 完成（5 条候选规则，≥3 条启动条件满足）|
| Stage 2 concept census | ✓ 完成（8 个候选概念，公共阻塞已记录）|

**本计划（v2.1）到此完结。**

### 4.2 后续独立计划（用户决策）

| 项 | 启动条件 | census 结论 |
|---|---|---|
| LINT CLI v0.3 实现 | Stage 2 standards census ≥3 候选规则 | **满足**（5 条候选：CR-001~CR-005）|
| 内容扩展（BL-D-014 概念建页）| Stage 2 concept census 完成 + 用户确认优先级 | **就绪**（8 个候选，优先级建议已提供；阻塞：source evidence 缺口）|
| 自动化 dry-run + `mcp__akb-search` MCP 挂载 | 用户明确启用意图 | 与本 census 无关；条件不变 |

---

## §5. 修订历史

| 日期 | 改动 | 作者 |
|---|---|---|
| 2026-05-08 | 初始 census 报告 — Stage 2 standards census（5 条候选）+ BL-D-014 concept census（8 个候选）| Claude Code |
| 2026-05-08 | errata 追加（Source-First Recensus 后）— CC-005 / CC-007 错误推断见下方 §Errata | praise + Claude Code |

---

## §Errata: 2026-05-08 Source-First Recensus

> **追加规则**：本节只追加，不改原 §3.2 表。历史判定保留，读者按本节修正预期。

### CC-005 plan-execute-loop — 错误推断替代

**原 §3.2 推断**（上游 akb2-census-week 早期版本）："harness-engineering-deep-eval §3.1 plan loop 间接支撑"

**错误性质**：经 grep 实测反验证，harness-engineering-deep-eval 中不含 plan loop 的直接论述；该推断不成立。

**本轮处置**：BL-D-014 Source-First 1-3 v2（2026-05-08）Lane B 入库 `langchain-plan-and-execute-agents`（LangChain 官方 plan-and-execute 综述）作为真 direct evidence source；CC-005 当前状态：`ready_for_candidate_next_plan` → 已建页 `wiki/concepts/concept-plan-and-execute.md`（active）。

上游错误推断不再被依赖；CC-005 的 source 证据由 `langchain-plan-and-execute-agents` 完整替代。

参考：`docs/phase-d-reports/bl-d-014-source-recensus-2026-05-08.md` §3.2 + §5

### CC-007 dual-review — 错误推断持续待替代

**原 §3.2 推断**："harness-engineering-deep-eval 含 dual-eval"

**错误性质**：经 grep 实测反验证，harness-engineering-deep-eval 不含 dual-eval 的直接定义；该推断不成立。

**本轮处置**：暂未入库替代 source；CC-007 维持 `needs_source`。下一轮另开 source 寻找计划（候选：dual-review / cross-review 工程文章）。

参考：`docs/phase-d-reports/bl-d-014-source-recensus-2026-05-08.md` §5
