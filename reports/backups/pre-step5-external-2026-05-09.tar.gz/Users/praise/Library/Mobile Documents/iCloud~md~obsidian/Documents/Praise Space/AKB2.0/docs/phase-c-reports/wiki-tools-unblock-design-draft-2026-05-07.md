---
report_type: phase_d_standards_revision_design_draft
report_id: wiki-tools-unblock-design-draft-2026-05-07
date: 2026-05-07
scope: 4 standards docs revision design (NOT yet committed to standards)
review_status: pending_codex_review_before_standards_edit
verdict_target: APPROVED_TO_EDIT_STANDARDS
---

# Phase D 标准修订设计草案（review-only，未动 standards doc）

> **本文件目的**：按 plan §"标准 review 通过后，才修 5 个 wiki/tools 页面" + 用户确认第 1 点 "中段先加'标准修订设计草案'并 review 后再动 standards doc"。
> 
> **本文件状态**：设计草案，**所有 standards doc 未被修改**。`docs/AKB-2.0-INTAKE-GATE.md` / `PAGE-TEMPLATES.md` / `LINT-RULES.md` / `FOLDER-STRUCTURE.md` mtime ≤ 5/5（C1 之前），本设计草案 review 通过后才动。

---

## §0. 执行中发现的设计冲突（v2 reconciliation，2026-05-07）

设计草案 v1 Codex APPROVED 后，进入 Phase 3 准备动 standards doc 时**实际读 PAGE-TEMPLATES §4.7 + FOLDER-STRUCTURE §3.4 + 验证 toolbox/tools/cc-*.md 全部存在**，发现两个材料冲突：

| 冲突 | 设计草案 v1 | 实际现存标准 | v2 处置（用户 2026-05-07 决策 Option A）|
|---|---|---|---|
| **§4.7 vs §3.7.4 同名** | 提议在 PAGE-TEMPLATES 新增 §3.7.4 tool-understanding 模板差异 | §4.7 已存在 tool-understanding 模板（5 必备节：是什么/解决什么问题/何时用 何时不用/与替代品对比/相关概念 + 必填 frontmatter: tool_name/tool_category/solves_problem/compared_to）| **DROP §3.7.4 patch**；改为 §4.7 EXTEND 加 own-ecosystem 子型 4-5 行 |
| **跨边界 wikilink 规则** | 提议 `WIKI-TOOLBOX-CROSS-WIKILINK` P2 禁规则 + FOLDER-STRUCTURE 新增 §X.Y 禁跨边界 | **§4.7 明文强制要求** "必须链接对应的 tool-card(toolbox/tools/<slug>)"；toolbox/tools/cc-*.md 实际存在（4 个 cc-* + cc-local-llm 全有）；wikilink 是 §4.7 设计的配对机制 | **DROP `WIKI-TOOLBOX-CROSS-WIKILINK` 规则**；**DROP FOLDER-STRUCTURE 禁跨边界 patch**；改为新规则 `WIKI-TOOLS-CALL-CONTRACT-LEAK` 限制"调用契约正文"混入 wiki/tools |

**用户决策 Option A 4 点细化**：
1. §4.7 保留权威，只扩 own-ecosystem 子型
2. `与替代品对比` 对 own-ecosystem 降为"与相邻工作流/不用该工具的替代路径对比"，不是必须外部竞品
3. 删除 `WIKI-TOOLBOX-CROSS-WIKILINK` 禁规则；改为"允许同 slug tool-card 配对链接，但禁止把调用契约正文混入 wiki/tools"
4. FOLDER-STRUCTURE 只写职责边界（§3.4 已说），不禁合法互链；本 plan 不动 FOLDER-STRUCTURE

**v2 实际待动 standards doc 收窄到 3 个**（FOLDER-STRUCTURE 不动）：INTAKE-GATE / PAGE-TEMPLATES / LINT-RULES。

---

## §1. 设计原则

1. **诚实**：每条规则上线前在 11 active（10 + cc-local-llm）做 retroactive scan，若有 violation，先决定改规则措辞还是改 active；不让规则上线即打破 C3 PASS 状态
2. **最小**：4 个 standards doc 改动控制在最小补丁，不重写整段；不引入未列在 plan 中的新规则
3. **跨 doc 一致**：4 doc 互引；本设计草案中所有 cross-reference 必须可解析
4. **规范层不强制**：新增 LINT 规则属规范层，执行依赖人审 + plan-time validation；自动 LINT CLI 待 BL（独立 plan）

---

## §2. 设计草案：4 个 standards doc 改动汇总

### §2.1 `docs/AKB-2.0-INTAKE-GATE.md`

#### Patch INTAKE-GATE-1：tool-understanding active 追加标准（新增 §4.3）

**位置**：在现有 §4.2 "Active Page Constitution 实施" 之后新增 §4.3。

**新增内容（v2 reconciliation：引用 PAGE-TEMPLATES §4.7 不重复定义）**：

```markdown
### §4.3 tool-understanding 模板 active 追加标准（v3.1 Phase D BL-C3-001 闭环）

承接 §4.1 5 类 claim 类型 + §4.2 active 标准追加 4 项；本节专门规定 `template_type: tool-understanding` 类页面的 active gate。

#### §4.3.1 tool-understanding active 必备结构（引用 PAGE-TEMPLATES §4.7）

tool-understanding 类 active 的正文必备节、frontmatter 必填字段、必须链接由 [[AKB-2.0-PAGE-TEMPLATES|PAGE-TEMPLATES]] §4.7 定义；本节不重复，仅指明 active gate 时必须按 §4.7 检查：

- 5 必备节（接受别名，详见 PAGE-TEMPLATES §3.7.3 模板别名规则）：`## 是什么` / `## 解决什么问题` / `## 何时用` + `## 何时不用` / `## 与替代品对比` / `## 相关概念`
- 必填 frontmatter：`tool_name` / `tool_category` / `solves_problem` / `compared_to`
- 必须链接：对应 toolbox/tools/<slug> tool-card + ≥1 related_concepts

#### §4.3.2 own-ecosystem 子型变体（v3.1 新增）

对于 own-ecosystem skill 类（如 Codex 端 cc-* skill / Claude Code 端 mcp-* tool），§4.7 适配如下：

- `compared_to` 字段允许"与相邻工作流 / 不用该工具的替代路径"，不强制是外部竞品（详见 PAGE-TEMPLATES §4.7 own-ecosystem 子型）
- 推荐附加节（非必填，但提升可读性）：`## 风险与限制`（含 risk_level 标注）/ `## Claude / Codex 使用判断` / `## 维护记录`
- 推荐附加 frontmatter：`risk_level`：low / medium / high；`runtime_mutation_allowed`、`automation_allowed`：true / false（own-ecosystem skill 涉及运行时副作用时强制）

#### §4.3.3 wiki/tools active 与 toolbox/ 资产的关系（v2 reconciliation）

- `wiki/tools/` = 工具的**理解层**文档（What / Why / 使用场景）
- `toolbox/tools/` 等 = 工具的**可执行资产**（调用契约 / inputs/outputs schema / 命令模板）
- 两层 1:1 对应：每个 active wiki/tools 页面**必须** wikilink 到对应 `toolbox/tools/<slug>` tool-card（§4.7 强制要求）
- **职责边界**（承接 FOLDER-STRUCTURE §3.4 已声明）：
  - wiki/tools 正文**不应**包含完整调用契约（inputs/outputs schema、命令模板、可执行代码块超过示意）—— 那些进 toolbox/tools/ 或 toolbox/interfaces/
  - 违反触发新规则 `WIKI-TOOLS-CALL-CONTRACT-LEAK` P2（详见 LINT-RULES）
```

**Retroactive scan**（按 §4.7 5 必备节 + own-ecosystem 子型）：

| cc-* | tool_name | tool_category | solves_problem | compared_to | ## 是什么 | ## 解决 | ## 何时用/不用 | ## 与替代品对比 | ## 相关概念 |
|---|---|---|---|---|---|---|---|---|---|
| cc-local-llm（active）| ❌缺 | ❌缺 | ❌缺 | ❌缺 | ✅ | ✅ | ✅ | ❌缺 | ✅（关联工具）|
| cc-akb-search（cand） | ❌ | ❌ | ❌ | ❌ | ✅（这工具是什么）| ✅ | ✅ | ❌缺 | ✅ |
| cc-skill-stocktake（cand）| ❌ | ❌ | ❌ | ❌ | ✅ | ✅ | ✅ | ❌缺 | ✅ |
| cc-executable-plan（cand）| ❌ | ❌ | ❌ | ❌ | ✅ | ✅ | ✅ | ❌缺 | ✅ |
| cc-review（cand）| ❌ | ❌ | ❌ | ❌ | ✅ | ✅ | ✅ | ❌缺 | ✅ |

**5 个 cc-* 共同缺口**：
- frontmatter 全缺 `tool_name` / `tool_category` / `solves_problem` / `compared_to` 4 字段
- 正文全缺 `## 与替代品对比`（own-ecosystem 子型可降为 `## 与替代路径对比`）
- 推荐节（own-ecosystem）部分有：## 风险与限制 ✅ 5/5；## Claude/Codex 使用判断 ✅ 5/5；## 维护记录 ❌ 0/5

**Phase 4 修复策略**：
- 4 candidates：补 4 frontmatter 字段 + 加 `## 与替代路径对比` 节 + 评估能否升 active
- cc-local-llm（P1c 流程）：用户决策"顺手修"，但避免触动 P1c 决策的核心字段。本 plan 加 frontmatter 4 字段（属补充而非覆盖 P1c 字段）+ 加 `## 与替代路径对比` 节 + 加 `## 维护记录` 节

---

#### Patch INTAKE-GATE-2：通用 frontmatter 长字段规则（修订 §5.1）

**位置**：现有 §5.1 META-WALL 表新增一行。

**当前 §5.1 表（摘录）**：

```
| frontmatter 含长 narrative 字段(`core_summary` 长 / `gate_reason` >120 字 / 长数组 future_questions / 嵌套 origin/l4_manifest_ref/decision_refs) | `METADATA-ARTICLE-IN-YAML` P1 | 提议 needs_repair + 按宪法 §3.1.4 supersede 表移正文或 manifest |
```

**修订为**（用户决策：阈值 150）：

```
| **任意** frontmatter 字符串字段 >150 字符（不限于 `gate_reason` / `core_summary`；包含 `status_change_reason` / `gate_reason_detail` 等）| `METADATA-LONG-FIELD` P1 | 提议 needs_repair + 移正文或 manifest |
```

**Retroactive scan 结果**（150 阈值下）：
- 11 篇 active：**0 violations** ✅
- cc-local-llm `status_change_reason` 122 字符 < 150，合规
- 真实 META-WALL 案例（demote 前 cc-executable-plan 259 字 / cc-review 276 字）仍能被规则捕获

**用户决策**：阈值 150（不为单条 P1c 流程产出放宽规则的反向考量：cc-local-llm 122 字本身已经偏长，但 150 阈值仍能防住实际 META-WALL；为整个生态留缓冲）。

---

#### Patch INTAKE-GATE-3：维护记录条数上限（新增 §5.2）

**位置**：在现有 §5.1 之后新增 §5.2。

**新增内容**：

```markdown
### §5.2 维护记录格式上限（v3.1 Phase D BL-C3-002 + BL-C3-003 闭环）

active 正文 ## 维护记录 节不应膨胀成第二个 frontmatter 墙。规则：

#### §5.2.1 条数上限

- ## 维护记录 表最多保留 **最近 5 条**
- 超过 5 条时，最早的条目移到 `manifests/` 或 `archive/changelogs/<slug>--changelog.md`
- 当前条数 > 5 触发 `BODY-MAINTENANCE-LOG-OVERFLOW` P2

#### §5.2.2 单条格式

每条维护记录单行，4 列：日期 | 动作 | 依据 | reviewer

- 日期：YYYY-MM-DD
- 动作：1-2 句概述（不展开 frontmatter 字段细节；那些进 manifest）
- 依据：plan slug 或 review 路径
- reviewer：praise 或 praise + Claude Code 等

不允许在单条维护记录中堆砌 200+ 字 narrative；超长描述触发 `BODY-MAINTENANCE-LOG-VERBOSE` P2。
```

**Retroactive scan 结果**：
- 11 active：**0 violations**（所有 ≤ 5 条；harness-NLM 在 5 条临界，下次 touch 会触发）
- **决策**：上线规则 + 给 harness-NLM 加 BL-D-012（next touch 之前需先归档最早 1 条到 changelog）

---

### §2.2 `docs/AKB-2.0-PAGE-TEMPLATES.md`（v2 reconciliation）

#### Patch PAGE-TEMPLATES-1：§4.7 EXTEND own-ecosystem 子型变体（不新增 §3.7.4）

**位置**：现有 §4.7 tool-understanding 节末追加 own-ecosystem 子型说明（4-5 行）。

**追加内容**：

```markdown
**own-ecosystem 子型变体**（v1.6 Phase D BL-C3-001 闭环；适用 Codex 端 cc-* skill / Claude Code 端 mcp-* tool 等内部生态工具）：
- `tool_category` 允许新值 `agent-skill`（own-ecosystem skill 类）
- `compared_to` 允许"与相邻工作流 / 不用该工具的替代路径对比"，不强制是外部竞品
- 推荐附加节：`## 风险与限制`（含 risk_level 标注）/ `## Claude / Codex 使用判断` / `## 维护记录`
- 推荐附加 frontmatter：`risk_level` / `runtime_mutation_allowed` / `automation_allowed`（own-ecosystem skill 涉及运行时副作用时强制）
- INTAKE-GATE §4.3 active gate 检查时按本子型适配（详见 INTAKE-GATE §4.3.2）
```

---

#### Patch PAGE-TEMPLATES-2：§3.7.3 模板别名规则 EXTEND（不新建 §3.7.3.X）

**位置**：现有 §3.7.3 "##### 模板别名规则" 子节（line 373-385）后追加完整 9 行 alias 表。

**当前子节内容（仅 `## 核心论点` 别名表 5 行）**：

```
| template_type | 默认 anchor section | 等价别名 |
| source(默认) | ## 核心论点 | (默认) |
| source(walkthrough-grounded) | ## 标签级主题清单 | ## 核心论点 |
| concept | ## 概念定义 | ## 核心论点 |
| design | ## 设计原则陈述 | ## 核心论点 |
| synthesis | ## 综合论点 | ## 核心论点 |
```

**追加内容**（v1.6 Phase D BL-C3-003 闭环）：

```markdown
**全节别名映射（v1.6 补丁，扩展上表只覆盖 `## 核心论点` 的局限）**：

| canonical 节 | 接受别名 |
|---|---|
| `## TLDR` | （无别名，统一） |
| `## 入选理由` | `## 为什么值得入库`、`## 这工具是什么` + `## 解决什么问题`（tool-understanding 用，两节并存） |
| `## 证据地图` | （无别名，统一） |
| `## 核心论点` | `## 核心观点`、`## 概念定义`、`## 标签级主题清单`、`## 设计原则陈述`、`## 综合论点`、`## 是什么`（tool-understanding 用） |
| `## 论证与解释` | （无别名，统一） |
| `## 适用边界` | `## 何时用` + `## 何时不用`（tool-understanding 用，两节并存） |
| `## 图谱关系` | `## 关联概念` + `## 关联工具`（tool-understanding 用，两节并存） |
| `## Future Questions` | `## 后续缺口` |
| `## 维护记录` | （无别名，统一） |

约定：
- 任一别名出现 = 该 canonical 节 PASS
- canonical 名是 LINT 输出 + manifest schema 标准名
- 别名仅作"避免误判"用途，不强制规范化
- LINT-RULES `BODY-QUALITY-MISSING-STRUCTURE` 应按本表识别别名
```

---

### §2.3 `docs/AKB-2.0-LINT-RULES.md`

#### Patch LINT-RULES-1：3 条新规则（追加到现有规则列表）

**位置**：现有 LINT 规则列表末追加。

**新增 3 条**：

| Rule ID | 严重级 | 触发条件 | 修复建议 |
|---|---|---|---|
| `METADATA-LONG-FIELD` | P1 | 任意 frontmatter 字符串字段 > 150 字符 | 移到正文或 manifest |
| `BODY-MAINTENANCE-LOG-OVERFLOW` | P2 | ## 维护记录 节条数 > 5 | 最早条目移到 archive/changelogs/ |
| `BODY-MAINTENANCE-LOG-VERBOSE` | P2 | 单条维护记录 narrative > 200 字 | 拆分到 manifest 或 changelog |
| `TOOL-UNDERSTANDING-MISSING-STRUCTURE` | P1 | tool-understanding 模板 active 缺 PAGE-TEMPLATES §4.7 5 必备节中任一 + own-ecosystem 子型按 §4.3.2 适配 | 补节或保 candidate |
| `WIKI-TOOLS-CALL-CONTRACT-LEAK` | P2 | wiki/tools/*.md 正文含完整调用契约（inputs/outputs schema、命令模板、可执行代码块超过示意） | 调用契约移到 toolbox/tools/ 或 toolbox/interfaces/；wiki/tools 仅理解层 |

**v2 reconciliation**：DROP `WIKI-TOOLBOX-CROSS-WIKILINK` 规则（与 §4.7 强制要求 wikilink 到 toolbox/tools/<slug> 矛盾）；改为 `WIKI-TOOLS-CALL-CONTRACT-LEAK` 限制调用契约正文混入而非禁止链接（用户决策 Option A 第 3 点）。

**重要声明**（追加到 LINT-RULES.md 顶部）：

```markdown
> **执行层声明**（v1.X Phase D 加，2026-05-07）：本规则集属**规范层**。当前 vault 内**没有自动 LINT CLI** 实现；规则执行依赖：
> 1. 人审（reviewer 在 INTAKE 时手工对照本表）
> 2. plan-time validation（每个 plan 的 Test Plan 节按需 grep / awk 验证）
> 3. 后续单开 plan 实现 LINT CLI 后才有自动检查
> 
> 规则添加 = 规范文档加文字；不等于即时强制。
```

---

### §2.4 `docs/AKB-2.0-FOLDER-STRUCTURE.md`（v2 reconciliation：DROP）

按用户决策 Option A 第 4 点，FOLDER-STRUCTURE 已在 §3.4 wiki/tools 行 + §3.5 toolbox/ 节明示职责边界（理解层 vs 调用层 + 哪些不收）。本 plan **不动 FOLDER-STRUCTURE**。

§3.4 现有原文（line 167）：

```
| tools/ | 工具理解页（What / Why / 使用场景） | Agent 调用接口定义（进 toolbox/interfaces/）；Prompt 模板（进 toolbox/prompts/） |
```

已包含"调用接口定义不收"的语义，等价于 LINT 新规则 `WIKI-TOOLS-CALL-CONTRACT-LEAK` 的标准依据。

---

## §3. 设计草案内部一致性检查（v2 reconciliation 后）

| Cross-reference | 状态 |
|---|---|
| INTAKE-GATE §4.3.1 引 PAGE-TEMPLATES §4.7（5 必备节 + 必填字段） + §3.7.3 模板别名规则 | 单向 ✅（§4.7 已存在，本 plan EXTEND 不重复定义） |
| INTAKE-GATE §4.3.2 own-ecosystem 子型 → PAGE-TEMPLATES §4.7 own-ecosystem 子型变体 | 双向 ✅ |
| INTAKE-GATE §4.3.3 wiki/tools ↔ toolbox 关系 → FOLDER-STRUCTURE §3.4 现有边界 + LINT WIKI-TOOLS-CALL-CONTRACT-LEAK | 单向 ✅（FOLDER-STRUCTURE 不动，引用现有内容） |
| INTAKE-GATE §5.2 引 LINT BODY-MAINTENANCE-LOG-OVERFLOW / VERBOSE | 单向 ✅ |
| PAGE-TEMPLATES §3.7.3 模板别名规则 EXTEND（9 行 alias 表）→ LINT BODY-QUALITY-MISSING-STRUCTURE | 单向 ✅（已有 5 行只覆盖 ## 核心论点，扩到 9 行覆盖全节） |
| LINT METADATA-LONG-FIELD → INTAKE-GATE §5.1 | 单向 ✅ |
| LINT WIKI-TOOLS-CALL-CONTRACT-LEAK → FOLDER-STRUCTURE §3.4 现有 + INTAKE-GATE §4.3.3 | 单向 ✅ |
| LINT TOOL-UNDERSTANDING-MISSING-STRUCTURE → PAGE-TEMPLATES §4.7（含 own-ecosystem 子型）+ INTAKE-GATE §4.3 | 单向 ✅ |

**v2 reconciliation 删除的引用**：
- ~~LINT WIKI-TOOLBOX-CROSS-WIKILINK → FOLDER-STRUCTURE §X.Y~~（规则与 doc patch 都 DROP）
- ~~INTAKE-GATE §4.3.2 references_toolbox 字段 → FOLDER-STRUCTURE §X.Y~~（字段 DROP，wikilink 是 §4.7 强制要求）

无悬挂引用；3 doc（INTAKE-GATE / PAGE-TEMPLATES / LINT-RULES）互引闭环；FOLDER-STRUCTURE 不动。

---

## §4. Retroactive scan 总览（决策待用户）

| 规则 | 11 active 现存 violation | 用户决策处置 |
|---|---|---|
| METADATA-LONG-FIELD (>150 字) | **0** ✅ | 上线规则；阈值 150 已避免 retroactive |
| BODY-MAINTENANCE-LOG-OVERFLOW (>5 条) | 0（harness-NLM 在 5 条临界） | 上线规则；harness-NLM 加 BL-D-012 next touch 前归档最早条 |
| BODY-MAINTENANCE-LOG-VERBOSE (>200 字/条) | 多处（C2 / C3 维护记录单条 250-500 字描述详细操作） | **P2 警告（用户决策）**：上线规则；现有过长条目 next touch 时压缩；不立即 retroactive fail |
| TOOL-UNDERSTANDING-MISSING-STRUCTURE | 1（cc-local-llm 缺 ## 维护记录 节；## 输入与输出 走 inline 选项 OK）| **本 plan 顺手修（用户决策）**：Phase 4 给 cc-local-llm 补 ## 维护记录 节后即满足 9 节合规 |
| WIKI-TOOLBOX-CROSS-WIKILINK | 5（5 wiki/tools 全部含 cc-local-llm）| **本 plan 顺手修 cc-local-llm（用户决策）**+ 4 candidates 在 Phase 4 一并改 references_toolbox |

**总 retroactive backlog**：1 条新 BL（BL-D-012 harness-NLM 维护记录 next touch 前归档）。其它 retroactive 问题在本 plan Phase 4 顺手修（含 cc-local-llm）。

---

## §5. 用户决策（2026-05-07）

3 个待确认问题已得用户决策：

1. **METADATA-LONG-FIELD 阈值**：选 **150**（不为 cc-local-llm 单条 P1c 流程产出放宽规则的反向考量；150 仍能抓 META-WALL 真案例）
2. **BODY-MAINTENANCE-LOG-VERBOSE 严重级**：选 **P2 警告**（不阻塞 current state；next touch 时压缩）
3. **cc-local-llm 处置**：选 **本 plan 顺手修**（122 字 status_change_reason 已 < 150 阈值不需改；但缺 ## 维护记录 节 + 3 跨边界 wikilink 需 Phase 4 一并修）

下一步：本设计草案发 Codex review；APPROVED 后进 Phase 3 动 4 个 standards doc。

---

## §6. 维护记录

| 日期 | 动作 | 依据 | reviewer |
|---|---|---|---|
| 2026-05-07 | 初始本设计草案；4 standards doc 改动汇总 + retroactive scan + 内部一致性检查 + 3 个待用户确认问题 | plan: AKB2.0 wiki/tools 解锁与标准修订闭环 + 用户确认 4 点微调 | praise |
| 2026-05-07 | Codex review-1 REQUIRES_CHANGES 2 P2 修复：(1) cc-local-llm 修复方案 §2.1 retroactive scan 子节澄清 9 节按 inline 选项判定，实际仅缺 ## 维护记录 1 节；(2) cross-reference 悬挂修复（INTAKE-GATE §4.3.1 引用 PAGE-TEMPLATES §3.7.4 → §3.7.3.X 别名表实际位置）；§3 内部一致性表更新 | Codex result-20260507T102745Z.md | praise |
| 2026-05-07 | **v2 reconciliation**（执行中发现 2 个材料冲突 → 用户决策 Option A 4 点细化）：(1) PAGE-TEMPLATES §4.7 已存在 tool-understanding 模板（5 必备节 + 4 frontmatter 必填字段）→ DROP 设计草案 v1 新增 §3.7.4 patch；改为 §4.7 EXTEND own-ecosystem 子型（4-5 行）；(2) §4.7 强制要求 wiki/tools wikilink 到 toolbox/tools/<slug>，toolbox/tools/cc-*.md 全部存在 → DROP `WIKI-TOOLBOX-CROSS-WIKILINK` 规则；DROP FOLDER-STRUCTURE §X.Y patch；新增 `WIKI-TOOLS-CALL-CONTRACT-LEAK` P2 限制调用契约正文混入；(3) PAGE-TEMPLATES §3.7.3 模板别名规则已存在（5 行只覆盖 ## 核心论点）→ EXTEND 到 9 行覆盖全节，不新建 §3.7.3.X；(4) Phase 4 修复策略调整：5 cc-* 共同缺 4 frontmatter 字段（tool_name/tool_category/solves_problem/compared_to）+ ## 与替代品对比节（own-ecosystem 子型降为 ## 与替代路径对比）；§3 内部一致性表更新 | 用户 2026-05-07 决策 + Codex review pending | praise |
