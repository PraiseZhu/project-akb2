---
report_type: phase_c_usability_validation
report_id: phase-c1-active-usability-validation-2026-05-06
date: 2026-05-06
scope: 7 wiki active pages
source_manifest: manifests/ingest/2026-05-05-active-rewrite.jsonl
review_baseline: c9c2dd365172/result-20260506T113337Z.md
predecessor_report: docs/phase-c-reports/active-page-constitution-rewrite-validation-2026-05-06.md
verdict: PASS_WITH_BACKLOG
---

# AKB2.0 Phase C1 — Active 可用性验收报告

## 执行摘要

Phase B0 → C0 已完成 7 篇 active 的"结构合格"验收（fm/H2/必备节/source-grounding/Codex APPROVED）。本轮 C1 验证"能不能被人和 Claude/Codex 实际使用"。

**结论**：`PASS_WITH_BACKLOG`

- 8 个真实 query 中 4 条 `yes` + 4 条 `partial` + 0 条 `no`
- 图谱关系健康（7 active 双向链接齐全）
- Index 导航可用（每条索引行含一句人读摘要，可作 Claude/Codex 入口）
- Obsidian 阅读体验：`pending_user_visual_check`（用户未提供截图，不假装通过）
- 4 类 backlog（P1×3 / P2×4 / P3×1）已记录，本轮不修

7 篇 active 可作为 Phase C 运营起点；下一阶段 C2 可启动 query/graph/lint 实际使用路线。

---

## §1. 7 篇 active 清单

| # | slug | template | graph_role | graph_status | evidence_provenance |
|---|---|---|---|---|---|
| 1 | `karpathy-intro-to-llms` | source | evidence | orphan_risk | bridging_source_grounded |
| 2 | `harness-engineering-deep-eval` | source | evidence | healthy | bridging_source_grounded |
| 3 | `jenny-wen-ai-design-philosophy` | source | evidence | healthy | bridging_source_grounded |
| 4 | `concept-large-language-model` | concept | hub | orphan_risk | bridging_source_grounded |
| 5 | `concept-harness-engineering` | concept | hub | healthy | bridging_source_grounded |
| 6 | `concept-context-engineering` | concept | cluster_center | orphan_risk | bridging_source_grounded |
| 7 | `implementation-aware-design` | design | design-memory | healthy | bridging_source_grounded |

3 篇 `orphan_risk` 都是单 source 桥接（已诚实标注），不是质量 fail。

---

## §2. Manifest / Backup / Report / Review 对应关系

| 件 | 路径 | 状态 |
|---|---|---|
| Manifest | `manifests/ingest/2026-05-05-active-rewrite.jsonl` | 7 行，schema_version=akb-l4-rewrite-v3 ✅ |
| Backup | `archive/active-pre-rewrite-2026-05-05/` | 7 个 .md ✅ |
| Phase C 验收报告 | `docs/phase-c-reports/active-page-constitution-rewrite-validation-2026-05-06.md` | verdict=PASS（标题"7 必备节"已修为"9 必备节"）✅ |
| Phase C 最终 Codex review | `~/.claude/review-baselines/c9c2dd365172/result-20260506T113337Z.md` | APPROVED, 0 findings ✅ |
| 前序 Codex review | `~/.claude/review-baselines/c9c2dd365172/result-20260506T102704Z.md` | APPROVED, 0 findings ✅ |

manifest 内 7 行的 `page_path` / `backup_path` / `gate_decision` 字段与上述对应。

---

## §3. 查询验收矩阵

### Q1（用户题）：AKB2.0 里 large language model 的核心 mental model 是什么？它和 agent / tool use / memory 有什么关系？

- query: AKB2.0 LLM 核心 mental model + 与 agent/tool use/memory 的关系
- expected_entrypoint: `wiki/concepts/large-language-model.md`
- hit_pages: `concept-large-language-model`、`karpathy-intro-to-llms`、`concept-harness-engineering`
- evidence_section:
  - concept-LLM `## 概念定义`（line 56-63）— 标签级定义 + 三主题域
  - concept-LLM `## 论证与解释 — evidence 限制`（line 67-74）— 单 source 桥接说明
  - karpathy `## 标签级主题清单`（line 60）— OS kernel mental model 标签级提及
  - concept-HE `## 概念定义`（line 59-63）— "LLM 视为引擎"心智可桥接
- answer_quality: **partial**
  - mental model 标签级回答 OK（Transformer + next-token + OS kernel + 三阶段训练）
  - 与 agent 关系：concept-LLM `related_concepts` 直接指 HE，可桥接
  - 与 tool use 关系：必须 2 跳到 HE 7 大组件第 1 条（MCP 工具调用）
  - 与 memory 关系：必须 2 跳到 HE 7 大组件第 2 条 + CE concept 的 CE/Memory 边界
- missing_context: karpathy transcript 未入库（OS kernel 五要素映射、scaling laws、三阶段训练数据全部未展开）；`concept-mcp-tool-use` / `concept-llm-memory` / `concept-agentic-loop` 在 Pending
- next_action: backlog P1 — karpathy transcript 升级 + 入库 LLM 子概念页

### Q2（用户题）：Harness Engineering 和 Context Engineering 的边界是什么？我做 Claude Code / MCP / agent 工具时应该分别怎么用？

- query: HE/CE 边界 + Claude Code/MCP/agent 工具应用指引
- expected_entrypoint: `wiki/concepts/harness-engineering.md` + `wiki/concepts/context-engineering.md`
- hit_pages: `concept-HE`、`concept-CE`、`harness-engineering-deep-eval`
- evidence_section:
  - concept-HE `## 在 PE/CE/HE 范式中的位置`（line 67-77）— 三层对比表
  - concept-HE `## 论证与解释 — 7 大核心技术组件`（line 81-91）
  - concept-CE `## 论证与解释 — CE vs HE Memory 边界`（line 85-95，标 akb_interpretation）
  - harness source `## 应用场景 / 例子`（line 137-156）— 15 工具横评含 Claude Code
- answer_quality: **partial**
  - HE/CE 边界部分：**yes** — 三层对比表清晰（CE 关注信息架构 20-40% Recall；HE 关注执行环境 50-300% Intent Met；HE outer loop 包裹 CE）
  - Claude Code 应用：harness source §四.1 把 Claude Code 列为"技能化/原生集成"哲学并给关键能力 5 维度评分，但只是定性
  - MCP 应用：harness source §二.1 第 1 条 tool use 提及 MCP 标准化扩展动作空间，但 MCP 本身无 concept 页（Pending）
  - agent 工具应用：15 工具横评 + 5 工具评分矩阵可对比，但缺单工具深度
- missing_context: `concept-mcp-tool-use` / `entity-claude-code` / `entity-cursor` / `entity-cline` 全部 Pending；缺 Claude Code 的 production 配置最佳实践
- next_action: backlog P1 — 入库 `concept-mcp-tool-use`；backlog P2 — entity-claude-code

### Q3（用户题）：Implementation-aware design 对我做 AI 工具、设计系统、Figma/Code Connect 工作流有什么具体指导？

- query: IAD 对 AI 工具/设计系统/Figma Code Connect 工作流的具体指导
- expected_entrypoint: `wiki/designs/implementation-aware-design.md`
- hit_pages: `implementation-aware-design`、`jenny-wen-ai-design-philosophy`
- evidence_section:
  - IAD `## 设计原则陈述`（line 61-74）— Anthropic 30/30/30 时间分配
  - IAD `## 论证与解释 — 三件套落地`（line 78-88）— 三件套件 1/2/3
  - IAD `## 论证与解释 — 三类人才原型`（line 90-100）
  - IAD `## 论证与解释 — 协作模式`（line 102-107）— "让工程师直接开火"
  - IAD `## 适用边界`（line 139-162）— Anthropic 特定情境 + 受监管行业不适用
- answer_quality: **partial**
  - AI 工具 / 设计师角色侧：**yes** — 30/30/30 时间分配 + Block-shaped Generalist 三类人才 + 协作模式
  - 设计系统侧：三件套件 3 提及 design tokens + Code Connect，**但本 source 明示"未给具体 tokens 治理细节"**
  - Figma Code Connect 工作流侧：仅件 3 提及，**无具体工作流细节**；IAD `## AKB2.0 中的角色` 第 3 条标 toolbox/design 子区可承接但 `concept-design-tokens-governance` / `concept-claude-cowork` 在 Pending
  - 适用边界：清晰列出受监管行业 / 多 brand / 6 月+ 长期场景不适用
- missing_context: design tokens governance 工具未入库；Code Connect MCP server 未入库；多产品 brand governance 框架未覆盖
- next_action: backlog P2 — 收集 Code Connect / Figma plugin 类工具源 + 入库 `concept-design-tokens-governance`

### Q4（补充题，Claude/Codex 工作）：如果我要设计 agent harness，应该先读哪些页？

- query: 设计 agent harness 的阅读路径
- expected_entrypoint: `wiki/concepts/00-Index.md` § agent / Claude Code 工程
- hit_pages 推荐顺序:
  1. `concept-harness-engineering`（HE 定义 + 三层范式位置 + 7 组件 + 8-Factor）
  2. `harness-engineering-deep-eval`（35 源 NLM 系统化 + 实证 + 15 工具横评）
  3. `concept-context-engineering`（CE 边界 + CE/HE Memory 区分）
  4. `concept-large-language-model`（LLM 引擎心智）
  5. `implementation-aware-design`（设计协同侧 + Anthropic 工具设计即 UX）
- evidence_section: 各页 TLDR + ## 入选理由 即可建路径，无需深入
- answer_quality: **yes** — 路径清晰，4 篇 concept/design + 1 篇 source 形成完整入口
- missing_context: 后续若要选具体工具（Claude Code vs Cursor vs Cline）缺单 entity 页；7 组件 production agent 的精确覆盖率矩阵未给（NLM 自身 §四.1 仅定性）
- next_action: backlog P2 — entity-claude-code / entity-cursor 等

### Q5（补充题，Claude/Codex 工作）：Claude Code/Codex 使用 AKB2.0 时，哪些概念页能提供上下文？

- query: AKB2.0 当前能给 Claude Code/Codex 提供上下文的概念清单
- expected_entrypoint: `wiki/concepts/00-Index.md`
- hit_pages: 3 concept（LLM / HE / CE）+ 1 design（IAD）
- evidence_section: 3 个 00-Index.md 的索引行人读摘要 + 各页 TLDR
- answer_quality: **yes** — Index 索引行的一句人读摘要清晰可作 entry；4 篇 concept/design 覆盖 LLM 入门 / agent 工程主线 / 设计协同侧
- missing_context: 仅 4 概念入口；entity 类页（Claude Code / Cursor / Anthropic / MCP / Stripe / Anthropic）全部 Pending；synthesis 类页 0
- next_action: backlog P2 — 入库高频引用的 entity 页（Anthropic / Claude Code / MCP）

### Q6（补充题，图谱导航）：从 `large-language-model` 能否跳到 `harness-engineering` 和 `context-engineering`？

- query: LLM concept → HE / CE 跳转可达性
- evidence_section: concept-LLM frontmatter `related_concepts` + concept-HE frontmatter `related_concepts`
- answer_quality: **partial**
  - LLM → HE: ✅ 1 跳（LLM `related_concepts: [concept-harness-engineering]`）
  - LLM → CE: ❌ 直接，但 LLM → HE → CE 2 跳可达（HE `related_concepts` 含 CE）
  - 反向：HE `related_concepts` 含 LLM ✅ 双向
- missing_context: LLM frontmatter 未直接列 CE — 但语义上 CE 是 HE 的 part_of，2 跳合理
- next_action: backlog P3（可选）— 在 LLM frontmatter `related_concepts` 加 CE 直链

### Q7（补充题，图谱导航）：从 `implementation-aware-design` 能否追溯到 Jenny source？

- query: IAD → Jenny source 追溯
- evidence_section:
  - IAD frontmatter `related_sources: ["[[jenny-wen-ai-design-philosophy]]", "[[harness-engineering-deep-eval]]"]` ✅ direct
  - IAD `## 图谱关系`（line 167）`derived_from` strong ← Jenny
  - IAD 正文每节标 Jenny source `§3 / §3.2 / §3.3 / §9 / §5.1 / §5.2 / §12` 等具体章节
- answer_quality: **yes** — direct + 完整证据节追溯
- missing_context: none
- next_action: none

### Q8（补充题，图谱导航）：source 页和 concept/design 页之间是否有可解释关系？

- query: 7 active 之间双向关系健康度
- evidence_section: 7 active 全 frontmatter `related_*` 字段
- answer_quality: **yes**
  - karpathy ↔ concept-LLM ✅（双向 evidenced_by medium）
  - harness-NLM ↔ concept-HE ✅（双向 evidenced_by strong）
  - harness-NLM ↔ concept-CE ✅（双向 evidenced_by medium / part_of strong）
  - harness-NLM ↔ design-IAD ✅（双向 applies_to medium）
  - jenny ↔ design-IAD ✅（双向 derived_from strong）
  - karpathy ↔ harness-NLM：harness `related_sources: [karpathy]`，karpathy 未反向（builds_on weak，HE 报告未直接引 Karpathy）
  - jenny ↔ harness-NLM ✅（双向 related_sources）
  - 关系类型清晰：`evidenced_by` / `derived_from` / `applies_to` / `extends` / `part_of` / `builds_on`
- missing_context: karpathy 未列 harness 反向（语义上合理：karpathy 2023 talk 早于 HE 2026 报告）
- next_action: none

### 查询矩阵汇总

| Query | 类别 | 答题质量 |
|---|---|---|
| Q1 LLM mental model + agent/tool/memory | 用户题 | partial |
| Q2 HE/CE 边界 + Claude Code/MCP/agent | 用户题 | partial |
| Q3 IAD + AI 工具/设计系统/Figma Code Connect | 用户题 | partial |
| Q4 设计 agent harness 阅读路径 | Claude/Codex 工作 | yes |
| Q5 Claude Code/Codex 上下文清单 | Claude/Codex 工作 | yes |
| Q6 LLM → HE / CE 图谱跳转 | 图谱导航 | partial |
| Q7 IAD → Jenny source 追溯 | 图谱导航 | yes |
| Q8 source ↔ concept/design 双向关系 | 图谱导航 | yes |

**4 yes + 4 partial + 0 no**。所有 partial 都对应可识别的 backlog 项；无 yes/no 二极分布异常。

---

## §4. Obsidian 阅读体验验收

| 检查项 | 状态 | 说明 |
|---|---|---|
| 阅读视图第一屏可见 H1 + TLDR + 正文开头 | `pending_user_visual_check` | 用户未提供截图；fm 17-23 行已收紧到合理范围（前序 Codex APPROVED） |
| Properties 不变成长篇正文容器 | `pending_user_visual_check` | core_summary 黑名单已禁用；future_questions 已迁正文 |
| TLDR 30 秒内可理解 | `pending_user_visual_check` | 静态阅读 7 篇 TLDR 段落均一句话定位 + 一句话证据来源；用户在 Obsidian 阅读视图最终判定 |
| 入选理由短而明确 | `pending_user_visual_check` | 每篇 3 重理由结构一致 |
| 证据地图可追溯来源 | static-pass | 7 篇均含 `## 证据地图`，逐节标注 source 章节 |
| 核心论点 / 论证有人读价值 | `pending_user_visual_check` | 静态结构合规；阅读体验需用户判定 |
| 维护记录不干扰正文 | static-pass | 全部位于正文末节 `## 维护记录` |

**注**：用户已声明会抽 1-2 篇 active 在 Obsidian 阅读视图确认。如未提供截图，本节保持 `pending_user_visual_check`，不假装通过。

---

## §5. Index 导航验收（只读）

| Index 文件 | 7 active 覆盖 | 索引行质量 | 入口可用性 |
|---|---|---|---|
| `wiki/sources/00-Index.md` | karpathy / harness-NLM / jenny 各 1 处 ✅ | 每行含一句人读摘要（含时间锚 / 来源类型 / 关键概念）✅ | 可作 Claude/Codex 入口 ✅ |
| `wiki/concepts/00-Index.md` | concept-LLM / concept-HE / concept-CE 各 1 处 ✅ | 每行含 graph_role 标识 + 一句人读摘要 ✅ | 可作入口 ✅ |
| `wiki/designs/00-Index.md` | implementation-aware-design 1 处 ✅ | 索引行含一句人读摘要 + 拆出来源说明 ✅ | 可作入口 ✅ |

无混入 staging / raw / archive 内容。3 个 index 的分组规则（`source_type` / 领域+graph_role / `design_subtype`）清晰。

---

## §6. Graph Context 验收（只读）

| 节点 | 关系健康度 | 判断 |
|---|---|---|
| karpathy → concept-LLM | bridging（单跳）| `orphan_risk`（自标）— 可用但弱 |
| harness-NLM → concept-HE / concept-CE / IAD | 多跳 + 三方关联 | `healthy` |
| jenny → IAD → harness-NLM | 设计主线双跳完整 | `healthy` |
| concept-LLM 上游 | 仅 karpathy 1 source | `orphan_risk` — 待 transcript 升级 |
| concept-HE 上游 + 下游 | NLM 35 源 + CE/IAD/LLM 关联 | `healthy` |
| concept-CE 上游 | 仅 NLM §一.2 表 CE 列对照项 | `orphan_risk`（自标）— 待 CE 主题 source |
| IAD 上游 | Jenny source + NLM 报告双源 | `healthy` |

**未发现 missing_context 类节点**（即"不能支撑查询，需立即修"）。

3 个 `orphan_risk` 自标都对应可识别的 source 入库需求，已进 backlog。本轮**不新增概念页 / 不修改 wikilink / 不写 pending manifest**。

---

## §7. Backlog（按 P0/P1/P2/P3）

### P0（阻塞 — 必须立即修）

无。

### P1（高优先级 — 影响 Claude/Codex 实际查询能力）

| ID | 问题 | 来源 query | 建议动作 |
|---|---|---|---|
| BL-C1-001 | karpathy transcript 未入库，LLM concept 仅标签级，agent / tool use / memory 关系无法深度追溯 | Q1 | 入库 karpathy 完整 transcript → 升级 karpathy source `evidence_provenance` 到 `source_grounded` → 升级 concept-LLM evidence 到 strong |
| BL-C1-002 | `concept-mcp-tool-use` 缺失，HE 7 大组件第 1 条 MCP 应用无概念页可跳 | Q2 | 入库 concept-mcp-tool-use 概念页（独立 source 优先：MCP 协议 spec 或 Anthropic MCP docs） |
| BL-C1-003 | CE concept 仅 cluster_center 对照锚，专门 CE 主题 source 缺失 | Q2 / 自标 | 入库 CE 主题 source（LangChain/LlamaIndex 工具评估 / Lewis et al. RAG paper / chunking 实证 paper） |

### P2（中优先级 — 影响完整性，不影响基础可用）

| ID | 问题 | 来源 query | 建议动作 |
|---|---|---|---|
| BL-C1-004 | `entity-claude-code` 缺失，Q2 应用部分仅能给 NLM 报告 §四.1 横评定性 | Q2 / Q4 | 入库 Claude Code entity 页（功能 / 配置 / Skills / hooks 等） |
| BL-C1-005 | `concept-design-tokens-governance` / `concept-claude-cowork` 缺失，IAD Q3 工作流细节无法展开 | Q3 | 入库 design tokens / Code Connect 类工具 source；建立 governance concept 页 |
| BL-C1-006 | `entity-anthropic` / `entity-openai` / `entity-stripe` / `entity-semaclaw` 等 NLM 高频引用主体缺 entity 页 | Q5 | 按引用频次入库 entity 页 |
| BL-C1-007 | LLM concept 上游单源（仅 karpathy walkthrough）`orphan_risk` 状态需扩 source | Q1 / 自标 | 入库 RLHF paper / scaling laws paper / multimodal paper 等扩 LLM evidence 桥接 |

### P3（低优先级 / 可选 — 不影响验收）

| ID | 问题 | 来源 query | 建议动作 |
|---|---|---|---|
| BL-C1-008 | LLM concept frontmatter `related_concepts` 未直链 CE，Q6 需 2 跳 | Q6 | 可选：在 LLM frontmatter 加 `[[concept-context-engineering]]`；语义上 CE 是 HE 的 part_of，2 跳合理，不一定需修 |

### Backlog 处置原则

- 本轮**不修任何 backlog 项**
- 所有 backlog 项的执行需独立 plan + 独立 review
- backlog 由后续 C2 阶段或新 source 入库 trigger 驱动

---

## §8. C2 准备清单（前瞻，不在本轮范围）

C1 通过后，C2 可启动以下方向（择一执行，需独立 plan）：

1. **Query 路线**：基于本批 4 partial query 的 missing_context，按 P1 优先级入库 karpathy transcript / `concept-mcp-tool-use` / 专门 CE source
2. **Graph 路线**：扩 entity 类页降低 3 个 `orphan_risk`（concept-LLM / concept-CE）
3. **Lint 路线**：实现 `pending-graph-nodes-2026-05-05.jsonl` 的 LINT P1 检查 + frontmatter schema 校验工具

C2 选择由用户决定；本报告不做推荐排序，避免越界扩范围。

---

## §9. 不变量验收

| 检查项 | 状态 | 证据 |
|---|---|---|
| 7 篇 active 正文未改 | pass | 仅修正 phase-c report 一处标题 |
| 3 个 `00-Index.md` 未改 | pass | 仅读取，未 Edit/Write |
| `manifests/ingest/2026-05-05-active-rewrite.jsonl` 未改 | pass | 7 行未变 |
| `archive/active-pre-rewrite-2026-05-05/` 未改 | pass | 7 个 .md 未动 |
| `toolbox/` 未改 | pass | 本轮无 toolbox 操作 |
| 旧 AKB / Project AKB 未改 | pass | 本轮未触及 |
| Obsidian / iCloud 配置未改 | pass | 本轮未触及 |

---

## §10. Review 结论

verdict: **PASS_WITH_BACKLOG**

理由：
- 本轮验收范围严格遵守 C1 计划（只修一处标题 + 新增本报告，0 越界修改）
- 7 active 在结构合规之上证明可被人和 Claude/Codex 实际使用（4 yes / 4 partial / 0 no）
- 所有 partial / orphan_risk 都对应明确 backlog，未掩盖
- Obsidian 阅读体验项保持 `pending_user_visual_check`，不假装通过

下一步：
- 用户在 Obsidian 抽查阅读视图后，本报告 `pending_user_visual_check` 项可由用户更新为 `user-confirmed` 或反馈具体问题进 backlog
- C2 阶段由用户在 P1/P2/lint/graph 中择一开新 plan

---

## §11. 维护记录

| 日期 | 改动 | 作者 |
|---|---|---|
| 2026-05-06 | 初始本 C1 可用性验收报告（承接 plan：AKB2.0 Phase C1 Active 可用性验收与冻结收口）；同步修正 `active-page-constitution-rewrite-validation-2026-05-06.md` §2 标题"7 必备节"→"9 必备节" | praise + Claude Code |
