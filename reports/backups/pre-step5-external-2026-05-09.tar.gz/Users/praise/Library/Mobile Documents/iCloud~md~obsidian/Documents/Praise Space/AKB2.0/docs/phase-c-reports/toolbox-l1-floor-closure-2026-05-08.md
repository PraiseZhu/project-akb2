---
title: Toolbox L1 Floor Closure — 2026-05-08
phase: P1e
date: 2026-05-08
type: phase-c-report
status: closed
artifacts:
  - ai-infra/akb2-toolbox-closure/2026-05-08-p1e-delta/delta-manifest.json
  - ai-infra/akb2-toolbox-closure/2026-05-08-p1e-delta/effective-manifest.json
  - ai-infra/akb2-toolbox-evals/p1e-cc-akb-search-a4/
  - ai-infra/akb2-toolbox-evals/p1e-cc-akb-search-review2/
  - ai-infra/akb2-toolbox-evals/p1e-cc-akb-search-c5/
  - ai-infra/akb2-toolbox-matrix/v0/outputs/global-matrix.json
based_on_baseline:
  primary: ai-infra/akb2-toolbox-closure/2026-05-07/closure-manifest.json
  primary_sha256: 0fbd53703ff58802299ba8cb04f5290e4b973c124729376dc341f862f06f90cc
  primary_unchanged_after_closure: true
---

# Toolbox L1 Floor Closure — 2026-05-08

## TLDR

5 个核心工具全部进入 active 状态，eval_level ≥ L1，automation_allowed 全 false。`cc-akb-search` 通过 P1e（A4 5/5 + Review 2 三轮 APPROVED + C-5 verdict `accept_active_L1`）从 candidate/L0 升至 active/L1。primary closure 2026-05-07 保持只读，本次仅以 delta + effective manifest 派生当前状态。

## 5 工具最终状态

| slug | toolbox_status | wiki_status | eval_level | automation_allowed | last_phase |
|------|----------------|-------------|------------|--------------------|------------|
| cc-executable-plan | active | active | L2 | false | P1b-L2-regression-2026-05-06 |
| cc-review | active | active | L2 | false | P1b-L2-regression-2026-05-06 |
| cc-local-llm | active | active | L1 | false | P1c-full-sequence-2026-05-07 |
| cc-skill-stocktake | active | active | L1 | false | P1d-v3-full-sequence-2026-05-07 |
| **cc-akb-search** | **active**(↑) | active | **L1**(↑) | false | **P1e-2026-05-08** |

来源:`ai-infra/akb2-toolbox-matrix/v0/outputs/global-matrix.md`(2026-05-08T11:10:05Z 收集)

## P1e cc-akb-search 升级证据链

### A4 L1 eval(2026-05-08T10:55:26Z)

5 fixture 全部 pass:

| F | category | query | limit | total | verdict |
|---|----------|-------|-------|-------|---------|
| F1 | exact_keyword | LangGraph | 5 | 3 | pass |
| F2 | fuzzy_keyword | agent harness evaluation | 5 | 4 | pass |
| F3 | chinese_query | 智能体评测 | 5 | 0 | pass(graceful, FTS5 unicode61 expected) |
| F4 | no_result | xyz_nonexistent_term_2026_qwerty | 5 | 0 | pass |
| F5 | limit_behavior | MCP protocol | 2 | 2 | pass |

evidence pack:`ai-infra/akb2-toolbox-evals/p1e-cc-akb-search-a4/`

### Review 2(ai_infra readonly contract)

3 轮 code-reviewer subagent 审查,从 REQUIRES_CHANGES 收敛至 APPROVED:

| 轮次 | verdict | 关键 finding |
|------|---------|-------------|
| Round 1 | REQUIRES_CHANGES | P1: `Curator.__init__` 用 `or` 默认值绕过 `cache=None`; P2a: ToolboxDB WAL pragma 在只读路径执行 |
| Round 2 | REQUIRES_CHANGES | HIGH: `run_full_curation` 缺 `self.cache.purge_expired()` None guard |
| Round 3 | APPROVED | 0 P1/P2 finding;3 层独立护栏验证(SQLite mode=ro + router=None + cache=None) |

evidence:`ai-infra/akb2-toolbox-evals/p1e-cc-akb-search-review2/`

**Review 2 通道 limitation**:本轮采用 code-reviewer subagent(sonnet),非 canonical Codex Watch `/review code` 通道。后续若改 runner/collector/MCP wrapper/正式五件套逻辑,必须补跑 canonical review。

### C-5 Tool Intake Gate

verdict:`accept_active_L1`

evidence:
- `c5-verdict.json`(verdict + evidence_paths)
- `c5-mcp-call-2026-05-08.json`(`mcp__akb-search("agent evaluation framework", limit=3)` 实时调用冻结)

### 代码侧 P1/P2 修复(Project AKB)

5 文件修改用于满足 readonly contract:

| 文件 | 改动 |
|------|------|
| `scripts/core/search.py` | `cache=None when router is None`;`_search_toolbox` 加存在性检查 + `skip_init=True` |
| `scripts/pipeline/curator.py` | `self.cache = cache`(移除 `or KnowledgeCache()`);3 处 `is not None` 守卫 |
| `scripts/utils/db.py` | `CatalogDB` 加 `readonly=False`;`connect()` 分支 `file:path?mode=ro` URI |
| `scripts/toolbox/db.py` | `ToolboxDB` 加 `skip_init=False`;`connect()` 分支 `file:path?mode=ro` URI |
| `Codex/plugins/.../akb-search-readonly/server.py` | `CatalogDB(readonly=True)` |

完整 diff 见 Review 2 transcript。

## Delta closure 设计

### 决策:不修改 primary,只补 delta

primary `2026-05-07/closure-manifest.json` 保持只读。新建 `2026-05-08-p1e-delta/`,包含:

- `delta-manifest.json` — 仅记 `cc-akb-search` 增量(from/to/evidence/review/sha256)
- `merge-baselines.sh` — 派生 effective manifest 的合并脚本
- `effective-manifest.json` — 当前状态视图(派生,**非 source of truth**)
- `effective-manifest-summary.md` — 人读摘要

> **注（v5 修正，2026-05-08）**: `effective-manifest.json` 是派生视图。本次 v5 修正后顶层 `a1_mcp_discovery` 已由 delta 的 `a1_mcp_discovery_update` 字段透传为 `mounted`；`pending_next_phases.phase_3_cc_akb_search_unblock` 标记为 `complete`。primary closure 不变（SHA `0fbd5370...`）。

### 合并语义(merge-baselines.sh)

- delta-wins 字段白名单:`toolbox_status`,`wiki_status`,`eval_level`,`backlink_status`,`block_reason`,`last_phase`,`skill_sha256`
- 其他 4 工具从 primary 原样继承
- **automation_allowed invariant**:任何 `automation_allowed=true` → exit 1
- 5 工具数量校验失败 → exit 4
- 修改非 `tools_changed[]` 工具 → exit 2

### 不改 collect-global-matrix.sh

runner 仍读 `$AKB_ROOT/toolbox/{interfaces,tools,evals,registry}/$slug.md` + `wiki/tools/$slug.md` 直接收集状态。delta 只通过 canonical AKB2.0 文件状态变化间接生效。

## SHA256 漂移说明

`wiki/tools/cc-akb-search.md` SHA 在 2026-05-07 baseline 后被 Phase D BL-C3-001 修改(status 提前升 active)。本 P1e delta 不修改 wiki 文件,但在 `delta-manifest.json` 的 `five_file_sha256.before/after` 中记录了 `before: 811051b4...` → `after: 35f0340a...` 漂移,以便审计追溯。

primary closure 文件本身 sha256 `0fbd5370...` 在本流程开始与结束完全一致。

## L1 floor 定义(回顾)

L1 floor 接受门槛(P1e 已满足):

- ✅ 5 fixture 全部 pass(覆盖 exact/fuzzy/Chinese/no-result/limit)
- ✅ 工具返回 valid JSON for all input
- ✅ 工具不在中文/Unicode 输入下崩溃
- ✅ 工具尊重 limit 参数
- ✅ 0 DB 写入(SQLite mode=ro 引擎级护栏)
- ✅ 0 文件写入
- ✅ 0 网络调用(router=None)
- ✅ 响应 < 5s
- ✅ ai_infra readonly contract review APPROVED

## 后续 plan(独立 plan,本次不实施)

| Plan | 范围 | 触发条件 |
|------|------|---------|
| L2 regression v1 | cc-local-llm + cc-skill-stocktake 第一批,8-12 fixture/工具,assert-only | 本计划合并完成后 |
| Automation gate v0 | 设计 L2 pass + rollback target + dry-run + human approval + audit log + failure stop 门槛 | L2 v1 至少 1 工具通过后 |
| Search quality v0 | cc-akb-search 第二批 L2(观察 7 天后);query set 来源(用户日志 vs 人工)+ ranking baseline + rollback path | cc-akb-search 观察期满后 |

占位 README:
- `ai-infra/akb2-toolbox-evals/l2-regression-v1/README.md`
- `ai-infra/akb2-toolbox-automation-gate/v0/README.md`
- `ai-infra/akb2-toolbox-search-quality/v0/README.md`

## 验收(closure complete)

- [x] 5 工具均 active,eval_level ≥ L1
- [x] cc-executable-plan/cc-review 保持 L2
- [x] automation true count = 0(全局 grep 验证)
- [x] primary closure SHA256 与本流程开始时一致
- [x] effective manifest 由 merge-baselines.sh 派生,非手写
- [x] global matrix runner 输出新 5 工具状态(exit 0)
- [x] 3 个后续 plan 占位 README 落地

## 链接

- Primary closure(只读基线):`../../ai-infra/akb2-toolbox-closure/2026-05-07/closure-manifest.json`
- Delta:`../../ai-infra/akb2-toolbox-closure/2026-05-08-p1e-delta/`
- Global matrix outputs:`../../ai-infra/akb2-toolbox-matrix/v0/outputs/`
- 升级路径(cc-akb-search):[[../../toolbox/evals/cc-akb-search]] 升级历史
- 计划与执行证据（以 artifact 为准，velvety 引用已废止 — velvety 现归属 Automation Gate v0）:
  - A4 evidence: `../../ai-infra/akb2-toolbox-evals/p1e-cc-akb-search-a4/run-evidence.md`
  - A4 fixture results: `../../ai-infra/akb2-toolbox-evals/p1e-cc-akb-search-a4/fixture-results.json`
  - C-5 verdict: `../../ai-infra/akb2-toolbox-evals/p1e-cc-akb-search-c5/c5-verdict.json`
  - Delta manifest: `../../ai-infra/akb2-toolbox-closure/2026-05-08-p1e-delta/delta-manifest.json`
  - Effective manifest: `../../ai-infra/akb2-toolbox-closure/2026-05-08-p1e-delta/effective-manifest.json` (派生视图)
