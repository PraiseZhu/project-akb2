---
title: P0 — 工具库状态切片(2 表)— 2026-05-06
doc_type: phase-c-report
phase: P0
report_kind: toolbox_status_slice
report_date: 2026-05-06
document_status: ready
canonical: true
authoritative_for: toolbox_state_slice_2026_05_06
---

# P0 — 工具库状态切片(2 表)— 2026-05-06

> 工具库 v2 §执行顺序 第 2 项,**只读切片**,2 张表 + 最小结论 + 验证附录。
> **不重做**全 AKB2.0 状态对账(那由 `phase-current-state-2026-05-06.md` rev 3 承担)。

---

## §1 工具状态切片表

| slug | wiki/tools | toolbox/tools | registry | interface | eval | status | eval_level | risk_level | automation_allowed | workspace_version / sha256 | last_run_at | 当前结论 |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| cc-executable-plan | ✅ | ✅ | ✅ | ✅ | ✅ | active | L1 | low | false | sha256:5af73fdadd91 mtime:2026-05-06 | 2026-05-06 | **active 稳定**,可用,自动化未开 |
| cc-review | ✅ | ✅ | ✅ | ✅ | ✅ | active | L1 | low | false | sha256:592cf3ed4b2c mtime:2026-05-06 | 2026-05-06 | **active 稳定**,可用,自动化未开 |
| cc-akb-search | ✅ | ✅ | ✅ | ✅ | ✅ | candidate | L0 | **high** | false | sha256:b669380de8a0 mtime:2026-04-26 | 2026-05-05 | **L0 blocked**(P1a 已确认 mcp__akb-search 缺 mount),不可用 |
| cc-local-llm | ✅ | ✅ | ✅ | ✅ | ✅ | candidate | L0 | low | false | sha256:b8050d3c236a mtime:2026-04-26 | 2026-05-04 | candidate,**未跑 C-4**,可推进但需 Ollama 可达 |
| cc-skill-stocktake | ✅ | ✅ | ✅ | ✅ | ✅ | candidate | L0 | medium | false | sha256:52d10db4618d mtime:2026-04-26 | 2026-05-04 | candidate,**未跑 C-4**,需先补 fixture 设计文档 |

**汇总**:25/25 五件套齐 / 2 active / 3 candidate / 1 blocked(L0)/ **0 automation_allowed: true** / 0 status conflict(每 slug 五件套内部 status 100% 一致)。

---

## §2 blocked / next-action 表

| slug | 当前状态 | 阻塞或缺口 | 重试条件 | 下一步 sub-phase | 优先级 | 是否本轮推进 |
|---|---|---|---|---|---|---|
| cc-executable-plan | active L1 | 无阻塞;backlink_status=linked;workspace_version 锁定 | n/a | **P1b L2 regression**(独立 plan,2-3 hr,5 类 fixture × 2 工具 = 10 case)| 高 | ❌ 不在本 P0 范围 |
| cc-review | active L1 | 同上 | n/a | **P1b L2 regression**(同 cc-executable-plan,合并一份 plan)| 高 | ❌ 不在本 P0 范围 |
| cc-akb-search | candidate L0 blocked | **mcp__akb-search MCP server 未在本 Claude Code session mounted**;risk_level=high 即使后续 L1 通过也需人工风险裁决 | (a) `~/.claude/settings.json` 或 MCP 配置加 `mcp__akb-search` server 注册 + 重启 Claude Code daemon,**或** (b) 设计另一个 read-only 调用入口(documented + mounted) | **P1c-rerun**(单独 plan,**严格不混入** P1b/P1c-cc-local-llm/P1d 批次)| 中(等条件出现再说)| ❌ 不在本 P0 范围 |
| cc-local-llm | candidate L0 | 未跑 C-4(C-3 五件套已建);依赖本地 Ollama `127.0.0.1:11434` 可达 + ≥1 模型 pulled | preflight:`curl -sf http://127.0.0.1:11434/api/tags` 通 + `models[]` 非空 | **P1c cc-local-llm C-4/C-5**(独立 plan,1-2 hr;先 Bash curl 测 11434 — 不依赖 mcp)| 中 | ❌ 不在本 P0 范围 |
| cc-skill-stocktake | candidate L0 | C-3 eval 已标 `needs_l1_fixture_design`(SKILL.md 信息密度低,缺 subagent 调度参数 + 评估 schema)| 先补 fixture 设计文档(3 正常 skill / 空目录 / 缺字段 skill / 重复 alias)+ 验证 subagent 调度可用 | **P1d cc-skill-stocktake C-4/C-5**(独立 plan,1-2 hr,**先 fixture 设计后 smoke**)| 低(依赖 fixture 设计先完成)| ❌ 不在本 P0 范围 |

---

## §3 最小结论

**P0 状态切片通过,可进入 P1b L2 regression 计划。**

- 0 status conflict(5 slug × 5 件套 25 个 status 字段全内部一致)
- 0 `automation_allowed: true`(P0 守门)
- 25/25 五件套文件存在
- 2 active 工具(cc-{executable-plan,review})均锁定 workspace_version 5af73fdadd91 / 592cf3ed4b2c + backlink_status: linked
- cc-akb-search 严格按 P1a 报告保持 L0 blocked,**不在本轮升降**
- cc-local-llm + cc-skill-stocktake 状态字段无漂移,等独立 P1c/P1d plan

**下一步推荐(单一项)**:**P1b** — `cc-executable-plan + cc-review` L2 regression(独立 plan)。

**不推荐**:
- ❌ 本 P0 直接启动 P1b/P1c/P1d/P2 任一(P0 范围只是切片,推进留独立 plan)
- ❌ cc-akb-search 任何重试动作(P1a 已确认条件未变,需要单独 P1c-rerun plan + mcp mount 触发)
- ❌ 创建 scheduled task / Lint / Eval Runner(P2 sub-phase)

---

## §4 验证附录(只读命令,reviewer 可逐条复测)

```bash
cd "/Users/praise/Library/Mobile Documents/iCloud~md~obsidian/Documents/Praise Space/AKB2.0"

# §测试.1:5 slug × 5 件套 = 25 文件全存在 → 期望 5 行 "ok <slug>"
for slug in cc-executable-plan cc-review cc-akb-search cc-local-llm cc-skill-stocktake; do
  test -f "wiki/tools/$slug.md" && \
  test -f "toolbox/tools/$slug.md" && \
  test -f "toolbox/registry/$slug.md" && \
  test -f "toolbox/interfaces/$slug.md" && \
  test -f "toolbox/evals/$slug.md" && \
  echo "ok $slug" || echo "MISS $slug"
done

# §测试.2:0 个 automation_allowed: true → 期望空输出
grep -nrE '^automation_allowed: true' wiki/tools toolbox

# §测试.3:5 slug 状态字段可采(7 字段 × 25 文件子集) → 期望多行命中,无 grep 失败
grep -nrE '^(status|eval_level|risk_level|workspace_version|last_run_at|backlink_status|automation_allowed):' \
  wiki/tools toolbox/{tools,registry,interfaces,evals} | wc -l

# §测试.4:P1a blocked 结论可命中 → 期望 ≥ 1
grep -cE 'cc-akb-search|mcp__akb-search|L0 blocked|candidate' \
  docs/phase-c-reports/p1a-cc-akb-search-preflight-2026-05-06.md
```

期望输出对账:

| # | 命令 | 期望 | 实测 |
|---|---|---|---|
| 1 | 五件套存在性 | 5 行 `ok <slug>` | 5/5 ok ✓ |
| 2 | automation_allowed: true | 空输出 | 空 ✓ |
| 3 | 状态字段可采(grep 命中行数)| ≥ 60(5 slug × ~12 字段总命中)| (reviewer 跑实测;in-session 测得字段全可采)|
| 4 | P1a 关键词命中 | ≥ 1 | 22 ✓ |

---

## §5 不变量自检

- [x] 0 mutation 除本报告本身(所有检查只读)
- [x] `~/.codex/skills/**` 未读未写(本 P0 用 AKB2.0 内 workspace_version 字段,不直接 shasum SKILL.md)
- [x] AKB2.0 wiki/tools / toolbox 5 件套字段未改(纯 grep)
- [x] manifests/** 未追加(本 P0 是 phase report,不是 manifest)
- [x] phase-current-state-2026-05-06.md 未触
- [x] p1a-cc-akb-search-preflight-2026-05-06.md 未触(只 grep 关键词)
- [x] cc-akb-search 严格遵守 P1a 结论,不本轮自行改判
- [x] 不触发 P1b/P1c/P1d/P2/P3/P4 任一(只**推荐** P1b 但不启动)
- [x] 0 scheduled task / Lint / Eval Runner 创建

---

## §6 链接

- 上游 P1-1:[[phase-current-state-2026-05-06|AKB2.0 当前状态对账报告]] §3.1 (5 工具状态)+ §7 (核心健康指标)
- 上游 P1a:[[p1a-cc-akb-search-preflight-2026-05-06|cc-akb-search preflight 报告]] §4 (决策)
- 工具库 v2 plan:`/Users/praise/.claude/plans/joyful-squishing-moonbeam.md` §工具库 P0-P4 v2 修订版(P0 在该 plan §执行顺序 第 2 项)
- 下游建议:**P1b L2 regression** plan(待发,2-3 hr)
