# Automation Gate v0 Phase-C Report

**日期**: 2026-05-08
**阶段**: Phase C — Automation Gate v0 (Dry-Run Mechanism)
**覆盖工具**: 全部 5 工具（cc-executable-plan、cc-review、cc-local-llm、cc-skill-stocktake、cc-akb-search）
**状态**: CLOSED（dry-run mechanism implemented，全工具均 blocked）
**Review 结果**: APPROVED（result-20260508T141327Z.md）

---

## 目标

在 L2 Regression v1 完成后（两工具 verdict=blocked），建立 Automation Gate v0 dry-run 机制：

- 固化 8 条 gate 条件（policy.json）
- 建立 gate 输出 JSON Schema（schema/gate-result.schema.json）
- 实现只读 runner（run-gate.sh）支持 3 种模式
- 5 类 fixture 覆盖所有 blocked 路径 + eligible 路径
- 验证当前真实状态的 dry-run 输出（global_verdict=blocked_l2_verdict_blocked）
- 修正 L2 regression v1 phase-c-report 中 3 处错误的 verdict 摘要

---

## 执行摘要

| 组件 | 状态 | 关键输出 |
|------|------|---------|
| policy.json（8 条件） | 完成 | 含 hard_fail、invariant SHA256、verdict_enum |
| gate-result.schema.json | 完成 | would_create_automation const=false |
| run-gate.sh（3 模式） | 完成 | self-test / dry-run-current / tool |
| fixtures（5 类） | 完成 | self-test 5/5 pass |
| 当前真实 dry-run | 完成 | global_verdict=blocked_l2_verdict_blocked, exit=1 |
| README.md | 完成 | 占位 → implemented |
| phase-c-report 修正 | 完成 | 3 处 verdict 摘要已修正 |

---

## Step 执行记录

### Step 1: baseline 快照与 invariant 预检

- 计算 5 工具 SKILL.md sha256，落 `baseline-snapshot.md`
- 验证 `automation_allowed: true` 全局 0 命中
- 验证 closure-manifest sha256 = `0fbd5370...`（不变）

### Step 2: policy.json + schema

- `policy.json`：8 条 gate 条件 + input_sources + invariants + global_verdict_enum（13 值）+ `dry_run_only: true`
- `schema/gate-result.schema.json`：全字段 JSON Schema，`would_create_automation` 为 const false

### Step 3: 5 类 fixtures 落盘

| fixture | 关键条件 | expected global_verdict |
|---------|---------|------------------------|
| positive | 所有条件满足 + approval 文件 | all_eligible |
| blocked-l1-floor | eval_level=L1 | blocked_l1_floor |
| blocked-l2-verdict-blocked | L2 但 verdict=blocked | blocked_l2_verdict_blocked |
| blocked-no-promotion-evidence | L2+recommend 但无 promo 目录 | blocked_no_promotion_evidence |
| hard-fail-automation-already-true | tool-card automation_allowed=true | hard_fail_automation_already_true |

### Step 4: run-gate.sh 实现

- 只读：禁止写除 outputs/ 外任何路径
- 输入：closure-manifest → eval_level/toolbox_status；l2-rec → verdict；tool-card frontmatter → auto_allowed/runtime_mut
- 全局 invariant 守护：grep automation_allowed=true count > 0 → exit 3
- L2-scan override：当所有工具 blocked 时，扫 L2_REG_BASE/*/recommendation.json，存在 verdict=blocked → global_verdict=blocked_l2_verdict_blocked

### Step 5: fixture self-test

```
Self-test: 5 passed, 0 failed; exit=0
```

### Step 6: current-state dry-run

```
global_verdict=blocked_l2_verdict_blocked; exit=1
invariants: automation_allowed_true_count=0, closure_manifest_sha256_match=true
```

per-tool:
- cc-executable-plan → blocked_no_l2_regression_evidence（L2 but no L2 evidence）
- cc-review → blocked_no_l2_regression_evidence（L2 but no L2 evidence）
- cc-local-llm → blocked_l1_floor（eval_level=L1）
- cc-skill-stocktake → blocked_l1_floor（eval_level=L1）
- cc-akb-search → blocked_l0_or_below（eval_level=L0）

### Step 7: README.md 更新

- 状态从"planning"更新为"implemented (dry-run mechanism only, 2026-05-08)"
- 新增机制概述、组件表格、CLI 用法、当前状态、8 条条件说明

### Step 8: phase-c-report 修正

`l2-regression-v1-2026-05-08.md` 3 处 verdict 摘要修正 + 1 条后续操作注：
- 执行摘要表格：`recommend_promote_L2` → `blocked (backend curl_exit=7)`
- Step 3 描述：同步修正
- Step 4 描述：同步修正
- 后续操作：新增"前置条件阻塞"说明

### Step 9: Review

- Canonical Codex Watch `/review code`
- **VERDICT: APPROVED**（result-20260508T141327Z.md）
- Findings: none
- Residual Risk: P3（不阻塞）

---

## 验证清单

| 项目 | 结论 |
|------|------|
| run-gate.sh --self-test exit=0, 5/5 pass | pass |
| run-gate.sh --dry-run-current exit=1, global_verdict=blocked_l2_verdict_blocked | pass |
| gate-result.json would_create_automation=false | pass |
| invariants.automation_allowed_true_count=0 | pass |
| invariants.closure_manifest_sha256_match=true | pass |
| automation_allowed=true 全局 0 命中（不变） | pass |
| closure-manifest.json sha256 不变（0fbd5370...） | pass |
| phase-c-report 3 处 verdict 摘要修正 | pass |
| README.md 从占位更新为 implemented | pass |
| canonical Codex Watch review APPROVED | pass |

---

## 后续操作

- **backend 修复 + L2 重跑**：cc-local-llm / cc-skill-stocktake 的 backend 恢复后，重跑 L2 regression v1，verdict 变为 recommend_promote_L2 后可继续 Promotion Gate v0。
- **cc-executable-plan / cc-review L2 regression**：两工具 eval_level=L2 但无 L2 evidence（grandfathered），需另开 L2 regression plan。
- **Promotion Gate v0 Plan**：precondition #1（L2 verdict=recommend_promote_L2）暂未满足，等 backend 恢复后执行。
- **cc-akb-search L2 推进**：另开计划。
- **Automation Gate v1 schema 升级**：等 Promotion Gate v0 出真实 schema 后升级 promotion_evidence 字段。

---

*由 Automation Gate v0 计划执行，review APPROVED 后自动生成本报告。*
