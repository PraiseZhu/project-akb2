---
dir: AKB2.0/manifests/lint
automation_boundary: §6.2 registered subdirectory
updated_at: 2026-05-08
lint_cli_versions: [v0.2, v0.3]
---

# AKB2.0 Manifests / Lint — 目录索引

## 用途

本目录存放 AKB2.0 工具库 lint 相关的**稳定 manifest**（rule definition / rule schema / rule index）。

- **稳定 manifest**：跨 lint run 不变的规则定义，落在这里
- **一次性 outputs / evidence**：落在 Codex evidence pack（`Codex/ai-infra/akb2-toolbox-lint/`）
- **content quality lint**（akb2-lint.py）的 JSONL 输出：也落这里（`*.jsonl` 文件）

## 当前文件

### P2 Toolbox Structure Lint v0（2026-05-07）

| 文件 | 类型 | 用途 |
|------|------|------|
| `toolbox-structure-rules-v0.md` | 人读 rule definition | 8 条结构合规规则含义 + handoff 边界 + cc-akb-search 例外 |
| `toolbox-structure-rules-v0.json` | 机读 rule schema | runner 引用；output schema；exceptions 段 |

### akb2-lint.py v0.2 (content quality lint) 输出

| 文件 | 类型 | 用途 |
|------|------|------|
| `*-v0-2.jsonl` | content lint JSONL 输出 | akb2-lint.py v0.2 每次运行的 finding（18 rules，wiki active 扫描） |
| `2026-05-08T011944-v0-2.jsonl` | **v0.2 clean baseline** | P0=0/P1=0/P2=0 — v2.1 Stage 1 清零后首次干净扫描 |

### akb2-lint.py v0.3（2026-05-08 新增，Census Week Phase D 产出）

| 规格 | 内容 |
|------|------|
| 实现文件 | `.akb-runtime/lint/akb2-lint.py`（单文件原地升级，含 v0.2 全量规则）|
| 触发方式 | `python3 akb2-lint.py --version v0.3` |
| 规则数 | 22 条（v0.2 × 18 + 新增 × 4）|
| 新增规则 | RAW-NO-WIKILINK(P2)、ACTIVE-SLUG-NO-DATE(P2)、DEPRECATED-SUPERSEDED-BY(P1)、WIKILINK-NO-RAW-PATH(P2) |
| 增强规则 | WIKI-TOOLS-TOOLBOX-PAIRING（R18）：新增正文 wikilink 检查 |
| 扫描范围 | wiki active 页（15）+ raw/ 文件（2）+ deprecated 页（0）|
| 输出路径 | `manifests/lint/*-v0-3.jsonl` + `docs/phase-d-reports/lint-cli-v0.3-*.md` |
| v0.2 兼容 | ✅ 默认行为不变；v0.3 须显式 `--version v0.3` |
| 官方 clean run | `2026-05-08T141034-v0-3.jsonl`（P0=0/P1=0/P2=0，主证据） |
| 调试 run（保留） | `2026-05-08T140811-v0-3.jsonl`（P0=0/P1=0/P2=0，中间调试 run，非主证据） |

## 两套 lint 边界说明

| 维度 | toolbox-structure-rules-v0（本目录）| akb2-lint.py（content lint）|
|------|-----------------------------------|-----------------------------|
| lint_kind | structure | content quality |
| 检查目标 | 5件套文件存在性 + frontmatter 字段值 | 5件套内容字段（BODY-MAINTENANCE-LOG 等）|
| 输出格式 | JSON（outputs/lint-current-5-tools.json）| JSONL（本目录 *.jsonl）|
| 运行方式 | Bash + jq + shasum | Python |
| Runner 路径 | Codex/ai-infra/akb2-toolbox-lint/p2-lint-v0/ | .akb-runtime/lint/akb2-lint.py |

两套 lint 正交，可并存，不冲突。

## 版本历史

| 版本 | 日期 | 产出 |
|------|------|------|
| toolbox-structure v0 | 2026-05-07 | 8 条结构规则，scope = 当前 5 工具 × 5件套 |
| akb2-lint v0.2 | 2026-05-08 | 18 条 content lint 规则，wiki active 扫描 |
| akb2-lint v0.3 | 2026-05-08 | +4 条规则（22 条），三范围扫描（active+raw+deprecated），Phase D 产出 |
