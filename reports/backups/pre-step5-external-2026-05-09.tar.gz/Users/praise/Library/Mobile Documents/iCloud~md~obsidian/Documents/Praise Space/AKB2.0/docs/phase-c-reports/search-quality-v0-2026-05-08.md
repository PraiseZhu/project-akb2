# Search Quality v0 Phase-C Report

**日期**: 2026-05-08
**阶段**: Phase C — cc-akb-search Search Quality Baseline v0
**覆盖工具**: cc-akb-search（L1 active）
**状态**: CLOSED（SQ-1 hard fail — blocked_insufficient_user_queries；runner 与审计正确可复现）
**Review 结果**: APPROVED（followup，result-20260508T153115Z.md）

---

## 目标

为 cc-akb-search（P1e 完成后 L1 active）建立只读搜索质量基线评估机制：

- 扫描 transcript 提取真实 user_observed query（source_type 分类可追溯）
- 建立双路径（MCP + CLI）baseline runner，前后 sha256 守护（只读合约）
- 7 项指标 + 量化阈值判定（recall@5 / zero_result_rate / chinese_pass_rate / latency_p95）
- 产出 recommendation.md（no_patch_required 或 patch_candidate_required）

---

## 执行摘要

| 阶段 | 状态 | 关键输出 |
|------|------|---------|
| SQ-0 Preflight（sha256 快照） | 完成 | baseline-snapshot.md（前后快照 PASS） |
| SQ-1 Query Source Audit | BLOCKED（hard fail） | query-source-audit.md；blocked_insufficient_user_queries.md |
| SQ-2/3/4 Baseline + Metrics + Recommendation | 未运行（SQ-1 阻断） | — |
| SQ-5 Review | APPROVED（followup） | result-20260508T153115Z.md |

---

## 阻塞原因

cc-akb-search 于 2026-05-08 P1e 完成后首次挂载 MCP server。在此之前 23 天（2026-04-16 至 2026-05-07）均处于 `not_mounted` 状态，无用户调用可积累。挂载首日 13 次调用全部为 A4 L1 Evaluation fixture 或 V2 connection 验证（eval_observed）。

```
n_user_observed = 0  (threshold ≥ 7) → hard fail exit 2
```

这是预期内的硬约束，不是评估逻辑 bug。

---

## 关键指标（不变量）

| 检查 | 结果 |
|------|------|
| automation_allowed=true 全局命中 | 0（PASS） |
| catalog.db sha256（前后比对） | 不变（2082e717...） |
| cc-akb-search status | active（不变） |
| cc-akb-search eval_level | L1（不变） |
| cc-akb-search automation_allowed | false（不变） |
| self-test 通过率 | 5/5 PASS |

---

## Review 状态

- **Initial review**（result-20260508T151411Z.md）：REQUIRES_CHANGES（2 × P2）
  - Finding 1: source_type 分类不可复现（全 session 扫描窗口缺失）
  - Finding 2: hard fail 路径缺少 catalog post-sha 守护
- **Followup review**（result-20260508T153115Z.md）：APPROVED
  - Finding 1 PASS：user=0, eval=13 与 query-source-audit.md 完全一致
  - Finding 2 PASS：输出含 `[SQ-1] catalog.db sha256 unchanged` 行

---

## 产出文件

| 文件 | 状态 |
|------|------|
| `run-search-quality.sh` | 完成（5 项修复，self-test 5/5 PASS） |
| `baseline-snapshot.md` | 完成（前后 sha256 填充） |
| `query-source-audit.md` | 完成（13 条全量审计） |
| `blocked_insufficient_user_queries.md` | 完成 |
| `run-evidence.md` | 完成（含 post-sha 输出行） |
| `queries.jsonl` | 未生成（SQ-1 hard fail 阻断） |
| `baseline-results.jsonl` | 未生成（SQ-2 阻断） |
| `metrics.json` | 未生成（SQ-3 阻断） |
| `recommendation.md` | 未生成（SQ-4 阻断） |

---

## 后续操作

推荐等到 `2026-05-15`（MCP 挂载后 7 天）重跑 SQ-1：

```bash
bash run-search-quality.sh --collect-queries
```

届时预计 user_observed ≈ 5–15 条（依日常使用频率）。若 n_user_observed ≥ 7 → 继续 SQ-2/3/4。

---

## 状态保持确认

- cc-akb-search `toolbox_status=active`，`eval_level=L1`（未升 L2）
- 其他 4 工具状态不变
- 无 runtime code 修改
- `automation_allowed` 全字段不变
