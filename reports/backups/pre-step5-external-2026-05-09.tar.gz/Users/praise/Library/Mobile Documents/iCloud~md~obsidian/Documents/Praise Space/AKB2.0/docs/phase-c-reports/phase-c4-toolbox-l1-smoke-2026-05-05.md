---
title: Phase C-4 工具库 L1 Smoke 报告
doc_type: phase-c-report
phase: C-4
report_kind: toolbox_l1_smoke
automation_layer: L1_smoke_evidence
not_active_promotion: true
report_date: 2026-05-05
runner: claude
runner_override_reason: "user approved Claude execution per C-4 真实 Runner 执行版 plan 选项 A; Codex runner 可后续补充复核"
slugs_in_round:
  - cc-executable-plan
  - cc-review
  - cc-akb-search
---

# Phase C-4 工具库 L1 Smoke 报告 — 2026-05-05

> 本报告记录 C-3 候选 5 件套中前 3 个工具的 L1 smoke 执行结果。**本轮 runner = Claude(用户 override),不是 Codex**。Codex runner 可后续补充复核。**所有产出仍为 candidate**,**0 工具升 active**,**0 自动化授权**。

---

## §1 执行总览

| slug | 阶段 | runner | assertion_status | eval_level (before → after) | 阻塞? |
|---|---|---|---|---|---|
| `cc-executable-plan` | C-4a | claude | **pass** | L0 → **L1** | 不阻塞 C-4 主线 |
| `cc-review` | C-4a | claude | **pass** | L0 → **L1** | 不阻塞 C-4 主线 |
| `cc-akb-search` | C-4b | claude | **blocked** | L0 → L0(保持) | **不阻塞** C-4 主线(C-4a 已收口) |

C-4a 两个核心工具 100% pass,C-4 主线**可以收口**。C-4b 因本 session 无 `mcp__akb-search` MCP 入口 BLOCKED,留待外部 session 补跑。

---

## §2 Runner 透明披露

| 项 | 值 |
|---|---|
| 实际 runner | Claude(本 Claude Code session) |
| 期望 runner(原 plan) | Codex |
| Override 来源 | 用户在 chat 中明确选项 A:"让 Claude 执行,但 evidence 如实标 runner: claude" |
| 后续 Codex 复跑路径 | 在有 Codex CLI session 的环境下,跑同 fixture/assertions 包,产同名 `run-evidence.md`(可附时间戳避免覆盖);对比 Claude evidence 的 sha256 与 assertion 验证一致 |

每份 `run-evidence.md` 显式写 `runner: claude` + `runner_override_reason`,manifest 同步显式 `executed_by: claude`。**没有任何字段伪装为 Codex**。

---

## §3 C-4a 详细结果

### §3.1 cc-executable-plan(L1 pass)

- **fixture**:`ai-infra/akb2-toolbox-evals/c4a/cc-executable-plan/fixture.md`(legacy-skill-importer.sh deprecated 迁移最小 plan)
- **evidence**:`ai-infra/akb2-toolbox-evals/c4a/cc-executable-plan/run-evidence.md`
- **output sha256**:`a34aa2aec6eb86c9c01dd0b9432066dec413e63e886498b0f5c26f531cd516ae`(200 行 plan 文档)
- **断言**:
  - A drift check `diff -q` exit 0 → pass
  - B 8/8 mandatory ## sections 命中 → pass
  - C `REVIEW_DOMAIN：app_code` + `REVIEW_FOCUS：` 5 维度 → pass(注:assertion C 用 ASCII colon `:` 但中文 plan 模板约定全角 `：`,raw output 用全角是正确的;assertion 文档级缺陷已记录)
  - D Markdown well-formed + 200 行 ≥ 200 阈值 + 路径命中(`legacy-skill-importer.sh` 15 次 + `skill-importer-v2.sh` 11 次) → pass

### §3.2 cc-review(L1 pass)

- **fixture**:`ai-infra/akb2-toolbox-evals/c4a/cc-review/`(positive + negative 双 fixture)
- **evidence**:`ai-infra/akb2-toolbox-evals/c4a/cc-review/run-evidence.md`
- **output sha256**:positive `c6a72923...`;negative `bf19f3d3...`
- **positive 断言**:single fenced markdown ✓ / `# 计划审查结果` ✓ / `结论:通过` ✓ / 0 P2 ✓ / 已检查范围 4 数据行 ≥ 3 ✓ / 路径未越界 ✓ → pass
- **negative 断言**:single fenced markdown ✓ / `# 代码审查结果` ✓ / `结论:需要修改` ✓ / 2 P2 finding ≥ 1 ✓ / 5 字段(问题/证据/影响/最小修复/验收)× 2 finding 全齐 ✓ / planted P2 命中($TARGET 未引号 / 空检查 / 缺 set -euo pipefail) ✓ → pass

---

## §4 C-4b 详细结果

### §4.1 cc-akb-search(L0 blocked)

- **fixture**:`ai-infra/akb2-toolbox-evals/c4b/cc-akb-search/`
- **evidence**:`ai-infra/akb2-toolbox-evals/c4b/cc-akb-search/run-evidence.md`
- **preflight 结果**:

| # | item | verdict |
|---|---|---|
| P1 | SKILL.md sha256 matches | pass(`b669380de8a0cd4319f0c978f4cfa69d2757b004a8569fc3adac8f633637f982`) |
| **P2** | **real read-only call entry available** | **BLOCKED**:本 Claude Code session 无 `mcp__akb-search` MCP server mount;无等价 read-only CLI |
| P3 | no write side effects | n/a(P2 blocked) |
| P4 | no external network/secret | n/a(P2 blocked) |
| P5 | no secret-shaped header | pass-with-note(grep 命中 SKILL.md SAFETY 区段说明文字 "Do not use or create secrets",不是实际 secret 值;assertion 模式过严) |

- **结论**:`assertion_status: blocked`、`eval_level_after: L0`、**未跑 query smoke**
- **enters_active_gate**:false(即使后续 preflight + L1 pass,risk:high 仍需人工风险裁决)

---

## §5 元数据同步(C-4b 顺带修)

C-3 时我把 cc-akb-search 评 `risk_level: medium`,与 SKILL.md 显式 `risk: high` 不符。本轮一并修正:

| 文件 | 字段 | 旧 | 新 |
|---|---|---|---|
| `toolbox/interfaces/cc-akb-search.md` | `risk_level:` | medium | **high** |
| `toolbox/tools/cc-akb-search.md` | `risk_level:` | medium | **high** |
| `toolbox/registry/cc-akb-search.md` | `risk_level:` | medium | **high** |
| `wiki/tools/cc-akb-search.md` | 风险段叙述 | "评 medium" | "对齐 SKILL.md high + 4 source flags" |

---

## §6 隔离自检

- **`.codex/skills` 3 个 SKILL.md sha256 前后完全一致** ✓
  - cc-executable-plan: `69364def87afa9ad88e66bf1b2285d0007ee245070b4ed8a6367496dc50357e8`
  - cc-review: `d6e7ce54dce6e76e87998c0d5fb419b43e83b303fec7c2f7bd01df05a214cbb3`
  - cc-akb-search: `b669380de8a0cd4319f0c978f4cfa69d2757b004a8569fc3adac8f633637f982`
- **AKB2.0 toolbox 无 `status: active`** ✓
- **AKB2.0 toolbox 无 `automation_allowed: true`** ✓
- **0 真实 AKB 数据被读 / 写 / 触发 synth / translate** ✓
- **0 外部网络调用 / 0 MCP / hook / plugin 启用** ✓
- **0 LaunchAgent / cron 改动** ✓

---

## §7 已发现的 fixture/assertions 文档级缺陷(留 backlog)

1. **assertion C colon 问题**:cc-executable-plan assertions.md 写 `REVIEW_DOMAIN:` 用 ASCII colon,但中文 plan 模板约定全角 `：`。raw output 用全角是正确的;assertion 模式应改成兼容 `[:：]`。
2. **assertion P5 secret 模式过严**:cc-akb-search preflight P5 grep 会命中 SKILL.md SAFETY 区段的 "secrets" 说明文字。assertion 应只匹配真实 secret 值前缀(`sk-` / `ghp_` / `AKIA` 等),而不是任何含 "secret" / "token" 的说明文字。
3. **assertion D 200 行下界紧贴**:cc-executable-plan plan output 刚好 200 行;若以后改 fixture 输入或我换写法可能 198-199 行。建议放到 ≥ 180 行让阈值有缓冲。

不在本轮修;留作 fixture maintenance backlog。

---

## §8 C-5 建议(下一步)

| slug | C-5 路径 |
|---|---|
| `cc-executable-plan` | L1 pass,可由 reviewer 评估是否进 Tool Intake Gate active 决策(单独 plan);本轮**不**自动推 |
| `cc-review` | 同上 |
| `cc-akb-search` | 在有 `mcp__akb-search` 的 Codex session 重跑 preflight + query smoke;即使 L1 pass,risk:high 需人工风险裁决才能进 active |

进入 active gate 之前需要单独评估的项:
- backlink_status 是否注入 workspace SKILL.md(C-3 时全部 pending)
- L2 regression(本轮只有 L1 smoke)
- automation_allowed 升 true 的边界(本轮硬约束 false)

---

## §9 链接

- C-3 上游报告:[[phase-c3-toolbox-pilot-candidate-build-2026-05-04|Phase C-3 报告]]
- C-4 manifest:[[../../manifests/toolbox-c4/2026-05-05-c4-l1-smoke-results|2026-05-05-c4-l1-smoke-results.jsonl]]
- 3 份 evidence(Codex workspace):
  - `ai-infra/akb2-toolbox-evals/c4a/cc-executable-plan/run-evidence.md`
  - `ai-infra/akb2-toolbox-evals/c4a/cc-review/run-evidence.md`
  - `ai-infra/akb2-toolbox-evals/c4b/cc-akb-search/run-evidence.md`
- 3 份 eval(已写回):
  - [[../../toolbox/evals/cc-executable-plan|cc-executable-plan eval (L1)]]
  - [[../../toolbox/evals/cc-review|cc-review eval (L1)]]
  - [[../../toolbox/evals/cc-akb-search|cc-akb-search eval (L0 blocked)]]
