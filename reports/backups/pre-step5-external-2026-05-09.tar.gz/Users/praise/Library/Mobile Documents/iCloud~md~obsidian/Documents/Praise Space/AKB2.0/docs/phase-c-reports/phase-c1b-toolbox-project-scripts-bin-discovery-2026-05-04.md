---
title: Phase C-1b Toolbox Project Scripts/Bin Discovery — 2026-05-04
doc_type: phase-c-report
phase: C-1b
report_kind: project_scripts_bin_scan
automation_layer: L0_read_only
not_active_promotion: true
scan_id: akb2-toolbox-scan-697041a7a8df
scanned_at: 2026-05-04T11:49:34Z
report_date: 2026-05-04
---

# Phase C-1b Toolbox Project Scripts/Bin Discovery — 2026-05-04

> Read-only scanner output. Never executes a candidate, never writes outside `manifests/workspace-scan/` and `docs/phase-c-reports/`, never promotes anything to active.

## §1 Scan summary

- AKB root: `/Users/praise/Library/Mobile Documents/iCloud~md~obsidian/Documents/Praise Space/AKB2.0`
- JSONL manifest: `/Users/praise/Library/Mobile Documents/iCloud~md~obsidian/Documents/Praise Space/AKB2.0/manifests/workspace-scan/2026-05-04-toolbox-project-scripts-bin-scan.jsonl`
- Total candidates: **888**
- Roots scanned: 2

## §2 Root status

| root | kind | status | candidates | error |
|---|---|---|---|---|
| `/Users/praise/Library/Mobile Documents/com~apple~CloudDocs/Codex` | project | scanned | 3 |  |
| `/Users/praise/Library/Mobile Documents/com~apple~CloudDocs/Claude Code` | project | scanned | 885 |  |

## §3 Detected kind distribution

| detected_kind | count |
|---|---|
| project_tool_script | 484 |
| project_script | 331 |
| project_cli | 40 |
| project_bin | 33 |

## §4 Risk + side-effects hints

| risk_hint | count |
|---|---|
| low | 855 |
| medium | 33 |

| side_effects_hint | count |
|---|---|
| write_local | 888 |

## §5 Suspected high-risk / sensitive headers

- `tools/TikTokDownloader/src/config/parameter.py` — secret_in_header
- `tools/TikTokDownloader/src/testers/params.py` — secret_in_header
- `tools/TikTokDownloader/src/application/main_server.py` — secret_in_header
- `tools/TikTokDownloader/src/custom/function.py` — secret_in_header
- `tools/TikTokDownloader/src/encrypt/msToken.py` — secret_in_header
- `Project Open Design/tools/pack/resources/mac/notarize.cjs` — secret_in_header
- `bin/publish-wechat` — secret_in_header
- `bin/swap-key` — secret_in_header
- `web_test/scripts/export-figma-assets.js` — secret_in_header
- `gstack/bin/gstack-community-dashboard` — secret_in_header
- `Project CleanCC/backend/tools/PowerShellTool/commandSemantics.ts` — secret_in_header
- `Project CleanCC/backend/tools/SkillTool/prompt.ts` — secret_in_header
- `Project CleanCC/backend/tools/RemoteTriggerTool/RemoteTriggerTool.ts` — secret_in_header
- `Project CleanCC/backend/tools/BriefTool/upload.ts` — secret_in_header
- `Project CleanCC/backend/tools/BashTool/sedEditParser.ts` — secret_in_header
- `Project CleanCC/backend/cli/handlers/auth.ts` — secret_in_header
- `Project AKB/toolbox/repos/claude code/tools/PowerShellTool/commandSemantics.ts` — secret_in_header
- `Project AKB/toolbox/repos/claude code/tools/SkillTool/prompt.ts` — secret_in_header
- `Project AKB/toolbox/repos/claude code/tools/RemoteTriggerTool/RemoteTriggerTool.ts` — secret_in_header
- `Project AKB/toolbox/repos/claude code/tools/BriefTool/upload.ts` — secret_in_header
- `Project AKB/toolbox/repos/claude code/tools/BashTool/sedEditParser.ts` — secret_in_header
- `Project AKB/toolbox/repos/claude code/cli/remoteIO.ts` — secret_in_header
- `Project AKB/toolbox/repos/claude code/cli/handlers/auth.ts` — secret_in_header
- `Project AKB/scripts/pipeline/migrate_concepts_en.py` — secret_in_header
- `Project AKB/scripts/chat/server.py` — secret_in_header

## §6 Phase B sample coverage in workspace

- none

## §7 AKB 2.0 toolbox coverage gaps

- candidates without `toolbox/registry/<slug>.md`: 888
- candidates without `toolbox/interfaces/<slug>.md`: 888
- candidates without `toolbox/evals/<slug>.md`: 888

## §8 Next-batch Tool Gate suggestions (advisory only)

> Scanner does NOT decide gate outcomes. The list below highlights candidates that look like solid first picks for human review.

- none

## §10 Project scope: exclusion summary

- pruned subdirs (skipped at walk time): 160
- truncated roots (hit `--max-files-per-root`): 0

## §11 Project scope: detected kinds

| detected_kind | count |
|---|---|
| project_tool_script | 484 |
| project_script | 331 |
| project_cli | 40 |
| project_bin | 33 |

## §12 Project scope: by project

| project | candidates |
|---|---|
| `Claude Code` | 885 |
| `Codex` | 3 |

## §13 Project scope: duplicates of C-1

- previous manifest: `/Users/praise/Library/Mobile Documents/iCloud~md~obsidian/Documents/Praise Space/AKB2.0/manifests/workspace-scan/2026-05-04-toolbox-workspace-scan.jsonl`
- duplicate records: 0

## §14 C-2 readiness

- candidates available for ranking: **888** (non-duplicate)
- C-2 input: union(C-1 manifest, this manifest) keyed by `workspace_path`; use `duplicate_of_prior_scan` to skip second-counting.

## §9 Invariants self-check

- [x] every record carries `not_active: true`
- [x] every record carries `automation_allowed: false`
- [x] every record carries `gate_decision: null`
- [x] no candidate file was executed or imported
- [x] no symlink was followed (recorded only)
- [x] outputs land only in `manifests/workspace-scan/` and `docs/phase-c-reports/`
- [x] project scope obeys allowed subtrees (`scripts/` `bin/` `tools/` `cli/`)
- [x] walk-time prune list applied (no `.git`, `node_modules`, `.venv`, etc.)

