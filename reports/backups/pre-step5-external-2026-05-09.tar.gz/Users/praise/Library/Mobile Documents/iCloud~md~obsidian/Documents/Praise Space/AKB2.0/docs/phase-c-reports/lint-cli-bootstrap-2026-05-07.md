---
report_type: phase_d_lint_cli_run
report_id: lint-cli-bootstrap-2026-05-07
date: 2026-05-07
operation_id: akb2-lint-20260507T194120
tool: akb2-lint.py v0.1
scanned_count: 15
p1_count: 0
p2_count: 21
---

# AKB2.0 LINT CLI Bootstrap Run Report

## 摘要

- 工具：`akb2-lint.py` v0.1（Python stdlib，无依赖）
- 位置：`.akb-runtime/lint/akb2-lint.py`
- 规则：6 条（5 新 + 1 旧 BODY-QUALITY-MISSING-STRUCTURE alias-aware）
- 扫描页数：15
- P1 findings：**0**
- P2 findings：**21**

## 扫描清单

- ⚠️ 2 `wiki/concepts/context-engineering.md`
- ⚠️ 3 `wiki/concepts/harness-engineering.md`
- ⚠️ 2 `wiki/concepts/large-language-model.md`
- ⚠️ 1 `wiki/concepts/mcp-tool-use.md`
- ⚠️ 2 `wiki/designs/implementation-aware-design.md`
- ⚠️ 1 `wiki/sources/anthropic-effective-context-engineering.md`
- ⚠️ 5 `wiki/sources/harness-engineering-deep-eval.md`
- ⚠️ 2 `wiki/sources/jenny-wen-ai-design-philosophy.md`
- ⚠️ 2 `wiki/sources/karpathy-intro-to-llms.md`
- ⚠️ 1 `wiki/sources/mcp-spec.md`
- ✅ `wiki/tools/cc-akb-search.md`
- ✅ `wiki/tools/cc-executable-plan.md`
- ✅ `wiki/tools/cc-local-llm.md`
- ✅ `wiki/tools/cc-review.md`
- ✅ `wiki/tools/cc-skill-stocktake.md`

## P1 violations

**none** — 15 active 未被新规则打挂 ✅

## P2 violations

- **BODY-MAINTENANCE-LOG-VERBOSE** at `/Users/praise/Library/Mobile Documents/iCloud~md~obsidian/Documents/Praise Space/AKB2.0/wiki/concepts/context-engineering.md`
  - 维护记录 row 253 chars: | 2026-05-06 | v3 Active Page Constitution 重写（approved_plan:…
  - proposed_action: 拆分到 manifest record 或 changelog
- **BODY-MAINTENANCE-LOG-VERBOSE** at `/Users/praise/Library/Mobile Documents/iCloud~md~obsidian/Documents/Praise Space/AKB2.0/wiki/concepts/context-engineering.md`
  - 维护记录 row 663 chars: | 2026-05-07 | **v4 Phase C2 Query Gap Closure 升级到 hub**（app…
  - proposed_action: 拆分到 manifest record 或 changelog
- **BODY-MAINTENANCE-LOG-VERBOSE** at `/Users/praise/Library/Mobile Documents/iCloud~md~obsidian/Documents/Praise Space/AKB2.0/wiki/concepts/harness-engineering.md`
  - 维护记录 row 249 chars: | 2026-05-04 | **quality_repair v2 — source-grounded 重写** — …
  - proposed_action: 拆分到 manifest record 或 changelog
- **BODY-MAINTENANCE-LOG-VERBOSE** at `/Users/praise/Library/Mobile Documents/iCloud~md~obsidian/Documents/Praise Space/AKB2.0/wiki/concepts/harness-engineering.md`
  - 维护记录 row 749 chars: | 2026-05-06 | **v3 Active Page Constitution 重写**(approved_p…
  - proposed_action: 拆分到 manifest record 或 changelog
- **BODY-MAINTENANCE-LOG-VERBOSE** at `/Users/praise/Library/Mobile Documents/iCloud~md~obsidian/Documents/Praise Space/AKB2.0/wiki/concepts/harness-engineering.md`
  - 维护记录 row 384 chars: | 2026-05-07 | **Phase C2 增量补丁**(approved_plan: AKB2.0 Phase…
  - proposed_action: 拆分到 manifest record 或 changelog
- **BODY-MAINTENANCE-LOG-VERBOSE** at `/Users/praise/Library/Mobile Documents/iCloud~md~obsidian/Documents/Praise Space/AKB2.0/wiki/concepts/large-language-model.md`
  - 维护记录 row 399 chars: | 2026-05-04 | **quality_repair v2 — 收紧到 hub 入口** — **删除** v…
  - proposed_action: 拆分到 manifest record 或 changelog
- **BODY-MAINTENANCE-LOG-VERBOSE** at `/Users/praise/Library/Mobile Documents/iCloud~md~obsidian/Documents/Praise Space/AKB2.0/wiki/concepts/large-language-model.md`
  - 维护记录 row 723 chars: | 2026-05-06 | **v3 Active Page Constitution 重写**(approved_p…
  - proposed_action: 拆分到 manifest record 或 changelog
- **BODY-MAINTENANCE-LOG-VERBOSE** at `/Users/praise/Library/Mobile Documents/iCloud~md~obsidian/Documents/Praise Space/AKB2.0/wiki/concepts/mcp-tool-use.md`
  - 维护记录 row 336 chars: | 2026-05-07 | 初始创建 — Phase C2 Query Gap Closure（approved_pl…
  - proposed_action: 拆分到 manifest record 或 changelog
- **BODY-MAINTENANCE-LOG-VERBOSE** at `/Users/praise/Library/Mobile Documents/iCloud~md~obsidian/Documents/Praise Space/AKB2.0/wiki/designs/implementation-aware-design.md`
  - 维护记录 row 339 chars: | 2026-05-04 | **quality_repair v2 — source-grounded 重写** — …
  - proposed_action: 拆分到 manifest record 或 changelog
- **BODY-MAINTENANCE-LOG-VERBOSE** at `/Users/praise/Library/Mobile Documents/iCloud~md~obsidian/Documents/Praise Space/AKB2.0/wiki/designs/implementation-aware-design.md`
  - 维护记录 row 798 chars: | 2026-05-06 | **v3 Active Page Constitution 重写**(approved_p…
  - proposed_action: 拆分到 manifest record 或 changelog
- **BODY-MAINTENANCE-LOG-VERBOSE** at `/Users/praise/Library/Mobile Documents/iCloud~md~obsidian/Documents/Praise Space/AKB2.0/wiki/sources/anthropic-effective-context-engineering.md`
  - 维护记录 row 455 chars: | 2026-05-07 | 初始创建 — Phase C2 Query Gap Closure（approved_pl…
  - proposed_action: 拆分到 manifest record 或 changelog
- **BODY-MAINTENANCE-LOG-VERBOSE** at `/Users/praise/Library/Mobile Documents/iCloud~md~obsidian/Documents/Praise Space/AKB2.0/wiki/sources/harness-engineering-deep-eval.md`
  - 维护记录 row 657 chars: | 2026-05-04 | L4 Pilot 第一批 active 提升(从 candidate)          …
  - proposed_action: 拆分到 manifest record 或 changelog
- **BODY-MAINTENANCE-LOG-VERBOSE** at `/Users/praise/Library/Mobile Documents/iCloud~md~obsidian/Documents/Praise Space/AKB2.0/wiki/sources/harness-engineering-deep-eval.md`
  - 维护记录 row 657 chars: | 2026-05-04 | quality_repair v1 — 正文扩写到 9 节;frontmatter 收口;…
  - proposed_action: 拆分到 manifest record 或 changelog
- **BODY-MAINTENANCE-LOG-VERBOSE** at `/Users/praise/Library/Mobile Documents/iCloud~md~obsidian/Documents/Praise Space/AKB2.0/wiki/sources/harness-engineering-deep-eval.md`
  - 维护记录 row 657 chars: | 2026-05-04 | **quality_repair v2 — source-grounded 重写** — …
  - proposed_action: 拆分到 manifest record 或 changelog
- **BODY-MAINTENANCE-LOG-VERBOSE** at `/Users/praise/Library/Mobile Documents/iCloud~md~obsidian/Documents/Praise Space/AKB2.0/wiki/sources/harness-engineering-deep-eval.md`
  - 维护记录 row 657 chars: | 2026-05-06 | **v3 Active Page Constitution 重写**(approved_p…
  - proposed_action: 拆分到 manifest record 或 changelog
- **BODY-MAINTENANCE-LOG-VERBOSE** at `/Users/praise/Library/Mobile Documents/iCloud~md~obsidian/Documents/Praise Space/AKB2.0/wiki/sources/harness-engineering-deep-eval.md`
  - 维护记录 row 657 chars: | 2026-05-06 | **v3.1 Codex S1.1 review followup fix** — 修复 …
  - proposed_action: 拆分到 manifest record 或 changelog
- **BODY-MAINTENANCE-LOG-VERBOSE** at `/Users/praise/Library/Mobile Documents/iCloud~md~obsidian/Documents/Praise Space/AKB2.0/wiki/sources/jenny-wen-ai-design-philosophy.md`
  - 维护记录 row 389 chars: | 2026-05-04 | **quality_repair v2 — source-grounded 重写** — …
  - proposed_action: 拆分到 manifest record 或 changelog
- **BODY-MAINTENANCE-LOG-VERBOSE** at `/Users/praise/Library/Mobile Documents/iCloud~md~obsidian/Documents/Praise Space/AKB2.0/wiki/sources/jenny-wen-ai-design-philosophy.md`
  - 维护记录 row 901 chars: | 2026-05-06 | **v3 Active Page Constitution 重写**(approved_p…
  - proposed_action: 拆分到 manifest record 或 changelog
- **BODY-MAINTENANCE-LOG-VERBOSE** at `/Users/praise/Library/Mobile Documents/iCloud~md~obsidian/Documents/Praise Space/AKB2.0/wiki/sources/karpathy-intro-to-llms.md`
  - 维护记录 row 391 chars: | 2026-05-04 | **quality_repair v2 — walkthrough-grounded 严格…
  - proposed_action: 拆分到 manifest record 或 changelog
- **BODY-MAINTENANCE-LOG-VERBOSE** at `/Users/praise/Library/Mobile Documents/iCloud~md~obsidian/Documents/Praise Space/AKB2.0/wiki/sources/karpathy-intro-to-llms.md`
  - 维护记录 row 908 chars: | 2026-05-06 | **v3 Active Page Constitution 重写**(approved_p…
  - proposed_action: 拆分到 manifest record 或 changelog
- **BODY-MAINTENANCE-LOG-VERBOSE** at `/Users/praise/Library/Mobile Documents/iCloud~md~obsidian/Documents/Praise Space/AKB2.0/wiki/sources/mcp-spec.md`
  - 维护记录 row 429 chars: | 2026-05-07 | 初始创建 — Phase C2 Query Gap Closure（approved_pl…
  - proposed_action: 拆分到 manifest record 或 changelog

## 不变量

- CLI 不修改任何 wiki/** active 内容（read-only scan）
- CLI 不修改 standards doc / toolbox / FOLDER-STRUCTURE
- manifest 写入 `manifests/lint/2026-05-07.jsonl`（per LINT-RULES §1.1）