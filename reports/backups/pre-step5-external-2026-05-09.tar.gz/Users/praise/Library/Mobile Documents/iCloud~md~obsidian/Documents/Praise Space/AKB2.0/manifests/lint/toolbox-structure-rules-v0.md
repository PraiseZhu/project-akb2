---
manifest_type: toolbox-structure-lint-rules
version: v0
scope: current_5_tools
created_at: 2026-05-07
phase: p2-toolbox-structure-lint-v0
automation_boundary: §6.2 registered subdirectory
lint_kind: structure
note: 与 akb2-lint.py (content quality lint) 正交。本 manifest 只检查 5件套结构字段合规，不检查内容字段。
---

# AKB2.0 Toolbox Structure Lint Rules v0

## 概述

本 manifest 定义 P2 Toolbox Structure Lint v0 的 8 条结构合规规则，用于扫描当前 5 工具 × 5 件套（25 文件）+ 5 SKILL.md 的结构合规性。

**lint_kind: structure**（区分于 akb2-lint.py 的 content quality lint）

**scope**: 当前 5 工具 = cc-executable-plan / cc-review / cc-local-llm / cc-skill-stocktake / cc-akb-search

---

## 规则一览

| rule_id | 名称 | severity | auto_decidable | 检查目标 |
|---------|------|----------|----------------|---------|
| r01 | five_file_present | hard_fail | ✓ | 5 件套 5 文件全齐 |
| r02 | status_consistency | **handoff** | ✗ | 5 件套 status 字段一致性 |
| r03 | workspace_path_exists | hard_fail | ✓ | interface workspace_path 文件实存 |
| r04 | sha256_match | hard_fail | ✓ | workspace_version sha256 与 SKILL.md 实测匹配 |
| r05 | backlink_linked | hard_fail | ✓ | interface backlink_status = linked（例外见下） |
| r06 | active_needs_l1 | hard_fail | ✓ | active 工具 eval_level ≥ L1 |
| r07 | eval_freshness | **handoff** | ✗ | last_run_at 不超过 30 天 |
| r08 | automation_allowed_false | hard_fail（P0） | ✓ | automation_allowed: true 为 0 |

---

## 规则详情

### r01 — five_file_present

**描述**：每个工具必须有完整的 5 件套：
- `toolbox/interfaces/<slug>.md`
- `toolbox/tools/<slug>.md`
- `toolbox/registry/<slug>.md`
- `toolbox/evals/<slug>.md`
- `wiki/tools/<slug>.md`

**检查方式**：`find` 五个路径，全存在 → pass；缺任 1 → fail

**severity**: `hard_fail`
**auto_decidable**: true — 文件存在/不存在是二元判断

---

### r02 — status_consistency

**描述**：同一工具的 5 件套 frontmatter 中 `status` 字段应一致。若 5 个文件的 status 值集合 cardinality > 1 → handoff。

**注意**：wiki 文件的 status 可能在 5 件套完全完成之前先被更新（如 wiki active + 4 件套 candidate）。这是合理的过渡状态，不算 hard fail。

**检查方式**：`grep -m1 '^status:' <file>` × 5 → 取值集合 cardinality

**severity**: `handoff`（不 fail）
**auto_decidable**: false — 人工裁定 split 是否为预期过渡态

---

### r03 — workspace_path_exists

**描述**：interface 文件中 `workspace_path:` 字段值（通常 `~/.codex/skills/<slug>/SKILL.md`）对应的文件必须实际存在。

**检查方式**：`grep 'workspace_path:' <interface>.md | awk '{print $2}'` → eval 路径展开 → `[ -f <path> ]`

**severity**: `hard_fail`
**auto_decidable**: true

---

### r04 — sha256_match

**描述**：interface 文件 `workspace_version:` 字段（格式 `sha256:<12位前缀> mtime:...`）中的 sha256 前 12 位必须与 `shasum -a 256 <SKILL.md>` 实测值前 12 位一致。

**注意**：eval 文件也有 `workspace_version` 字段，同样检查。

**检查方式**：
```bash
field_sha=$(grep 'workspace_version:' <interface> | grep -oE '[0-9a-f]{12}' | head -1)
actual_sha=$(shasum -a 256 <SKILL.md> | cut -c1-12)
[ "$field_sha" = "$actual_sha" ]
```

**severity**: `hard_fail`
**auto_decidable**: true

---

### r05 — backlink_linked

**描述**：interface 文件中 `backlink_status:` 字段必须为 `linked`。若为 `pending` → fail。

**例外：cc-akb-search**
cc-akb-search 处于 `blocked candidate` 状态（per P1a 确认，mcp__akb-search 未 mount），其 `backlink_status: pending` 是**预期状态**。不 hard fail，输出 `handoff`（reviewer_note 说明 blocked 原因）。

**检查方式**：`grep 'backlink_status:' <interface> | awk '{print $2}'`
- `linked` → pass
- `pending` + slug ≠ cc-akb-search → fail
- `pending` + slug = cc-akb-search → handoff

**severity**: `hard_fail`（cc-akb-search 例外为 handoff）
**auto_decidable**: true（例外逻辑已 hardcode 在 runner 中）

---

### r06 — active_needs_l1

**描述**：status 为 `active` 的工具，eval 文件中 `eval_level:` 必须 ≥ L1（即 L1 或 L2）。若 `active` 但 `eval_level: L0` → fail。

**检查方式**：
```bash
status=$(grep '^status:' <tool-card> | awk '{print $2}')
level=$(grep '^eval_level:' <eval> | awk '{print $2}')
if [ "$status" = "active" ] && [ "$level" = "L0" ]; then fail; fi
```

**severity**: `hard_fail`
**auto_decidable**: true

---

### r07 — eval_freshness

**描述**：eval 文件中 `last_run_at:` 字段距今超过 30 天 → handoff（不 fail）。新工具刚建档时天然 stale，不应 hard fail。

**检查方式**：
```bash
last=$(grep '^last_run_at:' <eval> | awk '{print $2}')
# 计算 days_since = (today - last) in days
# days_since > 30 → handoff
```

**severity**: `handoff`（不 fail）
**auto_decidable**: false — 时间阈值本身可议，stale 可能是合理待机

---

### r08 — automation_allowed_false

**描述**：任何工具 5 件套文件中 `automation_allowed: true` 出现 → hard fail（P0 守门，0 容忍）。

**检查方式**：
```bash
grep -r '^automation_allowed: true$' <toolbox-dir> <wiki-tools-dir>
# 任一命中 → fail（列出命中文件）
```

**severity**: `hard_fail`（P0 守门）
**auto_decidable**: true

---

## Handoff vs Hard Fail 边界

| 规则 | 判定 | 原因 |
|------|------|------|
| r01 | hard fail | 文件缺失是结构性问题，无歧义 |
| r02 | **handoff** | status split 可能是合理过渡态，需人裁 |
| r03 | hard fail | workspace_path 不存在会导致运行时找不到 SKILL |
| r04 | hard fail | sha256 漂移意味着 SKILL.md 被修改，需立即排查 |
| r05 | hard fail（cc-akb-search 例外 handoff）| backlink 断裂影响知识图谱；blocked 候选例外 |
| r06 | hard fail | active 工具没有 L1 eval 是 Gate 不完整 |
| r07 | **handoff** | stale 阈值可议；新工具 stale 是正常状态 |
| r08 | hard fail（P0）| automation_allowed: true 是严格红线，0 容忍 |

---

## 非目标（本 v0 不检查）

- 5 件套内容质量（BODY-MAINTENANCE-LOG / GRAPH-ROLE / SOURCE-* 等）— 由 akb2-lint.py 负责
- staging / 未来 candidate / wiki/concepts 文件
- 5 件套外任何文件
- lint 自动 fix（只 detect）
- r02 split status 的具体类型分析（handoff 后由人裁定）
- eval 质量（L2 语义评估）

---

## 与 akb2-lint.py (lint-cli) 的边界

本 manifest 的 lint_kind 为 **structure**，与 akb2-lint.py 的 content quality lint 正交：

| 维度 | 本 runner (structure lint) | akb2-lint.py (content lint) |
|------|--------------------------|---------------------------|
| 检查对象 | 5件套文件存在性 + frontmatter 字段值 | 5件套内容字段（BODY-MAINTENANCE-LOG 等） |
| 输出格式 | JSON（lint-current-5-tools.json） | JSONL（manifests/lint/*.jsonl） |
| 运行方式 | Bash + jq + shasum | Python |
| 触发时机 | P2 v0 手动跑一次 | 自动化 cron |

两套 lint 可并存，不冲突。

---

## 版本历史

- v0 (2026-05-07): 初版，8 rule，scope = 当前 5 工具
- v1 (待定): 扩展 staging / 未来 candidate（独立 plan）
