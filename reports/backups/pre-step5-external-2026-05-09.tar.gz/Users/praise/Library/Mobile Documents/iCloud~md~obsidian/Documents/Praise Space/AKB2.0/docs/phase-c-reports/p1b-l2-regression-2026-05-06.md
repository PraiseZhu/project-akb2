---
title: P1b — cc-{executable-plan,review} L2 regression — 2026-05-06
doc_type: phase-c-report
phase: P1b
report_kind: l2_regression
report_date: 2026-05-06
document_status: ready
canonical: true
authoritative_for: l2_regression_cc_executable_plan_and_cc_review_2026_05_06
---

# P1b — cc-{executable-plan,review} L2 regression — 2026-05-06

> 工具库 v2 §执行顺序 第 4 项 = P1b L2 regression(独立 plan,2-3 hr,5 类 fixture × 2 工具 = 10 case);承接 [[p0-toolbox-status-slice-2026-05-06|P0 状态切片]] §3 推荐;runner = claude per Option A 用户 override(2026-05-04)。

---

## §1 范围与不变量

### 范围

| 项 | 值 |
|---|---|
| 工具(2)| `cc-executable-plan`(active L1 → L2)+ `cc-review`(active L1 → L2)|
| case 数 / 工具 | 5(3 mandatory + 2 edge)|
| case 总数 | 10 |
| runner | **claude**(Option A — Codex CLI 在本 session 内不可直接调用) |
| evidence pack 路径 | `Codex/ai-infra/akb2-toolbox-evals/p1b-l2-regression/{cc-executable-plan,cc-review}/`(各含 fixtures/ + outputs/ + case-register.md + assertions.md + run-evidence.md)|
| 升级目标 | 2 工具 eval_level: L1 → L2;status 保持 active;automation_allowed 保持 false |

### 不变量(本 P1b 全程守住)

| # | 不变量 | 实测 |
|---|---|---|
| I1 | `~/.codex/skills/cc-executable-plan/SKILL.md` sha256 全程不变 | `5af73fdadd91...` 跑前跑后一致 ✓ |
| I2 | `~/.codex/skills/cc-review/SKILL.md` sha256 全程不变 | `592cf3ed4b2c...` 跑前跑后一致 ✓ |
| I3 | 全库 `automation_allowed: true` = 0 | `grep -rE '^automation_allowed: true' wiki/tools toolbox` 空输出 ✓ |
| I4 | cc-akb-search 严格按 P1a 结论保持 L0 blocked,本 P1b 不触 | cc-akb-search 5 件套 0 改 ✓ |
| I5 | cc-local-llm + cc-skill-stocktake candidate 状态字段无漂移 | 未触 ✓ |
| I6 | 不接 cron / LaunchAgent / hook / lint CLI(P2.x 范围) | 未接 ✓ |
| I7 | 不动 Project AKB / 不触发旧 fetch / synth / translate / NLM | 未触 ✓ |
| I8 | 不修改 5 标准(CONTENT-STANDARD 等)| 未触 ✓ |

---

## §2 5 case × 2 工具 = 10 case 矩阵

### cc-executable-plan(5 case)

| # | case_id | 类型 | REVIEW_DOMAIN | 关键 assertion | 输出 sha256 (前12) | 行数 | 通过 |
|---|---|---|---|---|---|---|---|
| 1 | mandatory-docs-content-plan | mandatory | docs_content | 11 节齐 + Edit 仅 1 文件 + 不越界到代码 + reserved prefix 列表完整 | `dd51650cd76e` | 183 | ✓ |
| 2 | mandatory-ai-infra-plan | mandatory | app_code | --strict-mode 默认 off + exit 3 新增 + 不解锁 automation_allowed + 4-6 单测覆盖矩阵 | `6a703550876e` | 222 | ✓ |
| 3 | mandatory-mutation-boundary-plan | mandatory | ai_infra | §不修改 显式列旧 AKB 全链路 + 不接 cron / LaunchAgent / hook + Project AKB/** 严格只读 | `5b1d8ebcb83c` | 212 | ✓ |
| 4 | edge-ambiguous-input-plan | edge | other | 不编造 file path / 函数名 + §待确认 ≥ 5 条 + §代码执行方向 显式"待用户明示" | `9ef97c8017b2` | 149 | ✓ |
| 5 | edge-review-handoff-plan | edge | ai_infra | Bash 实现(不写 Python)+ 8 类 lint 规则齐 + reviewer handoff 段 3 抽查 + ≥ 4 条对账命令 | `5cfa4f097411` | 245 | ✓ |

### cc-review(5 case)

| # | case_id | 类型 | REVIEW_KIND | 期望 verdict | 实测 verdict | P1 | P2 | 通过 |
|---|---|---|---|---|---|---|---|---|
| 1 | mandatory-clean-plan-review | mandatory | plan | 通过 | 通过 | 0 | 0 | ✓ |
| 2 | mandatory-plan-scope-leak-review | mandatory | plan | 需要修改(≥ 2 P1)| 需要修改 | 2 | 0 | ✓ |
| 3 | mandatory-code-bug-review | mandatory | code | 需要修改(≥ 1 P1 + ≥ 1 P2)| 需要修改 | 1 | 1 | ✓ |
| 4 | edge-residual-risk-only-review | edge | code | 通过(P3 only in 剩余风险)| 通过 | 0 | 0 | ✓ |
| 5 | edge-chinese-fenced-format-review | edge | plan | 通过(主测中文 + 单一 fence)| 通过 | 0 | 0 | ✓ |

### 汇总

- **10/10 case pass**
- **30 主 assertion / 工具 × 2 = 60 主 assertion 全过**
- **2 工具 SKILL.md byte-identical**(0 mutation)
- **2 工具升级**:eval_level L1 → L2;status: active 保持;automation_allowed: false 保持

---

## §3 升级决策

| 工具 | C-5b 状态 | P1b 后状态 | 升级理由 | 不解锁项 |
|---|---|---|---|---|
| cc-executable-plan | active L1 | **active L2** | 5 case 多 case + 跨 4 domain + ambiguous 输入处理 + byte-identical SKILL.md | `automation_allowed: false`(L2 不等于自动化;留 L3 + 人审) |
| cc-review | active L1 | **active L2** | 5 case 多 case + verdict 阈值 + P1/P2/P3 收敛 + 中文 / 单一 fence 格式契约 + byte-identical SKILL.md | `automation_allowed: false`(同上) |

---

## §4 已知未覆盖 / 留下一轮

| 工具 | 失败模式 | 留 phase |
|---|---|---|
| cc-executable-plan | 模板源 vs 镜像 drift → skill 停止生成 | L3 注入失败 case |
| cc-executable-plan | 写入路径不可写 → 报错 | L3 注入失败 case |
| cc-executable-plan | --dry-run flag 输出仅大纲 | L3 |
| cc-review | watch 不可达 → exit 3 + DEGRADED | L3 注入失败 case |
| cc-review | capsule malformed → review 漂移 | L3 |
| cc-review | timeout > 300s → exit 124 | L3 |
| cc-review | 输出不符模板 → 标 `malformed` | L3 |
| 共同 | risk_level 守门 + 自动化人审流程 | L3 + 人审 plan |

---

## §5 验证附录(只读命令,reviewer 可逐条复测)

```bash
WORKSPACE="/Users/praise/Library/Mobile Documents/iCloud~md~obsidian/Documents/Praise Space/AKB2.0"
EVAL_BASE="/Users/praise/Library/Mobile Documents/com~apple~CloudDocs/Codex/ai-infra/akb2-toolbox-evals/p1b-l2-regression"

# §测试.1:SKILL.md sha256 全程不变(2 工具)→ 期望各自 byte-identical
shasum -a 256 ~/.codex/skills/cc-executable-plan/SKILL.md ~/.codex/skills/cc-review/SKILL.md
# expected:
#   5af73fdadd91097cc60f8e6c3622427aeaac8382bda0d1525debe564f2c46d0a  cc-executable-plan/SKILL.md
#   592cf3ed4b2c6e3f96c63a500bdbe3bebbc375a19983debbfa7f1877f406d274  cc-review/SKILL.md

# §测试.2:5 fixture / 5 output 文件齐(2 工具)→ 期望各 5/5
ls "$EVAL_BASE/cc-executable-plan/fixtures" | wc -l   # expected 5
ls "$EVAL_BASE/cc-executable-plan/outputs"  | wc -l   # expected 5
ls "$EVAL_BASE/cc-review/fixtures"          | wc -l   # expected 5
ls "$EVAL_BASE/cc-review/outputs"           | wc -l   # expected 5

# §测试.3:cc-executable-plan 5 output 11 节齐(grep H2 命中 = 10 per file)
for f in "$EVAL_BASE/cc-executable-plan/outputs/"*.md; do
  cnt=$(grep -cE "^## (Review 对齐|目标与验收|当前状态|代码执行方向|接口与数据合约|实现步骤|边界与失败模式|测试计划|待确认|实施前 Review Checklist)" "$f")
  printf "%s: %s/10\n" "$(basename $f)" "$cnt"
done
# expected: each row 10/10

# §测试.4:cc-review verdict 实测对账 → 期望 5 行匹配
for f in "$EVAL_BASE/cc-review/outputs/"*.md; do
  v=$(grep "^结论:" "$f" | head -1)
  printf "%s\t%s\n" "$(basename $f)" "$v"
done
# expected:
#   01-...  结论:通过
#   02-...  结论:需要修改
#   03-...  结论:需要修改
#   04-...  结论:通过
#   05-...  结论:通过

# §测试.5:cc-review P1 / P2 实测分布 → 期望 01:0/0  02:2/0  03:1/1  04:0/0  05:0/0
for f in "$EVAL_BASE/cc-review/outputs/"*.md; do
  p1=$(grep -cE "^### 问题 [0-9]+ .*\[P1\]" "$f")
  p2=$(grep -cE "^### 问题 [0-9]+ .*\[P2\]" "$f")
  printf "%s\tP1=%s\tP2=%s\n" "$(basename $f)" "$p1" "$p2"
done

# §测试.6:0 automation_allowed: true 全库
grep -rE '^automation_allowed: true' "$WORKSPACE/wiki/tools" "$WORKSPACE/toolbox" 2>&1 | head -5
# expected: 空输出

# §测试.7:2 eval frontmatter L2 升级
for f in "$WORKSPACE/toolbox/evals/cc-executable-plan.md" "$WORKSPACE/toolbox/evals/cc-review.md"; do
  echo "--- $(basename $f) ---"
  awk '/^---$/{c++;if(c==2){exit}} {print}' "$f" | grep -E "^(eval_level|prior_eval_level|status|automation_allowed|workspace_version|last_run_evidence):"
done
# expected: eval_level: L2 / prior_eval_level: L1 / status: active / automation_allowed: false / workspace_version 双工具锁定 / last_run_evidence 指 P1b 路径

# §测试.8:case 04 edge ambiguous — §待确认 ≥ 5 条
grep -cE "^[0-9]+\. \*\*" "$EVAL_BASE/cc-executable-plan/outputs/04-edge-ambiguous-input-plan.md"
# expected: ≥ 5

# §测试.9:case 05 review handoff — handoff 段 + 验收对账命令
grep -c "Review handoff" "$EVAL_BASE/cc-executable-plan/outputs/05-edge-review-handoff-plan.md"   # expected ≥ 1

# §测试.10:case 03 cc-review PLANTED 不被 echo
grep -c "PLANTED" "$EVAL_BASE/cc-review/outputs/03-mandatory-code-bug-review.md"   # expected 0
```

期望输出对账:

| # | 命令 | 期望 | 实测 |
|---|---|---|---|
| 1 | SKILL.md sha256 不变 | byte-identical(2 工具)| ✓ |
| 2 | 5 fixture / 5 output 齐 | 5/5 × 4 path | ✓ |
| 3 | cc-executable-plan 5 output 11 节齐 | 10/10 × 5 | ✓ |
| 4 | cc-review verdict 实测对账 | 通过/需要修改/需要修改/通过/通过 | ✓ |
| 5 | cc-review P1/P2 分布 | 0/0  2/0  1/1  0/0  0/0 | ✓ |
| 6 | 0 automation_allowed: true | 空 | ✓ |
| 7 | 2 eval L2 升级 | eval_level: L2 / prior L1 / status active / automation false | ✓ |
| 8 | case 04 §待确认 ≥ 5 条 | 7 | ✓ |
| 9 | case 05 review handoff 段 ≥ 1 | 1 | ✓ |
| 10 | case 03 PLANTED 不 echo | 0 | ✓ |

---

## §6 不变量自检

- [x] 0 mutation 除本报告 + 2 eval frontmatter + body L2 章节 + 26 evidence pack 文件
- [x] `~/.codex/skills/cc-executable-plan/SKILL.md` byte-identical(`5af73fdadd91...` 跑前跑后)
- [x] `~/.codex/skills/cc-review/SKILL.md` byte-identical(`592cf3ed4b2c...` 跑前跑后)
- [x] cc-akb-search / cc-local-llm / cc-skill-stocktake 5 件套 0 字未改
- [x] 不触 5 标准 / wiki/standards/
- [x] 不触 Project AKB / 不触发旧 AKB 链路
- [x] manifests/** 未追加(本 P1b 是 phase report,不是 manifest;evidence 落 ai-infra/ 而不是 manifests/)
- [x] 0 cron / LaunchAgent / hook / lint CLI 创建
- [x] 0 `automation_allowed: true` 解锁

---

## §7 链接

- 上游 P0:[[p0-toolbox-status-slice-2026-05-06|工具库状态切片]] §3 推荐
- 上游 P1a:[[p1a-cc-akb-search-preflight-2026-05-06|cc-akb-search preflight]](本 P1b 不触 cc-akb-search)
- 工具库 v2 plan:`~/.claude/plans/joyful-squishing-moonbeam.md` §P1b 段
- 2 工具 eval(已 L2):
  - [[../../toolbox/evals/cc-executable-plan|cc-executable-plan eval]]
  - [[../../toolbox/evals/cc-review|cc-review eval]]
- evidence pack(全部 26 文件):
  - `Codex/ai-infra/akb2-toolbox-evals/p1b-l2-regression/cc-executable-plan/`
  - `Codex/ai-infra/akb2-toolbox-evals/p1b-l2-regression/cc-review/`
- 下游推荐:**P1c cc-local-llm C-4/C-5**(独立 plan,1-2 hr;先 Bash curl 测 11434)/ **P1d cc-skill-stocktake C-4/C-5**(独立 plan,1-2 hr,先 fixture 设计后 smoke);**P2.1 Toolbox Lint v0**(承接 case 05 输出的 plan blueprint)
