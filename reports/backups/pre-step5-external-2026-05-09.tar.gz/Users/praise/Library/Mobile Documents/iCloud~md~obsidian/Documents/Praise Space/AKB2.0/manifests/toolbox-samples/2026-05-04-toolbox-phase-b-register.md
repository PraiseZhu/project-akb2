---
title: AKB2.0 Toolbox Phase B 样本登记表(2026-05-04)
doc_type: manifest
manifest_type: toolbox_phase_b_register
snapshot_date: 2026-05-04
generated_by: manual
sample_count: 8
required_count: 6
extension_count: 2
---

# AKB2.0 Toolbox Phase B 样本登记表(2026-05-04)

> 本表是 manifest,记录 6 必选 + 2 扩展真实工具样本的 frontmatter 元数据。
> 所有样本 `page_status: candidate` / `automation_allowed: false` / `promotion_required: true`。
> 详细 shadow draft 在 [[../../staging/candidate/toolbox-phase-b-2026-05-04/00-Index|Phase B 样本目录]]。

---

## 必选样本(6)

### sample 1: cc-review

```yaml
sample_id: phase-b-2026-05-04-001
slug: cc-review
asset_type: tool
source_root: ~/.codex/skills/
workspace_path: ~/.codex/skills/cc-review/SKILL.md
workspace_path_exists: true
workspace_owner: official  # codex skill official
workspace_version_strategy: file_hash_mtime
workspace_version: "sha256:d6e7ce54dce6 mtime:2026-04-29"
backlink_status: pending  # workspace 侧未注入反链注释
risk_level: low  # 只读 review,不写 active
side_effects: read_only
automation_tier: L3  # 提议 review verdict,reviewer 决策
automation_allowed: false
intended_registry_path: toolbox/registry/cc-review.md
intended_interface_path: toolbox/interfaces/cc-review.md
intended_eval_path: toolbox/evals/cc-review.md
intended_wiki_tool_path: wiki/tools/cc-review.md
intended_tool_card_path: toolbox/tools/cc-review.md
shadow_bundle_path: staging/candidate/toolbox-phase-b-2026-05-04/cc-review/
phase_b_decision: shadow_complete
blocking_gaps: []
```

### sample 2: cc-executable-plan

```yaml
sample_id: phase-b-2026-05-04-002
slug: cc-executable-plan
asset_type: tool
source_root: ~/.codex/skills/
workspace_path: ~/.codex/skills/cc-executable-plan/SKILL.md
workspace_path_exists: true
workspace_owner: official
workspace_version_strategy: file_hash_mtime
workspace_version: "sha256:69364def87af mtime:2026-04-28"
backlink_status: pending
risk_level: low
side_effects: write_local  # 输出 plan 文档
automation_tier: L1  # 写 candidate plan
automation_allowed: false
intended_registry_path: toolbox/registry/cc-executable-plan.md
intended_interface_path: toolbox/interfaces/cc-executable-plan.md
intended_eval_path: toolbox/evals/cc-executable-plan.md
intended_wiki_tool_path: wiki/tools/cc-executable-plan.md
intended_tool_card_path: toolbox/tools/cc-executable-plan.md
shadow_bundle_path: staging/candidate/toolbox-phase-b-2026-05-04/cc-executable-plan/
phase_b_decision: shadow_complete
blocking_gaps: []
```

### sample 3: cc-akb-search

```yaml
sample_id: phase-b-2026-05-04-003
slug: cc-akb-search
asset_type: tool
source_root: ~/.codex/skills/
workspace_path: ~/.codex/skills/cc-akb-search/SKILL.md
workspace_path_exists: true
workspace_owner: official
workspace_version_strategy: file_hash_mtime
workspace_version: "sha256:b669380de8a0 mtime:2026-04-26"
backlink_status: pending
risk_level: safe
side_effects: read_only
automation_tier: L0
automation_allowed: false  # 默认 false,需 reviewer 升 true
intended_registry_path: toolbox/registry/cc-akb-search.md
intended_interface_path: toolbox/interfaces/cc-akb-search.md
intended_eval_path: toolbox/evals/cc-akb-search.md
intended_wiki_tool_path: wiki/tools/cc-akb-search.md
intended_tool_card_path: toolbox/tools/cc-akb-search.md
shadow_bundle_path: staging/candidate/toolbox-phase-b-2026-05-04/cc-akb-search/
phase_b_decision: shadow_complete
blocking_gaps: []
```

### sample 4: cc-local-llm

```yaml
sample_id: phase-b-2026-05-04-004
slug: cc-local-llm
asset_type: tool
source_root: ~/.codex/skills/
workspace_path: ~/.codex/skills/cc-local-llm/SKILL.md
workspace_path_exists: true
workspace_owner: official
workspace_version_strategy: file_hash_mtime
workspace_version: "sha256:b8050d3c236a mtime:2026-04-26"
backlink_status: pending
risk_level: low
side_effects: read_only  # 调本地 LLM,不外发
automation_tier: L0
automation_allowed: false
intended_registry_path: toolbox/registry/cc-local-llm.md
intended_interface_path: toolbox/interfaces/cc-local-llm.md
intended_eval_path: toolbox/evals/cc-local-llm.md
intended_wiki_tool_path: wiki/tools/cc-local-llm.md
intended_tool_card_path: toolbox/tools/cc-local-llm.md
shadow_bundle_path: staging/candidate/toolbox-phase-b-2026-05-04/cc-local-llm/
phase_b_decision: shadow_complete
blocking_gaps: []
```

### sample 5: execution-result-gate

```yaml
sample_id: phase-b-2026-05-04-005
slug: execution-result-gate
asset_type: agent_procedure
source_root: ~/.claude/scripts/hooks/
workspace_path: ~/.claude/scripts/hooks/execution-result-gate.js
workspace_path_exists: true
workspace_owner: user
workspace_version_strategy: file_hash_mtime
workspace_version: "sha256:08713602b1a2 mtime:2026-04-30"
backlink_status: pending
risk_level: medium  # PostToolUse hook,影响所有 mutation
side_effects: read_only  # 只读检查 + 输出阻断信号,不动文件
automation_tier: L3  # hook 自动触发但只阻断不修改
automation_allowed: false  # 本轮不批准 — agent_procedure 默认 false
intended_registry_path: toolbox/registry/execution-result-gate.md
intended_interface_path: toolbox/interfaces/execution-result-gate.md
intended_eval_path: toolbox/evals/execution-result-gate.md
shadow_bundle_path: staging/candidate/toolbox-phase-b-2026-05-04/execution-result-gate/
phase_b_decision: shadow_complete
blocking_gaps: ["hook 已在 settings.json 注册并自动运行 — workspace 侧实际是 active 状态,但 Obsidian 侧仍 candidate(本轮不批 active)"]
```

### sample 6: akb-ingest-gate

```yaml
sample_id: phase-b-2026-05-04-006
slug: akb-ingest-gate
asset_type: agent_procedure
source_root: ~/.claude/scripts/hooks/
workspace_path: ~/.claude/scripts/hooks/akb-ingest-gate.js
workspace_path_exists: true
workspace_owner: user
workspace_version_strategy: file_hash_mtime
workspace_version: "sha256:bfd15e54b595 mtime:2026-04-26"
backlink_status: pending
risk_level: medium  # PreToolUse hook,可阻断写入
side_effects: read_only
automation_tier: L3
automation_allowed: false
intended_registry_path: toolbox/registry/akb-ingest-gate.md
intended_interface_path: toolbox/interfaces/akb-ingest-gate.md
intended_eval_path: toolbox/evals/akb-ingest-gate.md
shadow_bundle_path: staging/candidate/toolbox-phase-b-2026-05-04/akb-ingest-gate/
phase_b_decision: shadow_complete
blocking_gaps: ["同 sample 5 — 已在 settings.json 注册自动运行,Obsidian 侧仍 candidate"]
```

---

## 扩展样本(2)

### sample 7: cc-skill-stocktake

```yaml
sample_id: phase-b-2026-05-04-007
slug: cc-skill-stocktake
asset_type: tool
source_root: ~/.codex/skills/
workspace_path: ~/.codex/skills/cc-skill-stocktake/SKILL.md
workspace_path_exists: true
workspace_owner: official
workspace_version_strategy: file_hash_mtime
workspace_version: "sha256:52d10db4618d mtime:2026-04-26"
backlink_status: pending
risk_level: safe
side_effects: read_only
automation_tier: L0
automation_allowed: false
intended_registry_path: toolbox/registry/cc-skill-stocktake.md
intended_interface_path: toolbox/interfaces/cc-skill-stocktake.md
intended_eval_path: toolbox/evals/cc-skill-stocktake.md
intended_wiki_tool_path: wiki/tools/cc-skill-stocktake.md
intended_tool_card_path: toolbox/tools/cc-skill-stocktake.md
shadow_bundle_path: staging/candidate/toolbox-phase-b-2026-05-04/cc-skill-stocktake/
phase_b_decision: shadow_complete
blocking_gaps: []
```

### sample 8: review-result-writer

```yaml
sample_id: phase-b-2026-05-04-008
slug: review-result-writer
asset_type: workflow
source_root: ~/.claude/scripts/
workspace_path: ~/.claude/scripts/review-result-writer.sh
workspace_path_exists: true
workspace_owner: user
workspace_version_strategy: file_hash_mtime
workspace_version: "sha256:03dc1d6a7b54 mtime:2026-04-29"
backlink_status: pending
risk_level: medium  # 写 baseline + capsule + result
side_effects: write_local
automation_tier: L1  # 写 manifest,不动 active wiki
automation_allowed: false
intended_registry_path: toolbox/registry/review-result-writer.md
intended_interface_path: toolbox/interfaces/review-result-writer.md
intended_eval_path: toolbox/evals/review-result-writer.md
shadow_bundle_path: staging/candidate/toolbox-phase-b-2026-05-04/review-result-writer/
phase_b_decision: shadow_complete
blocking_gaps: []
```

---

## 汇总

- 总样本数:**8**(6 必选 + 2 扩展)
- workspace_path_exists 全部 true:**8/8** ✅
- workspace_version 已记录:**8/8** ✅(全部用 `file_hash_mtime` 策略,因为 ~/.codex 和 ~/.claude 不在 git)
- backlink_status:**全部 pending**(workspace 侧未注入反链注释,本轮不动)
- automation_allowed:**全部 false**(本轮零批准)
- shadow bundle 完成度:**8/8** ✅(详见各样本目录)
- blocking_gaps:仅 sample 5/6(hook 已自动运行但 Obsidian 仍 candidate,设计预期不阻塞)

---

## 修订历史

| 日期 | 改动 | 作者 |
|------|------|------|
| 2026-05-04 | 首次登记 6 必选 + 2 扩展样本;全部 workspace_path 真实存在;workspace_version 策略 file_hash_mtime;backlink_status 全 pending;automation_allowed 全 false | Claude Code |
